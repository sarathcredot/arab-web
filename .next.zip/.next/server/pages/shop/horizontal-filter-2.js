(function() {
var exports = {};
exports.id = 1874;
exports.ids = [1874];
exports.modules = {

/***/ 8420:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ horizontal_filter_2; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: ./components/partials/shop/shop-banner.jsx
var shop_banner = __webpack_require__(5128);
// EXTERNAL MODULE: external "react-slide-toggle"
var external_react_slide_toggle_ = __webpack_require__(3920);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
// EXTERNAL MODULE: ./utils/data/shop.js
var shop = __webpack_require__(129);
;// CONCATENATED MODULE: ./components/partials/shop/sidebar/shop-sidebar-two.jsx

var __jsx = (external_react_default()).createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











function ShopSidebarTwo(props) {
  const router = (0,router_.useRouter)();
  const query = router.query;
  const {
    error
  } = (0,react_hooks_.useQuery)(queries/* GET_SHOP_SIDEBAR_DATA */.EP, {
    variables: {
      featured: true
    }
  });
  const {
    0: priceRange,
    1: setRange
  } = (0,external_react_.useState)({
    min: 0,
    max: 1000
  });
  (0,external_react_.useEffect)(() => {
    document.querySelector("body").addEventListener("click", onBodyClick);
    return () => {
      document.querySelector("body").removeEventListener("click", onBodyClick);
    };
  }, []);

  function containsAttrInUrl(type, value) {
    const currentQueries = query[type] ? query[type].split(',') : [];
    return currentQueries && currentQueries.includes(value);
  }

  function filterByPrice(e) {
    e.preventDefault();
    router.push({
      pathname: router.pathname,
      query: _objectSpread(_objectSpread({}, query), {}, {
        min_price: priceRange.min,
        max_price: priceRange.max
      })
    });
  }

  function openList(e) {
    e.currentTarget.classList.toggle('opened');
  }

  function getUrlForAttrs(type, value) {
    let currentQueries = query[type] ? query[type].split(',') : [];
    currentQueries = containsAttrInUrl(type, value) ? currentQueries.filter(item => item !== value) : [...currentQueries, value];
    return currentQueries.join(',');
  }

  function closeSidebar() {
    document.querySelector('body').classList.contains('sidebar-opened') && document.querySelector('body').classList.remove('sidebar-opened');
  }

  function onBodyClick(e) {
    e.target.closest('.toolbox-sort.opened') || document.querySelector('.toolbox-sort.opened') && document.querySelector('.toolbox-sort.opened').classList.remove('opened');
  }

  function minPriceChange(e) {
    setRange(_objectSpread(_objectSpread({}, priceRange), {}, {
      min: parseInt(e.target.value)
    }));
  }

  function maxPriceChange(e) {
    setRange(_objectSpread(_objectSpread({}, priceRange), {}, {
      max: parseInt(e.target.value)
    }));
  }

  if (error) {
    return __jsx("div", null, error.message);
  }

  return __jsx((external_react_default()).Fragment, null, __jsx("div", {
    className: `sidebar-overlay ${props.adClass}`,
    onClick: closeSidebar
  }), __jsx("aside", {
    className: `toolbox-left sidebar-shop mobile-sidebar mb-0 ${props.adClass}`
  }, __jsx("div", {
    className: "toolbox-item toolbox-sort select-custom",
    onClick: openList
  }, __jsx("span", {
    className: "sort-menu-trigger"
  }, "Size"), __jsx("ul", {
    className: "sort-list"
  }, shop/* shopSizes.map */.jU.map((item, index) => __jsx("li", {
    className: containsAttrInUrl('sizes', item.size) ? 'active' : '',
    key: `size-${index}`
  }, __jsx(ALink/* default */.Z, {
    href: {
      query: _objectSpread(_objectSpread({}, query), {}, {
        page: 1,
        sizes: getUrlForAttrs('sizes', item.size)
      })
    },
    scroll: false
  }, item.name))))), __jsx("div", {
    className: "toolbox-item toolbox-sort select-custom",
    onClick: openList
  }, __jsx("span", {
    className: "sort-menu-trigger"
  }, "Color"), __jsx("ul", {
    className: "sort-list"
  }, shop/* shopColors.map */.oQ.map((item, index) => __jsx("li", {
    className: containsAttrInUrl('colors', item.name) ? 'active' : '',
    key: `color-${index}`
  }, __jsx(ALink/* default */.Z, {
    href: {
      query: _objectSpread(_objectSpread({}, query), {}, {
        page: 1,
        colors: getUrlForAttrs('colors', item.name)
      })
    },
    scroll: false
  }, item.name))))), __jsx("div", {
    className: "toolbox-item toolbox-sort price-sort select-custom",
    onClick: openList
  }, __jsx("span", {
    className: "sort-menu-trigger"
  }, "Price"), __jsx("div", {
    className: "sort-list",
    onClick: e => e.stopPropagation()
  }, __jsx("form", {
    className: "filter-price-form d-flex align-items-center m-0"
  }, __jsx("input", {
    type: "number",
    className: "input-price mr-2",
    name: "min_price",
    placeholder: "55",
    value: priceRange.min,
    onChange: minPriceChange
  }), " -", __jsx("input", {
    type: "number",
    className: "input-price mx-2",
    name: "max_price",
    placeholder: "111",
    value: priceRange.max,
    onChange: maxPriceChange
  }), __jsx("button", {
    type: "submit",
    className: "btn btn-primary ml-3",
    onClick: e => filterByPrice(e)
  }, "Filter"))))));
}

/* harmony default export */ var shop_sidebar_two = ((0,apollo/* default */.Z)({
  ssr: true
})(ShopSidebarTwo));
// EXTERNAL MODULE: ./components/features/pagination.jsx
var pagination = __webpack_require__(2078);
// EXTERNAL MODULE: ./components/partials/products-collection/product-grid.jsx
var product_grid = __webpack_require__(9066);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/shop/horizontal-filter-2.js

var horizontal_filter_2_jsx = (external_react_default()).createElement;

function horizontal_filter_2_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function horizontal_filter_2_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { horizontal_filter_2_ownKeys(Object(source), true).forEach(function (key) { horizontal_filter_2_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { horizontal_filter_2_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function horizontal_filter_2_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













function ShopHorizontalTwo() {
  const router = (0,router_.useRouter)();
  const query = router.query;
  const [getProducts, {
    data,
    loading,
    error
  }] = (0,react_hooks_.useLazyQuery)(queries/* GET_PRODUCTS */.tT);
  const {
    0: perPage,
    1: setPerPage
  } = (0,external_react_.useState)(12);
  const {
    0: sortBy,
    1: setSortBy
  } = (0,external_react_.useState)(query.sortBy ? query.sortBy : 'default');
  const products = data && data.products.data;
  const totalPage = data ? parseInt(data.products.total / perPage) + (data.products.total % perPage ? 1 : 0) : 1;
  (0,external_react_.useEffect)(() => {
    let offset = document.querySelector('.main-content').getBoundingClientRect().top + window.pageYOffset - 58;
    setTimeout(() => {
      window.scrollTo({
        top: offset,
        behavior: 'smooth'
      });
    }, 200);
    let page = query.page ? query.page : 1;
    getProducts({
      variables: {
        search: query.search,
        colors: query.colors ? query.colors.split(',') : [],
        sizes: query.sizes ? query.sizes.split(',') : [],
        brands: query.brands ? query.brands.split(',') : [],
        min_price: parseInt(query.min_price),
        max_price: parseInt(query.max_price),
        category: query.category,
        tag: query.tag,
        sortBy: sortBy,
        from: perPage * (page - 1),
        to: perPage * page
      }
    });
  }, [query, perPage, sortBy]);

  function onPerPageChange(e) {
    setPerPage(e.target.value);
    router.push({
      pathname: router.pathname,
      query: horizontal_filter_2_objectSpread(horizontal_filter_2_objectSpread({}, query), {}, {
        page: 1
      })
    });
  }

  function onSortByChange(e) {
    router.push({
      pathname: router.pathname,
      query: horizontal_filter_2_objectSpread(horizontal_filter_2_objectSpread({}, query), {}, {
        sortBy: e.target.value,
        page: 1
      })
    });
    setSortBy(e.target.value);
  }

  function sidebarToggle(e) {
    let body = document.querySelector('body');
    e.preventDefault();

    if (body.classList.contains('sidebar-opened')) {
      body.classList.remove('sidebar-opened');
    } else {
      body.classList.add('sidebar-opened');
    }
  }

  if (error) {
    return horizontal_filter_2_jsx("div", null, error.message);
  }

  return horizontal_filter_2_jsx("main", {
    className: "main"
  }, horizontal_filter_2_jsx(shop_banner/* default */.Z, null), horizontal_filter_2_jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-2"
  }, horizontal_filter_2_jsx("div", {
    className: "container"
  }, horizontal_filter_2_jsx("ol", {
    className: "breadcrumb"
  }, horizontal_filter_2_jsx("li", {
    className: "breadcrumb-item"
  }, horizontal_filter_2_jsx(ALink/* default */.Z, {
    href: "/"
  }, horizontal_filter_2_jsx(index_esm/* IoMdHome */.QO$, {
    style: {
      fontSize: "16px"
    }
  }))), query.category ? horizontal_filter_2_jsx((external_react_default()).Fragment, null, horizontal_filter_2_jsx("li", {
    className: "breadcrumb-item"
  }, horizontal_filter_2_jsx(ALink/* default */.Z, {
    href: "/shop",
    scroll: false
  }, "shop")), data && data.products.categoryFamily.map((item, index) => horizontal_filter_2_jsx("li", {
    className: "breadcrumb-item",
    key: `category-family-${index}`
  }, horizontal_filter_2_jsx(ALink/* default */.Z, {
    href: {
      query: {
        category: item.slug
      }
    },
    scroll: false
  }, item.name))), horizontal_filter_2_jsx("li", {
    className: "breadcrumb-item active"
  }, query.search ? horizontal_filter_2_jsx((external_react_default()).Fragment, null, "Search - ", horizontal_filter_2_jsx(ALink/* default */.Z, {
    href: {
      query: {
        category: query.category
      }
    },
    scroll: false
  }, query.category), " / ", query.search) : query.category)) : query.search ? horizontal_filter_2_jsx((external_react_default()).Fragment, null, horizontal_filter_2_jsx("li", {
    className: "breadcrumb-item"
  }, horizontal_filter_2_jsx(ALink/* default */.Z, {
    href: {
      pathname: router.pathname,
      query: {}
    },
    scroll: false
  }, "shop")), horizontal_filter_2_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, `Search - ${query.search}`)) : query.tag ? horizontal_filter_2_jsx((external_react_default()).Fragment, null, horizontal_filter_2_jsx("li", {
    className: "breadcrumb-item"
  }, horizontal_filter_2_jsx(ALink/* default */.Z, {
    href: {
      pathname: router.pathname,
      query: {}
    },
    scroll: false
  }, "shop")), horizontal_filter_2_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, `Product Tag - ${query.tag}`)) : horizontal_filter_2_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, "Shop")))), horizontal_filter_2_jsx("div", {
    className: "container"
  }, horizontal_filter_2_jsx("nav", {
    className: "toolbox sticky-header horizontal-filter filter-sorts mobile-sticky mb-2 pt-3 pb-3 pb-lg-0"
  }, horizontal_filter_2_jsx("div", {
    className: "toolbox-left"
  }, horizontal_filter_2_jsx("a", {
    href: "#",
    className: "sidebar-toggle",
    onClick: e => sidebarToggle(e)
  }, horizontal_filter_2_jsx("svg", {
    "data-name": "Layer 3",
    id: "Layer_3",
    viewBox: "0 0 32 32",
    xmlns: "http://www.w3.org/2000/svg"
  }, horizontal_filter_2_jsx("line", {
    x1: "15",
    x2: "26",
    y1: "9",
    y2: "9",
    className: "cls-1"
  }), horizontal_filter_2_jsx("line", {
    x1: "6",
    x2: "9",
    y1: "9",
    y2: "9",
    className: "cls-1"
  }), horizontal_filter_2_jsx("line", {
    x1: "23",
    x2: "26",
    y1: "16",
    y2: "16",
    className: "cls-1"
  }), horizontal_filter_2_jsx("line", {
    x1: "6",
    x2: "17",
    y1: "16",
    y2: "16",
    className: "cls-1"
  }), horizontal_filter_2_jsx("line", {
    x1: "17",
    x2: "26",
    y1: "23",
    y2: "23",
    className: "cls-1"
  }), horizontal_filter_2_jsx("line", {
    x1: "6",
    x2: "11",
    y1: "23",
    y2: "23",
    className: "cls-1"
  }), horizontal_filter_2_jsx("path", {
    d: "M14.5,8.92A2.6,2.6,0,0,1,12,11.5,2.6,2.6,0,0,1,9.5,8.92a2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  }), horizontal_filter_2_jsx("path", {
    d: "M22.5,15.92a2.5,2.5,0,1,1-5,0,2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  }), horizontal_filter_2_jsx("path", {
    d: "M21,16a1,1,0,1,1-2,0,1,1,0,0,1,2,0Z",
    className: "cls-3"
  }), horizontal_filter_2_jsx("path", {
    d: "M16.5,22.92A2.6,2.6,0,0,1,14,25.5a2.6,2.6,0,0,1-2.5-2.58,2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  })), horizontal_filter_2_jsx("span", null, "Filter")), horizontal_filter_2_jsx(shop_sidebar_two, {
    adClass: "d-lg-flex d-none"
  }), horizontal_filter_2_jsx("div", {
    className: "toolbox-item toolbox-sort"
  }, horizontal_filter_2_jsx("div", {
    className: "select-custom"
  }, horizontal_filter_2_jsx("select", {
    name: "orderby",
    className: "form-control",
    value: sortBy,
    onChange: e => onSortByChange(e)
  }, horizontal_filter_2_jsx("option", {
    value: "default"
  }, "Default sorting"), horizontal_filter_2_jsx("option", {
    value: "popularity"
  }, "Sort by popularity"), horizontal_filter_2_jsx("option", {
    value: "rating"
  }, "Sort by average rating"), horizontal_filter_2_jsx("option", {
    value: "date"
  }, "Sort by newness"), horizontal_filter_2_jsx("option", {
    value: "price"
  }, "Sort by price: low to high"), horizontal_filter_2_jsx("option", {
    value: "price-desc"
  }, "Sort by price: high to low"))))), horizontal_filter_2_jsx("div", {
    className: "toolbox-right ml-auto"
  }, horizontal_filter_2_jsx("div", {
    className: "toolbox-item toolbox-show"
  }, horizontal_filter_2_jsx("label", null, "Show:"), horizontal_filter_2_jsx("div", {
    className: "select-custom"
  }, horizontal_filter_2_jsx("select", {
    name: "count",
    className: "form-control",
    value: perPage,
    onChange: e => onPerPageChange(e)
  }, horizontal_filter_2_jsx("option", {
    value: "12"
  }, "12"), horizontal_filter_2_jsx("option", {
    value: "24"
  }, "24"), horizontal_filter_2_jsx("option", {
    value: "36"
  }, "36")))), horizontal_filter_2_jsx("div", {
    className: "toolbox-item layout-modes"
  }, horizontal_filter_2_jsx(ALink/* default */.Z, {
    href: {
      pathname: router.pathname,
      query: query
    },
    className: "layout-btn btn-grid active",
    title: "Grid"
  }, horizontal_filter_2_jsx("i", {
    className: "icon-mode-grid"
  })), horizontal_filter_2_jsx(ALink/* default */.Z, {
    href: {
      pathname: '/shop/list',
      query: query
    },
    className: "layout-btn btn-list",
    title: "List"
  }, horizontal_filter_2_jsx("i", {
    className: "icon-mode-list"
  }))))), horizontal_filter_2_jsx("div", {
    className: "row"
  }, horizontal_filter_2_jsx(shop_sidebar_two, {
    adClass: "horizontal-filter filter-sorts d-lg-none d-block"
  }), horizontal_filter_2_jsx("div", {
    className: "col-lg-12 main-content pt-0"
  }, horizontal_filter_2_jsx(product_grid/* default */.Z, {
    products: products,
    loading: loading,
    perPage: perPage,
    gridClass: "col-6 col-sm-4 col-md-3"
  }), loading || products && products.length ? horizontal_filter_2_jsx("nav", {
    className: "toolbox toolbox-pagination border-0"
  }, horizontal_filter_2_jsx("div", {
    className: "toolbox-item toolbox-show"
  }, horizontal_filter_2_jsx("label", null, "Show:"), horizontal_filter_2_jsx("div", {
    className: "select-custom"
  }, horizontal_filter_2_jsx("select", {
    name: "count",
    className: "form-control",
    value: perPage,
    onChange: e => onPerPageChange(e)
  }, horizontal_filter_2_jsx("option", {
    value: "12"
  }, "12"), horizontal_filter_2_jsx("option", {
    value: "24"
  }, "24"), horizontal_filter_2_jsx("option", {
    value: "36"
  }, "36")))), horizontal_filter_2_jsx(pagination/* default */.Z, {
    totalPage: totalPage
  })) : ''))), horizontal_filter_2_jsx("div", {
    className: "mb-xl-4 mb-0"
  }));
}

/* harmony default export */ var horizontal_filter_2 = ((0,apollo/* default */.Z)({
  ssr: true
})(ShopHorizontalTwo));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,2806,5708,4229,4011,2078,8816,9066], function() { return __webpack_exec__(8420); });
module.exports = __webpack_exports__;

})();