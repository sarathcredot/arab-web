(function() {
var exports = {};
exports.id = 4484;
exports.ids = [4484];
exports.modules = {

/***/ 4013:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ list; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: ./components/partials/shop/shop-banner.jsx
var shop_banner = __webpack_require__(5128);
// EXTERNAL MODULE: ./components/partials/shop/sidebar/shop-sidebar-one.jsx
var shop_sidebar_one = __webpack_require__(101);
// EXTERNAL MODULE: ./components/features/pagination.jsx
var pagination = __webpack_require__(2078);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: external "react-lazy-load-image-component"
var external_react_lazy_load_image_component_ = __webpack_require__(9290);
// EXTERNAL MODULE: ./store/wishlist.js
var wishlist = __webpack_require__(5708);
// EXTERNAL MODULE: ./store/cart.js
var cart = __webpack_require__(2806);
// EXTERNAL MODULE: ./store/modal.js
var modal = __webpack_require__(6723);
// EXTERNAL MODULE: ./components/features/product-countdown.jsx
var product_countdown = __webpack_require__(4229);
;// CONCATENATED MODULE: ./components/features/products/product-two.jsx
var __jsx = (external_react_default()).createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // Import Actions



 // Import Custom Component




function ProductTwo(props) {
  const router = (0,router_.useRouter)();
  const {
    adClass = "",
    link = "default",
    product
  } = props;

  function isSale() {
    return product.price[0] !== product.price[1] && product.variants.length === 0 ? '-' + (100 * (product.price[1] - product.price[0]) / product.price[1]).toFixed(0) + '%' : product.variants.find(variant => variant.sale_price) ? "Sale" : false;
  }

  function isInWishlist() {
    return product && props.wishlist.findIndex(item => item.slug === product.slug) > -1;
  }

  function onWishlistClick(e) {
    e.preventDefault();

    if (!isInWishlist()) {
      let target = e.currentTarget;
      target.classList.add("load-more-overlay");
      target.classList.add("loading");
      setTimeout(() => {
        target.classList.remove('load-more-overlay');
        target.classList.remove('loading');
        props.addToWishList(product);
      }, 1000);
    } else {
      router.push('/pages/wishlist');
    }
  }

  function onAddCartClick(e) {
    e.preventDefault();
    props.addToCart(product);
  }

  function onQuickViewClick(e) {
    e.preventDefault();
    props.showQuickView(product.slug);
  }

  return __jsx("div", {
    className: `product-default media-with-lazy left-details mb-2 product-list ${adClass}`
  }, __jsx("figure", null, __jsx(ALink/* default */.Z, {
    href: `/product/${link}/${product.slug}`
  }, __jsx("div", {
    className: "lazy-overlay"
  }), __jsx(external_react_lazy_load_image_component_.LazyLoadImage, {
    alt: "product",
    src: process.env.NEXT_PUBLIC_ASSET_URI + product.pictures[0].url,
    threshold: 500,
    effect: "black and white",
    width: "100%"
  }), product.pictures.length >= 2 ? __jsx(external_react_lazy_load_image_component_.LazyLoadImage, {
    alt: "product",
    src: process.env.NEXT_PUBLIC_ASSET_URI + product.pictures[1].url,
    threshold: 500,
    effect: "black and white",
    wrapperClassName: "product-image-hover"
  }) : ""), __jsx("div", {
    className: "label-group"
  }, product.is_hot ? __jsx("div", {
    className: "product-label label-hot"
  }, "HOT") : '', isSale() ? __jsx("div", {
    className: "product-label label-sale"
  }, isSale()) : ''), product.until && product.until !== null && __jsx(product_countdown/* default */.Z, null)), __jsx("div", {
    className: "product-details"
  }, __jsx("div", {
    className: "category-wrap"
  }, __jsx("div", {
    className: "category-list"
  }, product.categories ? product.categories.map((item, index) => __jsx((external_react_default()).Fragment, {
    key: item.slug + '-' + index
  }, __jsx(ALink/* default */.Z, {
    href: {
      pathname: '/shop',
      query: {
        category: item.slug
      }
    }
  }, item.name), index < product.categories.length - 1 ? ', ' : "")) : "")), __jsx("h3", {
    className: "product-title"
  }, __jsx(ALink/* default */.Z, {
    href: `/product/default/${product.slug}`
  }, product.name)), __jsx("div", {
    className: "ratings-container"
  }, __jsx("div", {
    className: "product-ratings"
  }, __jsx("span", {
    className: "ratings",
    style: {
      width: 20 * product.ratings + '%'
    }
  }), __jsx("span", {
    className: "tooltiptext tooltip-top"
  }, product.ratings.toFixed(2)))), __jsx("p", {
    className: "product-description"
  }, product.short_description), __jsx("div", {
    className: "price-box"
  }, product.price[0] == product.price[1] ? __jsx("span", {
    className: "product-price"
  }, '$' + product.price[0].toFixed(2)) : product.variants.length > 0 ? __jsx("span", {
    className: "product-price"
  }, '$' + product.price[0].toFixed(2), " \u2013 ", '$' + product.price[1].toFixed(2)) : __jsx((external_react_default()).Fragment, null, __jsx("span", {
    className: "old-price"
  }, '$' + product.price[1].toFixed(2)), __jsx("span", {
    className: "product-price"
  }, '$' + product.price[0].toFixed(2)))), __jsx("div", {
    className: "product-action"
  }, product.variants.length > 0 ? __jsx(ALink/* default */.Z, {
    href: `/product/default/${product.slug}`,
    className: "btn-icon btn-add-cart"
  }, __jsx("i", {
    className: "fa fa-arrow-right"
  }), __jsx("span", null, "SELECT OPTIONS")) : __jsx("a", {
    href: "#",
    className: "btn-icon btn-add-cart product-type-simple",
    title: "Add To Cart",
    onClick: onAddCartClick
  }, __jsx("i", {
    className: "icon-shopping-cart"
  }), __jsx("span", null, "ADD TO CART")), __jsx("a", {
    href: "#",
    className: `btn-icon-wish ${isInWishlist() ? 'added-wishlist' : ''}`,
    onClick: onWishlistClick,
    title: `${isInWishlist() === true ? 'Go to Wishlist' : 'Add to Wishlist'}`
  }, __jsx("i", {
    className: "icon-heart"
  })), __jsx("a", {
    href: "#",
    className: "btn-quickview",
    title: "Quick View",
    onClick: onQuickViewClick
  }, __jsx("i", {
    className: "fas fa-external-link-alt"
  })))));
}

const mapStateToProps = state => {
  return {
    wishlist: state.wishlist.list ? state.wishlist.list : []
  };
};

/* harmony default export */ var product_two = ((0,external_react_redux_.connect)(mapStateToProps, _objectSpread(_objectSpread(_objectSpread({}, wishlist/* actions */.Nw), cart/* actions */.Nw), modal/* actions */.Nw))(ProductTwo));
;// CONCATENATED MODULE: ./components/partials/products-collection/product-row.jsx

var product_row_jsx = (external_react_default()).createElement;

function ProductsRow(props) {
  const {
    products = [],
    gridClass = "col-6 col-sm-12",
    loading,
    perPage,
    addClass = ''
  } = props;
  return product_row_jsx((external_react_default()).Fragment, null, product_row_jsx("div", {
    className: `row skeleton-body skel-shop-products ${addClass} ${!loading ? 'loaded' : ''}`
  }, loading ? new Array(parseInt(perPage)).fill(1).map((item, index) => product_row_jsx("div", {
    className: gridClass,
    key: `skel-pro-${index}`
  }, product_row_jsx("div", {
    className: "skel-pro skel-pro-list"
  }))) : products.map((item, index) => product_row_jsx("div", {
    className: gridClass,
    key: `product-${index}`
  }, product_row_jsx(product_two, {
    product: item
  })))), !loading && products.length === 0 ? product_row_jsx("div", {
    className: "info-box with-icon"
  }, product_row_jsx("p", null, "No products were found matching your selection.")) : '');
}
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
;// CONCATENATED MODULE: ./pages/shop/list.js

var list_jsx = (external_react_default()).createElement;

function list_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function list_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { list_ownKeys(Object(source), true).forEach(function (key) { list_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { list_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function list_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













function Shop() {
  const router = (0,router_.useRouter)();
  const query = router.query;
  const [getProducts, {
    data,
    loading,
    error
  }] = (0,react_hooks_.useLazyQuery)(queries/* GET_PRODUCTS */.tT);
  const {
    0: perPage,
    1: setPerPage
  } = (0,external_react_.useState)(12);
  const {
    0: sortBy,
    1: setSortBy
  } = (0,external_react_.useState)(query.sortBy ? query.sortBy : 'default');
  const products = data && data.products.data;
  const totalPage = data ? parseInt(data.products.total / perPage) + (data.products.total % perPage ? 1 : 0) : 1;
  (0,external_react_.useEffect)(() => {
    let offset = document.querySelector('.main-content').getBoundingClientRect().top + window.pageYOffset - 58;
    setTimeout(() => {
      window.scrollTo({
        top: offset,
        behavior: 'smooth'
      });
    }, 200);
    let page = query.page ? query.page : 1;
    getProducts({
      variables: {
        list: true,
        search: query.search,
        colors: query.colors ? query.colors.split(',') : [],
        sizes: query.sizes ? query.sizes.split(',') : [],
        min_price: parseInt(query.min_price),
        max_price: parseInt(query.max_price),
        category: query.category,
        tag: query.tag,
        sortBy: sortBy,
        from: perPage * (page - 1),
        to: perPage * page
      }
    });
  }, [query, perPage, sortBy]);

  function onPerPageChange(e) {
    setPerPage(e.target.value);
    router.push({
      pathname: router.pathname,
      query: list_objectSpread(list_objectSpread({}, query), {}, {
        page: 1
      })
    });
  }

  function onSortByChange(e) {
    router.push({
      pathname: router.pathname,
      query: list_objectSpread(list_objectSpread({}, query), {}, {
        sortBy: e.target.value,
        page: 1
      })
    });
    setSortBy(e.target.value);
  }

  function sidebarToggle(e) {
    let body = document.querySelector('body');
    e.preventDefault();

    if (body.classList.contains('sidebar-opened')) {
      body.classList.remove('sidebar-opened');
    } else {
      body.classList.add('sidebar-opened');
    }
  }

  if (error) {
    return list_jsx("div", null, error.message);
  }

  return list_jsx("main", {
    className: "main"
  }, list_jsx(shop_banner/* default */.Z, null), list_jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-3"
  }, list_jsx("div", {
    className: "container"
  }, list_jsx("ol", {
    className: "breadcrumb"
  }, list_jsx("li", {
    className: "breadcrumb-item"
  }, list_jsx(ALink/* default */.Z, {
    href: "/"
  }, list_jsx(index_esm/* IoMdHome */.QO$, {
    style: {
      fontSize: "16px"
    }
  }))), query.category ? list_jsx((external_react_default()).Fragment, null, list_jsx("li", {
    className: "breadcrumb-item"
  }, list_jsx(ALink/* default */.Z, {
    href: "/shop",
    scroll: false
  }, "shop")), data && data.products.categoryFamily.map((item, index) => list_jsx("li", {
    className: "breadcrumb-item",
    key: `category-family-${index}`
  }, list_jsx(ALink/* default */.Z, {
    href: {
      query: {
        category: item.slug
      }
    },
    scroll: false
  }, item.name))), list_jsx("li", {
    className: "breadcrumb-item active"
  }, query.search ? list_jsx((external_react_default()).Fragment, null, "Search - ", list_jsx(ALink/* default */.Z, {
    href: {
      query: {
        category: query.category
      }
    },
    scroll: false
  }, query.category), " / ", query.search) : query.category)) : query.search ? list_jsx((external_react_default()).Fragment, null, list_jsx("li", {
    className: "breadcrumb-item"
  }, list_jsx(ALink/* default */.Z, {
    href: {
      pathname: router.pathname,
      query: {}
    },
    scroll: false
  }, "shop")), list_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, `Search - ${query.search}`)) : query.tag ? list_jsx((external_react_default()).Fragment, null, list_jsx("li", {
    className: "breadcrumb-item"
  }, list_jsx(ALink/* default */.Z, {
    href: {
      pathname: router.pathname,
      query: {}
    },
    scroll: false
  }, "shop")), list_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, `Product Tag - ${query.tag}`)) : list_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, "Shop")))), list_jsx("div", {
    className: "container pt-2"
  }, list_jsx("div", {
    className: "row"
  }, list_jsx("div", {
    className: "col-lg-9 main-content"
  }, list_jsx("nav", {
    className: "toolbox sticky-header mobile-sticky"
  }, list_jsx("div", {
    className: "toolbox-left"
  }, list_jsx("a", {
    href: "#",
    className: "sidebar-toggle",
    onClick: e => sidebarToggle(e)
  }, list_jsx("svg", {
    "data-name": "Layer 3",
    id: "Layer_3",
    viewBox: "0 0 32 32",
    xmlns: "http://www.w3.org/2000/svg"
  }, list_jsx("line", {
    x1: "15",
    x2: "26",
    y1: "9",
    y2: "9",
    className: "cls-1"
  }), list_jsx("line", {
    x1: "6",
    x2: "9",
    y1: "9",
    y2: "9",
    className: "cls-1"
  }), list_jsx("line", {
    x1: "23",
    x2: "26",
    y1: "16",
    y2: "16",
    className: "cls-1"
  }), list_jsx("line", {
    x1: "6",
    x2: "17",
    y1: "16",
    y2: "16",
    className: "cls-1"
  }), list_jsx("line", {
    x1: "17",
    x2: "26",
    y1: "23",
    y2: "23",
    className: "cls-1"
  }), list_jsx("line", {
    x1: "6",
    x2: "11",
    y1: "23",
    y2: "23",
    className: "cls-1"
  }), list_jsx("path", {
    d: "M14.5,8.92A2.6,2.6,0,0,1,12,11.5,2.6,2.6,0,0,1,9.5,8.92a2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  }), list_jsx("path", {
    d: "M22.5,15.92a2.5,2.5,0,1,1-5,0,2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  }), list_jsx("path", {
    d: "M21,16a1,1,0,1,1-2,0,1,1,0,0,1,2,0Z",
    className: "cls-3"
  }), list_jsx("path", {
    d: "M16.5,22.92A2.6,2.6,0,0,1,14,25.5a2.6,2.6,0,0,1-2.5-2.58,2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  })), list_jsx("span", null, "Filter")), list_jsx("div", {
    className: "toolbox-item toolbox-sort"
  }, list_jsx("label", null, "Sort By:"), list_jsx("div", {
    className: "select-custom"
  }, list_jsx("select", {
    name: "orderby",
    className: "form-control",
    value: sortBy,
    onChange: e => onSortByChange(e)
  }, list_jsx("option", {
    value: "default"
  }, "Default sorting"), list_jsx("option", {
    value: "popularity"
  }, "Sort by popularity"), list_jsx("option", {
    value: "rating"
  }, "Sort by average rating"), list_jsx("option", {
    value: "date"
  }, "Sort by newness"), list_jsx("option", {
    value: "price"
  }, "Sort by price: low to high"), list_jsx("option", {
    value: "price-desc"
  }, "Sort by price: high to low"))))), list_jsx("div", {
    className: "toolbox-right"
  }, list_jsx("div", {
    className: "toolbox-item toolbox-show"
  }, list_jsx("label", null, "Show:"), list_jsx("div", {
    className: "select-custom"
  }, list_jsx("select", {
    name: "count",
    className: "form-control",
    value: perPage,
    onChange: e => onPerPageChange(e)
  }, list_jsx("option", {
    value: "12"
  }, "12"), list_jsx("option", {
    value: "24"
  }, "24"), list_jsx("option", {
    value: "36"
  }, "36")))), list_jsx("div", {
    className: "toolbox-item layout-modes"
  }, list_jsx(ALink/* default */.Z, {
    href: {
      pathname: '/shop',
      query: query
    },
    className: "layout-btn btn-grid",
    title: "Grid"
  }, list_jsx("i", {
    className: "icon-mode-grid"
  })), list_jsx(ALink/* default */.Z, {
    href: {
      pathname: '/shop/list',
      query: query
    },
    className: "layout-btn btn-list active",
    title: "List"
  }, list_jsx("i", {
    className: "icon-mode-list"
  }))))), list_jsx(ProductsRow, {
    products: products,
    loading: loading,
    perPage: perPage
  }), loading || products && products.length ? list_jsx("nav", {
    className: "toolbox toolbox-pagination border-0"
  }, list_jsx("div", {
    className: "toolbox-item toolbox-show"
  }, list_jsx("label", null, "Show:"), list_jsx("div", {
    className: "select-custom"
  }, list_jsx("select", {
    name: "count",
    className: "form-control",
    value: perPage,
    onChange: e => onPerPageChange(e)
  }, list_jsx("option", {
    value: "12"
  }, "12"), list_jsx("option", {
    value: "24"
  }, "24"), list_jsx("option", {
    value: "36"
  }, "36")))), list_jsx(pagination/* default */.Z, {
    totalPage: totalPage
  })) : ''), list_jsx(shop_sidebar_one/* default */.ZP, null))), list_jsx("div", {
    className: "mb-xl-4 mb-0"
  }));
}

/* harmony default export */ var list = ((0,apollo/* default */.Z)({
  ssr: true
})(Shop));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 5768:
/***/ (function(module) {

"use strict";
module.exports = require("rc-tree");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 4766:
/***/ (function(module) {

"use strict";
module.exports = require("react-input-range");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 9058:
/***/ (function(module) {

"use strict";
module.exports = require("react-sticky-box");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,2806,5708,4229,2078,8816,101], function() { return __webpack_exec__(4013); });
module.exports = __webpack_exports__;

})();