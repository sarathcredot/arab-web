(function() {
var exports = {};
exports.id = 1461;
exports.ids = [1461];
exports.modules = {

/***/ 2025:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_common_ALink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8974);
/* harmony import */ var _components_partials_shop_shop_banner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5128);
/* harmony import */ var _components_partials_shop_sidebar_shop_sidebar_one__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(101);
/* harmony import */ var _components_features_pagination__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2078);
/* harmony import */ var _components_partials_products_collection_product_grid__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9066);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7164);
/* harmony import */ var _server_queries__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4733);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1649);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













function OffCanvas() {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const query = router.query;
  const [getProducts, {
    data,
    loading,
    error
  }] = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__.useLazyQuery)(_server_queries__WEBPACK_IMPORTED_MODULE_9__/* .GET_PRODUCTS */ .tT);
  const {
    0: perPage,
    1: setPerPage
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(12);
  const {
    0: sortBy,
    1: setSortBy
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(query.sortBy ? query.sortBy : 'default');
  const products = data && data.products.data;
  const totalPage = data ? parseInt(data.products.total / perPage) + (data.products.total % perPage ? 1 : 0) : 1;
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    let offset = document.querySelector('.main-content').getBoundingClientRect().top + window.pageYOffset - 58;
    setTimeout(() => {
      window.scrollTo({
        top: offset,
        behavior: 'smooth'
      });
    }, 200);
    let page = query.page ? query.page : 1;
    getProducts({
      variables: {
        search: query.search,
        colors: query.colors ? query.colors.split(',') : [],
        sizes: query.sizes ? query.sizes.split(',') : [],
        brands: query.brands ? query.brands.split(',') : [],
        min_price: parseInt(query.min_price),
        max_price: parseInt(query.max_price),
        category: query.category,
        tag: query.tag,
        sortBy: sortBy,
        from: perPage * (page - 1),
        to: perPage * page
      }
    });
  }, [query, perPage, sortBy]);

  function onPerPageChange(e) {
    setPerPage(e.target.value);
    router.push({
      pathname: router.pathname,
      query: _objectSpread(_objectSpread({}, query), {}, {
        page: 1
      })
    });
  }

  function onSortByChange(e) {
    router.push({
      pathname: router.pathname,
      query: _objectSpread(_objectSpread({}, query), {}, {
        sortBy: e.target.value,
        page: 1
      })
    });
    setSortBy(e.target.value);
  }

  function sidebarToggle(e) {
    let body = document.querySelector('body');
    e.preventDefault();

    if (body.classList.contains('sidebar-opened')) {
      body.classList.remove('sidebar-opened');
    } else {
      body.classList.add('sidebar-opened');
    }
  }

  if (error) {
    return __jsx("div", null, error.message);
  }

  return __jsx("main", {
    className: "main"
  }, __jsx(_components_partials_shop_shop_banner__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, null), __jsx("div", {
    className: "shop-off-canvas"
  }, __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-1"
  }, __jsx("div", {
    className: "container"
  }, __jsx("ol", {
    className: "breadcrumb"
  }, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: "/"
  }, __jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_10__/* .IoMdHome */ .QO$, {
    style: {
      fontSize: "16px"
    }
  }))), query.category ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: "/shop",
    scroll: false
  }, "shop")), data && data.products.categoryFamily.map((item, index) => __jsx("li", {
    className: "breadcrumb-item",
    key: `category-family-${index}`
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: {
      query: {
        category: item.slug
      }
    },
    scroll: false
  }, item.name))), __jsx("li", {
    className: "breadcrumb-item active"
  }, query.search ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Search - ", __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: {
      query: {
        category: query.category
      }
    },
    scroll: false
  }, query.category), " / ", query.search) : query.category)) : query.search ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: {
      pathname: router.pathname,
      query: {}
    },
    scroll: false
  }, "shop")), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, `Search - ${query.search}`)) : __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, "Shop")))), __jsx("div", {
    className: "container"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-12 main-content pt-3"
  }, __jsx("nav", {
    className: "toolbox sticky-header mobile-sticky mb-lg-2"
  }, __jsx("div", {
    className: "toolbox-left"
  }, __jsx("a", {
    href: "#",
    className: "sidebar-toggle d-inline-flex",
    onClick: e => sidebarToggle(e)
  }, __jsx("svg", {
    "data-name": "Layer 3",
    id: "Layer_3",
    viewBox: "0 0 32 32",
    xmlns: "http://www.w3.org/2000/svg"
  }, __jsx("line", {
    x1: "15",
    x2: "26",
    y1: "9",
    y2: "9",
    className: "cls-1"
  }), __jsx("line", {
    x1: "6",
    x2: "9",
    y1: "9",
    y2: "9",
    className: "cls-1"
  }), __jsx("line", {
    x1: "23",
    x2: "26",
    y1: "16",
    y2: "16",
    className: "cls-1"
  }), __jsx("line", {
    x1: "6",
    x2: "17",
    y1: "16",
    y2: "16",
    className: "cls-1"
  }), __jsx("line", {
    x1: "17",
    x2: "26",
    y1: "23",
    y2: "23",
    className: "cls-1"
  }), __jsx("line", {
    x1: "6",
    x2: "11",
    y1: "23",
    y2: "23",
    className: "cls-1"
  }), __jsx("path", {
    d: "M14.5,8.92A2.6,2.6,0,0,1,12,11.5,2.6,2.6,0,0,1,9.5,8.92a2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  }), __jsx("path", {
    d: "M22.5,15.92a2.5,2.5,0,1,1-5,0,2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  }), __jsx("path", {
    d: "M21,16a1,1,0,1,1-2,0,1,1,0,0,1,2,0Z",
    className: "cls-3"
  }), __jsx("path", {
    d: "M16.5,22.92A2.6,2.6,0,0,1,14,25.5a2.6,2.6,0,0,1-2.5-2.58,2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  })), __jsx("span", null, "Filter"))), __jsx("div", {
    className: "toolbox-right"
  }, __jsx("div", {
    className: "toolbox-item toolbox-sort mb-0"
  }, __jsx("label", null, "Sort By:"), __jsx("div", {
    className: "select-custom"
  }, __jsx("select", {
    name: "orderby",
    className: "form-control",
    value: sortBy,
    onChange: e => onSortByChange(e)
  }, __jsx("option", {
    value: "default"
  }, "Default sorting"), __jsx("option", {
    value: "popularity"
  }, "Sort by popularity"), __jsx("option", {
    value: "rating"
  }, "Sort by average rating"), __jsx("option", {
    value: "date"
  }, "Sort by newness"), __jsx("option", {
    value: "price"
  }, "Sort by price: low to high"), __jsx("option", {
    value: "price-desc"
  }, "Sort by price: high to low")))), __jsx("div", {
    className: "toolbox-item toolbox-show mb-0"
  }, __jsx("label", null, "Show:"), __jsx("div", {
    className: "select-custom"
  }, __jsx("select", {
    name: "count",
    className: "form-control",
    value: perPage,
    onChange: e => onPerPageChange(e)
  }, __jsx("option", {
    value: "12"
  }, "12"), __jsx("option", {
    value: "24"
  }, "24"), __jsx("option", {
    value: "36"
  }, "36")))), __jsx("div", {
    className: "toolbox-item layout-modes mb-0"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: {
      pathname: router.pathname,
      query: query
    },
    className: "layout-btn btn-grid active",
    title: "Grid"
  }, __jsx("i", {
    className: "icon-mode-grid"
  })), __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: {
      pathname: '/shop/list',
      query: query
    },
    className: "layout-btn btn-list",
    title: "List"
  }, __jsx("i", {
    className: "icon-mode-list"
  }))))), __jsx(_components_partials_products_collection_product_grid__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
    products: products,
    loading: loading,
    perPage: perPage,
    gridClass: "col-6 col-sm-4 col-md-3"
  }), loading || products && products.length ? __jsx("nav", {
    className: "toolbox toolbox-pagination border-0"
  }, __jsx("div", {
    className: "toolbox-item toolbox-show"
  }, __jsx("label", null, "Show:"), __jsx("div", {
    className: "select-custom"
  }, __jsx("select", {
    name: "count",
    className: "form-control",
    value: perPage,
    onChange: e => onPerPageChange(e)
  }, __jsx("option", {
    value: "12"
  }, "12"), __jsx("option", {
    value: "24"
  }, "24"), __jsx("option", {
    value: "36"
  }, "36")))), __jsx(_components_features_pagination__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
    totalPage: totalPage
  })) : ''), __jsx(_components_partials_shop_sidebar_shop_sidebar_one__WEBPACK_IMPORTED_MODULE_5__/* .default */ .ZP, null)))), __jsx("div", {
    className: "mb-xl-4 mb-0"
  }));
}

/* harmony default export */ __webpack_exports__["default"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)({
  ssr: true
})(OffCanvas));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 5768:
/***/ (function(module) {

"use strict";
module.exports = require("rc-tree");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 4766:
/***/ (function(module) {

"use strict";
module.exports = require("react-input-range");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 9058:
/***/ (function(module) {

"use strict";
module.exports = require("react-sticky-box");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,2806,5708,4229,4011,2078,8816,101,9066], function() { return __webpack_exec__(2025); });
module.exports = __webpack_exports__;

})();