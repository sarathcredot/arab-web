(function() {
var exports = {};
exports.id = 2197;
exports.ids = [2197];
exports.modules = {

/***/ 8125:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ PageNotFound; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_ALink__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8974);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1649);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);


function PageNotFound() {
  return __jsx("div", {
    className: "container"
  }, __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav"
  }, __jsx("ol", {
    className: "breadcrumb"
  }, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: "/"
  }, __jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_2__/* .IoMdHome */ .QO$, {
    style: {
      fontSize: "16px"
    }
  }))), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, "404"))), __jsx("section", {
    className: "http-error"
  }, __jsx("div", {
    className: "row justify-content-center py-3"
  }, __jsx("div", {
    className: "col-md-7 text-center"
  }, __jsx("div", {
    className: "http-error-main"
  }, __jsx("h2", null, "404", __jsx("i", {
    className: "fas fa-file ml-3"
  })), __jsx("p", null, "We're sorry, but the page you were looking for doesn't exist."))), __jsx("div", {
    className: "col-md-4 mt-4 mt-md-0"
  }, __jsx("h4", {
    className: "text-primary"
  }, "Here are some useful links"), __jsx("ul", {
    className: "nav nav-list"
  }, __jsx("li", {
    className: "nav-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    className: "nav-link",
    href: "/"
  }, "Home")), __jsx("li", {
    className: "nav-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    className: "nav-link",
    href: '/pages/about-us'
  }, "About Us")), __jsx("li", {
    className: "nav-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    className: "nav-link",
    href: "#"
  }, "FAQ's")), __jsx("li", {
    className: "nav-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    className: "nav-link",
    href: "#"
  }, "Sitemap")), __jsx("li", {
    className: "nav-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    className: "nav-link",
    href: "/pages/contact-us"
  }, "Contact Us")))))));
}

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285], function() { return __webpack_exec__(8125); });
module.exports = __webpack_exports__;

})();