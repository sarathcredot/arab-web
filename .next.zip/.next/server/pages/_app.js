(function() {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 5022:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _app; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-helmet"
var external_react_helmet_ = __webpack_require__(6481);
var external_react_helmet_default = /*#__PURE__*/__webpack_require__.n(external_react_helmet_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
;// CONCATENATED MODULE: external "redux-persist/integration/react"
var react_namespaceObject = require("redux-persist/integration/react");;
;// CONCATENATED MODULE: external "redux"
var external_redux_namespaceObject = require("redux");;
;// CONCATENATED MODULE: external "next-redux-wrapper"
var external_next_redux_wrapper_namespaceObject = require("next-redux-wrapper");;
;// CONCATENATED MODULE: external "redux-saga"
var external_redux_saga_namespaceObject = require("redux-saga");;
var external_redux_saga_default = /*#__PURE__*/__webpack_require__.n(external_redux_saga_namespaceObject);
// EXTERNAL MODULE: external "redux-saga/effects"
var effects_ = __webpack_require__(5060);
// EXTERNAL MODULE: ./store/cart.js
var cart = __webpack_require__(2806);
// EXTERNAL MODULE: ./store/wishlist.js
var wishlist = __webpack_require__(5708);
;// CONCATENATED MODULE: ./store/root-saga.js


 // notice how we now only export the rootSaga
// single entry point to start all Sagas at once

function* rootSaga() {
  yield (0,effects_.all)([(0,cart/* cartSaga */.xT)(), (0,wishlist/* wishlistSaga */.OP)()]);
}
// EXTERNAL MODULE: external "redux-persist"
var external_redux_persist_ = __webpack_require__(3643);
// EXTERNAL MODULE: ./store/modal.js
var modal = __webpack_require__(6723);
// EXTERNAL MODULE: external "redux-persist/lib/storage"
var storage_ = __webpack_require__(584);
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_);
;// CONCATENATED MODULE: ./store/demo.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const actionTypes = {
  RefreshStore: "REFRESH_STORE"
};
let initialState = {
  current: 0
};

const demoReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.RefreshStore:
      return _objectSpread(_objectSpread({}, state), {}, {
        current: action.payload.current
      });

    default:
      return state;
  }
};

const actions = {
  refreshStore: current => ({
    type: actionTypes.RefreshStore,
    payload: {
      current
    }
  })
};
const persistConfig = {
  keyPrefix: "porto-",
  key: "demo",
  storage: (storage_default())
};
/* harmony default export */ var demo = ((0,external_redux_persist_.persistReducer)(persistConfig, demoReducer));
;// CONCATENATED MODULE: ./store/index.js




 // Import Custom Component





const sagaMiddleware = external_redux_saga_default()();
const rootReducers = (0,external_redux_namespaceObject.combineReducers)({
  cartlist: cart/* default */.ZP,
  wishlist: wishlist/* default */.ZP,
  modal: modal/* default */.ZP,
  demo: demo
});
const makeStore = context => {
  const store = (0,external_redux_namespaceObject.createStore)(rootReducers, (0,external_redux_namespaceObject.applyMiddleware)(sagaMiddleware));
  store.sagaTask = sagaMiddleware.run(rootSaga);
  store.__persistor = (0,external_redux_persist_.persistStore)(store);
  return store;
};
const wrapper = (0,external_next_redux_wrapper_namespaceObject.createWrapper)(makeStore, {
  debug: false
});
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(2034);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.min.css
var ReactToastify_min = __webpack_require__(3326);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
;// CONCATENATED MODULE: ./components/common/partials/sticky-navbar.jsx

var __jsx = (external_react_default()).createElement;
 // Import Custom Component




function StickyNavbar({
  cartItems
}) {
  function getQtyTotal(items) {
    let total = 0;

    if (items) {
      for (let i = 0; i < items.length; i++) {
        total += parseInt(items[i].qty, 10);
      }
    }

    return total;
  }

  return __jsx("div", {
    className: "sticky-navbar",
    style: {
      display: "flex",
      justifyContent: "center"
    }
  }, __jsx("div", {
    className: "sticky-info"
  }, __jsx(ALink/* default */.Z, {
    href: "/"
  }, __jsx(index_esm/* IoIosAdd */.gyF, {
    style: {
      fontSize: "35px"
    }
  }), "Home")), __jsx("div", {
    className: "sticky-info"
  }, __jsx(ALink/* default */.Z, {
    href: "/pages/wishlist",
    className: ""
  }, __jsx("i", {
    className: "icon-wishlist-2"
  }), "Wishlist")), __jsx("div", {
    className: "sticky-info"
  }, __jsx(ALink/* default */.Z, {
    href: "/pages/login",
    className: ""
  }, __jsx("i", {
    className: "icon-user-2"
  }), "Account")), __jsx("div", {
    className: "sticky-info"
  }, __jsx(ALink/* default */.Z, {
    href: "/pages/cart",
    className: ""
  }, __jsx("i", {
    className: "icon-shopping-cart position-relative"
  }, __jsx("span", {
    className: "cart-count badge-circle"
  }, getQtyTotal(cartItems))), "Cart")));
}

function mapStateToProps(state) {
  return {
    cartItems: state.cartlist.cart ? state.cartlist.cart : []
  };
}

/* harmony default export */ var sticky_navbar = ((0,external_react_redux_.connect)(mapStateToProps, null)(StickyNavbar));
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./components/common/header.module.css
var header_module = __webpack_require__(6767);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
// EXTERNAL MODULE: ./node_modules/react-icons/ai/index.esm.js
var ai_index_esm = __webpack_require__(2821);
// EXTERNAL MODULE: ./utils/index.js
var utils = __webpack_require__(6442);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(8074);
;// CONCATENATED MODULE: ./components/common/partials/cart-menu.jsx
var cart_menu_jsx = (external_react_default()).createElement;



 // Import Actions


 // Import Custom Component


 // Import Utils




const GET_CART = client_.gql`
  query GetCart {
  getCart {
    products {
      _id
      productId
      quantity
      name
      shortDescription
      stock
      color
      size
      price
      image 
      sellingPrice
      mrp
    }
    grandTotal
    subTotal
    deliveryCharge
  }
}
`;
const REMOVE_CART = client_.gql`
  mutation RemoveFromCart($input: removeFromCartInput!) {
    removeFromCart(input: $input) {
      message
    }
  }
`;

function CartMenu({
  props
}) {
  // const { cartItems } = props;
  const {
    0: cartItems,
    1: setCartItems
  } = (0,external_react_.useState)([]);
  const router = (0,router_.useRouter)();
  const {
    0: toggle,
    1: setToggle
  } = (0,external_react_.useState)(false);
  const {
    0: localCart,
    1: setLocalCart
  } = (0,external_react_.useState)([]);
  (0,external_react_.useEffect)(() => {
    if (!token) {
      const storedLocalCart = localStorage.getItem("cart");

      if (storedLocalCart) {
        setLocalCart(JSON.parse(storedLocalCart));
      }
    }
  }, [token, toggle]);
  (0,external_react_.useEffect)(() => {
    router.events.on("routeChangeStart", cartClose);
    return () => {
      router.events.off("routeChangeStart", cartClose);
    };
  }, []);

  function toggleCart(e) {
    e.preventDefault();
    setToggle(!toggle);
    document.querySelector("body").classList.toggle("cart-opened");
  }

  function cartClose() {
    document.querySelector("body").classList.contains("cart-opened") && document.querySelector("body").classList.remove("cart-opened");
  }

  function getQtyTotal(items) {
    let total = 0;

    if (items) {
      for (let i = 0; i < items.length; i++) {
        total += parseInt(items[i].quantity, 10);
      }
    }

    return total;
  } // function removeFromCart(e, cart) {
  //   e.preventDefault();
  //   props.removeFromCart(cart);
  // }


  const [removeFromCart] = (0,client_.useMutation)(REMOVE_CART);
  const token = localStorage.getItem("arabtoken");

  const removeCart = async id => {
    try {
      if (token) {
        const response = await removeFromCart({
          variables: {
            input: {
              productId: id
            }
          }
        });
        cartRefetch();
        toast.success("Successfully removed product");
      }

      if (!token) {
        const storedCartItems = localStorage.getItem('cart');

        if (storedCartItems !== null) {
          const currentCartItems = JSON.parse(storedCartItems);
          const updatedCartItems = currentCartItems.filter(item => item.productId !== id);
          localStorage.setItem('cart', JSON.stringify(updatedCartItems));
          setCartItems(updatedCartItems);
        }
      }
    } catch (error) {// console.log(error);
    }
  };

  const {
    data: cartData,
    loading: cartLoading,
    error: cartError,
    refetch: cartRefetch
  } = (0,client_.useQuery)(GET_CART, {
    skip: !token
  }); // const added = eventEmmitter.addListener("productAdded",)

  (0,external_react_.useEffect)(() => {
    if (token) {
      if (cartError) {
        console.error("Error fetching cart data:", cartError);
      } else if (cartData) {
        setCartItems(cartData.getCart.products || []);
      }

      cartRefetch();
    } else {
      if (localCart && localCart.length > 0) {
        setCartItems(localCart);
      }
    }
  }, [token, cartData, cartError, cartRefetch, localCart, toggle]);
  const {
    0: cartCount,
    1: setCartCount
  } = (0,external_react_.useState)(0);
  (0,external_react_.useEffect)(() => {
    const count = localStorage.getItem('cart');

    if (count) {
      setCartCount(parseInt(count));
    }
  }, []);
  (0,external_react_.useEffect)(() => {
    const handleStorageChange = () => {
      const count = localStorage.getItem('cart');

      if (count) {
        setCartCount(parseInt(count.length));
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);
  return cart_menu_jsx("div", {
    className: "dropdown cart-dropdown"
  }, cart_menu_jsx("a", {
    href: "#",
    title: "Cart",
    className: "dropdown-toggle dropdown-arrow cart-toggle",
    onClick: toggleCart
  }, cart_menu_jsx("div", {
    className: (header_module_default()).circle
  }, cart_menu_jsx("img", {
    src: "/images/icon/cart.svg",
    alt: "cart"
  })), (cartItems === null || cartItems === void 0 ? void 0 : cartItems.length) > 0 && cart_menu_jsx("span", {
    className: "cart-count badge-circle"
  }, cartItems && (cartItems === null || cartItems === void 0 ? void 0 : cartItems.length))), cart_menu_jsx("div", {
    className: "cart-overlay",
    onClick: cartClose
  }), cart_menu_jsx("div", {
    className: "dropdown-menu mobile-cart"
  }, cart_menu_jsx("a", {
    href: "#",
    title: "Close (Esc)",
    className: "btn-close",
    onClick: e => {
      cartClose();
      e.preventDefault();
    }
  }, "\xD7"), cart_menu_jsx("div", {
    className: "dropdownmenu-wrapper"
  }, cart_menu_jsx("div", {
    style: {
      display: "flex"
    }
  }, cart_menu_jsx("div", {
    className: "dropdown-cart-header"
  }, "Shopping Cart"), cart_menu_jsx("a", {
    href: "#",
    title: "Close (Esc)",
    className: "btn-close",
    onClick: e => {
      cartClose();
      e.preventDefault();
    }
  }, "\xD7")), (cartItems === null || cartItems === void 0 ? void 0 : cartItems.length) > 0 ? cart_menu_jsx((external_react_default()).Fragment, null, cart_menu_jsx("div", {
    className: "dropdown-cart-products"
  }, cartItems === null || cartItems === void 0 ? void 0 : cartItems.map((cart, index) => {
    var _cart$sellingPrice;

    return cart_menu_jsx("div", {
      className: "product",
      key: "cartItems" + index
    }, cart_menu_jsx("div", {
      className: "product-details"
    }, cart_menu_jsx("h2", {
      className: "product-title"
    }, cart.index > -1 ? !cart.variants[cart.index].color ? cart_menu_jsx(ALink/* default */.Z, {
      href: `/product/default/${cart.slug}`
    }, cart.name + " - " + cart.variants[cart.index].size.name) : !cart.variants[cart.index].size ? cart_menu_jsx(ALink/* default */.Z, {
      href: `/product/default/${cart.slug}`
    }, cart.name + " - " + cart.variants[cart.index].color.name) : cart_menu_jsx(ALink/* default */.Z, {
      href: `/product/default/${cart.slug}`
    }, cart.name + " - " + cart.variants[cart.index].color.name + ", " + cart.variants[cart.index].size.name) : cart_menu_jsx(ALink/* default */.Z, {
      href: `/product/default/${cart._id}`
    }, cart.name)), cart_menu_jsx("span", {
      className: "cart-product-info"
    }, cart_menu_jsx("span", {
      className: "cart-product-qty"
    }, cart.quantity), " \xD7 OMR ", cart === null || cart === void 0 ? void 0 : (_cart$sellingPrice = cart.sellingPrice) === null || _cart$sellingPrice === void 0 ? void 0 : _cart$sellingPrice.toFixed(2))), cart_menu_jsx("figure", {
      className: "product-image-container"
    }, cart_menu_jsx(ALink/* default */.Z, {
      href: `/product/default/${cart.slug}`,
      className: "product-image"
    }, cart_menu_jsx("img", {
      src: cart === null || cart === void 0 ? void 0 : cart.image,
      width: "78",
      height: "78",
      alt: "product"
    })), cart_menu_jsx("div", {
      title: "Remove Product",
      style: {
        width: "20px",
        height: "20px",
        position: "absolute",
        top: "-7px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        right: "-5px",
        borderRadius: "50%",
        // background: "black",
        filter: "drop-shadow(1px 1px 6px rgba(0, 0, 0, 0.11))"
      },
      className: "hoverinto",
      onClick: e => {
        e.preventDefault();
        removeCart(cart.productId, index);
      }
    }, cart_menu_jsx(ai_index_esm/* AiOutlineClose */.oHP, {
      style: {
        fontSize: "10px"
      }
    }))));
  })), cart_menu_jsx("div", {
    className: "dropdown-cart-total"
  }, cart_menu_jsx("span", null, "SUBTOTAL:"), cart_menu_jsx("span", {
    className: "cart-total-price float-right"
  }, "OMR ", (0,utils/* getCartTotal */.I3)(cartItems).toFixed(2))), cart_menu_jsx("div", {
    className: "dropdown-cart-action"
  }, cart_menu_jsx(ALink/* default */.Z, {
    href: "/pages/cart",
    className: "btn btn-block view-cart hoverbtn",
    style: {
      border: "1px solid #000",
      background: "white"
    }
  }, "View Cart"), localStorage.getItem("arabtoken") && cart_menu_jsx("div", {
    href: "/pages/checkout",
    className: "btn btn-dark btn-block text-white hoverbtn",
    onClick: () => router.push("/pages/checkout")
  }, "Checkout"))) : cart_menu_jsx("p", {
    className: "pt-3 mt-2"
  }, "No products in the cart."))));
}

function cart_menu_mapStateToProps(state) {
  return {
    cartItems: state.cartlist.cart ? state.cartlist.cart : []
  };
}

/* harmony default export */ var cart_menu = ((0,apollo/* default */.Z)({
  ssr: true
})((0,external_react_redux_.connect)(cart_menu_mapStateToProps, cart/* actions */.Nw)(CartMenu)));
// EXTERNAL MODULE: ./components/common/partials/main-menu.jsx
var main_menu = __webpack_require__(980);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: external "react-lazy-load-image-component"
var external_react_lazy_load_image_component_ = __webpack_require__(9290);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
// EXTERNAL MODULE: external "react-hook-form"
var external_react_hook_form_ = __webpack_require__(2662);
;// CONCATENATED MODULE: ./components/common/partials/search-form.jsx
var search_form_jsx = (external_react_default()).createElement;



 // Import Custom Component

 // Import Apollo Server and Query






const GET_PRODUCTS_AUTOCOMPLETE = client_.gql`
  query GetProductsAutoComplete($input: GetProductsAutoCompleteInput!) {
    getProductsAutoComplete(input: $input) {
      suggestions {
        suggestion
        image
        categoryId
        categoryIdPath
      }
    }
  }
`;

function SearchForm(props) {
  const router = (0,router_.useRouter)();
  const {
    0: cat,
    1: setCat
  } = (0,external_react_.useState)("");
  const {
    0: search,
    1: setSearch
  } = (0,external_react_.useState)("");
  const {
    0: options,
    1: setOptions
  } = (0,external_react_.useState)([]);
  const [getProductsAutoComplete, {
    data
  }] = (0,react_hooks_.useLazyQuery)(GET_PRODUCTS_AUTOCOMPLETE);
  (0,external_react_.useEffect)(() => {
    document.querySelector("body").addEventListener("click", onBodyClick);
    return () => {
      document.querySelector("body").removeEventListener("click", onBodyClick);
    };
  }, []);
  (0,external_react_.useEffect)(() => {
    setSearch("");
    setCat("");
  }, [router.query.slug]);
  (0,external_react_.useEffect)(() => {
    document.querySelector(".header-search.show-results") && document.querySelector(".header-search.show-results").classList.remove("show-results");
  }, [router.pathname]);

  function removeXSSAttacks(html) {
    const SCRIPT_REGEX = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi; // Removing the <script> tags

    while (SCRIPT_REGEX.test(html)) {
      html = html.replace(SCRIPT_REGEX, "");
    } // Removing all events from tags...


    html = html.replace(/ on\w+="[^"]*"/g, "");
    return {
      __html: html
    };
  }

  function matchEmphasize(name) {
    let regExp = new RegExp(search, "i");
    return name.replace(regExp, match => "<strong>" + match + "</strong>");
  }

  function onSearchClick(e) {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.parentNode.classList.toggle("show");
  }

  function onBodyClick(e) {
    if (e.target.closest(".header-search")) return e.target.closest(".header-search").classList.contains("show-results") || e.target.closest(".header-search").classList.add("show-results");
    document.querySelector(".header-search.show") && document.querySelector(".header-search.show").classList.remove("show");
    document.querySelector(".header-search.show-results") && document.querySelector(".header-search.show-results").classList.remove("show-results");
  }

  function onCatSelect(e) {
    setCat(e.target.value);
  }

  function onSubmitSearchForm(e) {
    e.preventDefault();
    router.push({
      pathname: "/shop",
      query: {
        search: search,
        cat_id: cat
      }
    });
  }

  const onSearchChange = e => {
    const searchText = e.target.value;
    setSearch(searchText);

    if (searchText.length > 2) {
      getProductsAutoComplete({
        variables: {
          input: {
            query: searchText
          }
        }
      });
    } else {
      setOptions([]);
    }
  };

  (0,external_react_.useEffect)(() => {
    if (data && data.getProductsAutoComplete && data.getProductsAutoComplete.suggestions) {
      setOptions(data.getProductsAutoComplete.suggestions);

      if (data.getProductsAutoComplete.suggestions.length > 0) {
        setCat(data.getProductsAutoComplete.suggestions[0].categoryIdPath.split("#")[data.getProductsAutoComplete.suggestions[0].categoryIdPath.split("#").length - 1]);
      }
    }
  }, [data]);
  return search_form_jsx("div", {
    className: "header-icon header-search header-search-inline header-search-category w-lg-max text-right mb-0 d-sm-block d-none"
  }, search_form_jsx("a", {
    href: "#",
    className: "search-toggle",
    role: "button",
    onClick: onSearchClick
  }, search_form_jsx("i", {
    className: "icon-search-3"
  })), search_form_jsx("form", {
    action: "#",
    method: "get",
    onSubmit: e => onSubmitSearchForm(e)
  }, search_form_jsx("div", {
    className: "header-search-wrapper"
  }, search_form_jsx("input", {
    type: "search",
    className: "form-control",
    name: "q",
    id: `${props.type === 1 ? "q" : "qqq"}`,
    placeholder: "What are you looking for?",
    value: search,
    required: true,
    onChange: e => onSearchChange(e)
  }), search_form_jsx("button", {
    className: "btn",
    title: "search",
    type: "submit"
  }, search_form_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "17",
    height: "16",
    viewBox: "0 0 17 16",
    fill: "none"
  }, search_form_jsx("path", {
    d: "M8.18551 14C11.5138 14 14.2118 11.1645 14.2118 7.66668C14.2118 4.16887 11.5138 1.33334 8.18551 1.33334C4.85726 1.33334 2.15918 4.16887 2.15918 7.66668C2.15918 11.1645 4.85726 14 8.18551 14Z",
    stroke: "white",
    "stroke-linecap": "round",
    "stroke-linejoin": "round"
  }), search_form_jsx("path", {
    d: "M14.8463 14.6667L13.5776 13.3333",
    stroke: "white",
    "stroke-linecap": "round",
    "stroke-linejoin": "round"
  }))), search_form_jsx("div", {
    className: "live-search-list bg-white"
  }, options.length > 0 && search.length > 2 && options.map((product, index) => search_form_jsx("div", {
    // href={`/shop?page=0&category=${product.categoryId}`}
    className: "autocomplete-suggestion",
    key: `search-result-${index}`,
    style: {
      borderBottom: '0px',
      cursor: "pointer"
    } // use onCLick instead of href and setSearch null 
    ,
    onClick: () => {
      setSearch("");
      setOptions([]);
      router.push({
        pathname: "/shop",
        query: {
          search: product.suggestion,
          cat_id: product.categoryId
        }
      });
    }
  }, search_form_jsx(external_react_lazy_load_image_component_.LazyLoadImage, {
    src: product.image ? product.image : "images/icon/search.svg",
    width: 40,
    height: 40,
    alt: ""
  }), search_form_jsx("div", {
    className: "search-name",
    dangerouslySetInnerHTML: removeXSSAttacks(matchEmphasize(product.suggestion))
  })))))));
}

/* harmony default export */ var search_form = ((0,apollo/* default */.Z)({
  ssr: true
})(SearchForm));
// EXTERNAL MODULE: ./node_modules/react-icons/bi/index.esm.js
var bi_index_esm = __webpack_require__(7516);
;// CONCATENATED MODULE: ./components/common/header.jsx
var header_jsx = (external_react_default()).createElement;

 // Import Actions

 // Import Custom Component








 // import offer from "../../public/images/ticket-discount.svg";




const GET_WISH_LIST = client_.gql`query Products {
  getWishListProducts {
    products {
      image
      productId
      productName
      sellingPrice
      shortDescription
    }
  }
}`;
const LOG_OUT_USER = client_.gql`mutation LogoutUser {
  logoutUser {
    _id
  }
}
`;

function Header({
  adClass = "",
  wishlist
}) {
  // get current path
  const {
    pathname
  } = (0,router_.useRouter)();

  function openMobileMenu(e) {
    e.preventDefault();
    document.querySelector("body").classList.toggle("mmenu-active");
    e.currentTarget.classList.toggle("active");
  }

  const [logout, {
    loading,
    error
  }] = (0,client_.useMutation)(LOG_OUT_USER);
  const router = (0,router_.useRouter)();

  const handleLog = () => {
    // console.log("click");
    if (localStorage.getItem("arabtoken")) {
      // console.log("ccc");
      router.push("/pages/account");
    } else {
      router.push("/pages/login");
    }
  };

  const token = localStorage.getItem("arabtoken");
  const {
    data: wishListData,
    loading: wishListLoading,
    error: wishListError,
    refetch: wishListRefetch
  } = (0,react_hooks_.useQuery)(GET_WISH_LIST, {
    skip: !token
  });
  const {
    0: showDropdown,
    1: setShowDropdown
  } = (0,external_react_.useState)(false);

  const handleToggleDropdown = () => {
    setShowDropdown(prevState => !prevState);
  }; // <div className="header-top">
  //   {/* <div className="container">
  //     <div className="header-left d-none d-sm-block">
  //       <div className="info-box info-box-icon-left text-primary justify-content-start p-0">
  //         <i className="icon-shipping"></i>
  //         <div className="info-box-content">
  //           <h4 className="text-transform-none">
  //             FREE Express Shipping On Orders $99+
  //           </h4>
  //         </div>
  //       </div>
  //     </div>
  //     <div className="header-right header-dropdowns ml-0 ml-sm-auto w-sm-100">
  //       <div className="header-dropdown">
  //         <ALink href="#">USD</ALink>
  //         <div className="header-menu">
  //           <ul>
  //             <li>
  //               <ALink href="#">EUR</ALink>
  //             </li>
  //             <li>
  //               <ALink href="#">USD</ALink>
  //             </li>
  //           </ul>
  //         </div>
  //       </div>
  //       <div className="header-dropdown mr-auto mr-sm-3 mr-md-0">
  //         <ALink href="#">
  //           <i className="flag-us flag"></i>ENG
  //         </ALink>
  //         <div className="header-menu">
  //           <ul>
  //             <li>
  //               <ALink href="#">
  //                 <i className="flag-us flag mr-2"></i>ENG
  //               </ALink>
  //             </li>
  //             <li>
  //               <ALink href="#">
  //                 <i className="flag-fr flag mr-2"></i>FRA
  //               </ALink>
  //             </li>
  //           </ul>
  //         </div>
  //       </div>
  //       <div className="header-dropdown dropdown-expanded d-none d-lg-block">
  //         <ALink href="#">Links</ALink>
  //         <div className="header-menu">
  //           <ul>
  //             <li>
  //               <ALink href="/pages/account">My account</ALink>
  //             </li>
  //             <li>
  //               <ALink href="/pages/cart">Cart</ALink>
  //             </li>
  //             <li>
  //               <ALink href="/pages/login" className="login-link">
  //                 Log In
  //               </ALink>
  //             </li>
  //           </ul>
  //         </div>
  //       </div>
  //       <div className="social-icons">
  //         <ALink
  //           href="#"
  //           className="social-icon social-facebook icon-facebook"
  //         ></ALink>
  //         <ALink
  //           href="#"
  //           className="social-icon social-twitter icon-twitter"
  //         ></ALink>
  //         <ALink
  //           href="#"
  //           className="social-icon social-instagram icon-instagram"
  //         ></ALink>
  //       </div>
  //     </div>
  //   </div> */}
  // </div>


  const handleLogout = async () => {
    try {
      localStorage.clear();
      await logout();
      router.push('/pages/login');
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  return header_jsx((external_react_default()).Fragment, null, header_jsx("header", {
    className: `header ${adClass} sticky-header mobile-sticky desktop-sticky`
  }, header_jsx("div", {
    className: "header-middle",
    style: {
      paddingTop: "3rem",
      paddingBottom: "3rem"
    }
  }, header_jsx("div", {
    className: "container innercontainer"
  }, header_jsx("div", {
    className: "header-left col-lg-2 w-auto pl-0"
  }, pathname !== "/pages/login" && header_jsx("button", {
    className: "mobile-menu-toggler mr-2",
    type: "button",
    onClick: openMobileMenu
  }, header_jsx("i", {
    className: "fa fa-bars"
  })), header_jsx(ALink/* default */.Z, {
    href: "/",
    className: "logo"
  }, header_jsx("img", {
    src: "images/ArabDeal.png",
    className: "w-100",
    width: "111",
    height: "44",
    alt: "Porto Logo"
  }))), header_jsx("div", {
    className: "header-right w-lg-max"
  }, header_jsx(search_form, null), header_jsx("div", {
    className: `d-flex justify-content-center align-items-center ${(header_module_default()).offerdiv}`
  }, header_jsx(ALink/* default */.Z, {
    href: "/pages/offers",
    className: "logo"
  }, header_jsx("img", {
    src: "images/ticket-discount.svg",
    alt: "Offer",
    width: "30",
    height: "30",
    style: {
      marginRight: "8px"
    }
  })), header_jsx("span", null, "OFFERZONE")), header_jsx("div", {
    className: "header-dropdown-hide"
  }, header_jsx("div", {
    className: "header-dropdown mr-auto mr-sm-3 mr-md-2 d-sm-none d-md-flex",
    style: {
      background: "rgba(249, 249, 249, 1)"
    }
  }, header_jsx(ALink/* default */.Z, {
    href: "#"
  }, header_jsx("img", {
    src: "/images/omn.svg",
    className: (header_module_default()).flagimg
  }), "OMN"))), header_jsx("div", {
    className: "header-dropdown-hide"
  }, header_jsx("div", {
    className: "header-dropdown mr-auto mr-sm-3 mr-md-0 d-sm-none d-md-flex",
    style: {
      background: "rgba(249, 249, 249, 1)",
      padding: "11px 0px"
    }
  }, header_jsx(ALink/* default */.Z, {
    href: "#"
  }, header_jsx("img", {
    src: "/images/icon/language.svg",
    style: {
      width: "15px",
      height: "15px"
    }
  }), header_jsx("span", {
    style: {
      padding: "0px 5px",
      borderLeft: "1px solid #EBEBEB"
    }
  }, " English")))), !token ? header_jsx("div", {
    className: "header-user custom_userborder header-icon"
  }, header_jsx("div", {
    className: (header_module_default()).circle,
    onClick: handleLog
  }, header_jsx(bi_index_esm/* BiSolidUser */.qyE, {
    style: {
      fontSize: "20px"
    }
  }))) : header_jsx("div", {
    className: "header-dropdown  custom_userborder header-icon" // style={{ marginLeft:"20px"}}

  }, header_jsx("div", {
    className: (header_module_default()).circle
  }, header_jsx(bi_index_esm/* BiSolidUser */.qyE, {
    style: {
      fontSize: "20px"
    }
  })), header_jsx("div", {
    className: "header-menu"
  }, header_jsx("ul", null, header_jsx("li", null, header_jsx(ALink/* default */.Z, {
    href: "/pages/account"
  }, header_jsx("img", {
    src: "images/icon/vuesax/bold/frame.svg",
    style: {
      width: "25px",
      height: "25px"
    }
  }), "My Account")), header_jsx("li", {
    onClick: handleLogout
  }, header_jsx(ALink/* default */.Z, {
    href: "#"
  }, header_jsx("img", {
    src: "images/icon/vuesax/bold/key.svg",
    className: (header_module_default()).flagimg
  }), "Log Out"))))), token && header_jsx(ALink/* default */.Z, {
    href: "/pages/wishlist",
    className: "header-icon position-relative",
    title: "wishlist"
  }, header_jsx("div", {
    className: (header_module_default()).circle
  }, header_jsx(ai_index_esm/* AiFillHeart */.M_L, {
    style: {
      fontSize: "20px"
    }
  })), header_jsx("span", {
    className: "wishlist-count badge-circle"
  }, wishListData === null || wishListData === void 0 ? void 0 : wishListData.getWishListProducts.products.length)), header_jsx(cart_menu, null))))));
}

const header_mapStateToProps = state => {
  return {
    wishlist: state.wishlist.list ? state.wishlist.list : []
  };
};

/* harmony default export */ var header = ((0,apollo/* default */.Z)({
  ssr: true
})((0,external_react_redux_.connect)(header_mapStateToProps, wishlist/* actions */.Nw)(Header)));
// EXTERNAL MODULE: ./node_modules/react-icons/fa6/index.esm.js
var fa6_index_esm = __webpack_require__(231);
// EXTERNAL MODULE: ./node_modules/react-icons/ri/index.esm.js
var ri_index_esm = __webpack_require__(9352);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var fa_index_esm = __webpack_require__(9583);
;// CONCATENATED MODULE: ./components/common/footer.jsx
var footer_jsx = (external_react_default()).createElement;









const GET_ALL_CATEGORY = client_.gql`
  query GetAllChildCategories($input: GetAllChildLevelCategoriesInput!) {
    getAllChildCategories(input: $input) {
      records {
        categoryName
        _id
        isBlocked
        fullCategoryName
        isLeaf
        description
      }
    } 
  }
`;
const GET_ALL_BRANDS = client_.gql`query GetAllTopBrandRecords($input: BrandRecordsFilter) {
  getAllTopBrandRecords(input: $input) {
    maxRecords
    message
    records {
      brandName
      _id
    }
  }
}`;

function Footer() {
  const token = localStorage.getItem("arabtoken");
  const {
    0: categories,
    1: setCategories
  } = (0,external_react_.useState)([]);
  const {
    0: brands,
    1: setBrands
  } = (0,external_react_.useState)([]);
  const {
    data: categoryData
  } = (0,react_hooks_.useQuery)(GET_ALL_CATEGORY, {
    variables: {
      input: {
        parent: null
      }
    }
  });
  const {
    data: brndData
  } = (0,react_hooks_.useQuery)(GET_ALL_BRANDS); // const router = useRouter();
  // const handleLog = () => {
  //   console.log("click");
  //   if (localStorage.getItem("arabtoken")) {
  //     console.log("ccc");
  //     router.push("/pages/account");
  //   }
  //   else {
  //     router.push("/pages/login");
  //   }
  // };

  (0,external_react_.useEffect)(() => {
    if (categoryData && categoryData.getAllChildCategories && categoryData.getAllChildCategories.records) {
      // remove default category 
      const filteredCategories = categoryData.getAllChildCategories.records.filter(category => {
        var _category$categoryNam;

        return ((_category$categoryNam = category.categoryName) === null || _category$categoryNam === void 0 ? void 0 : _category$categoryNam.toLowerCase()) !== "default";
      });
      setCategories(filteredCategories.slice(0, 6));
    }

    if (brndData && brndData.getAllTopBrandRecords && brndData.getAllTopBrandRecords.records) {
      setBrands(brndData.getAllTopBrandRecords.records);
    }
  }, [categoryData, brndData]);
  return footer_jsx((external_react_default()).Fragment, null, footer_jsx("footer", {
    className: "footer font2"
  }, footer_jsx("div", {
    className: "container"
  }, footer_jsx("div", {
    className: "footer-top",
    style: {
      padding: "60px 0"
    }
  }, footer_jsx("div", {
    className: "row"
  }, footer_jsx("div", {
    className: "col-md-6 col-lg-3"
  }, footer_jsx("div", {
    className: "widget"
  }, footer_jsx("h3", {
    className: "widget-title"
  }, "IMPORTANT LINKS"), footer_jsx("div", {
    className: "widget-content"
  }, footer_jsx("ul", null, footer_jsx("li", null, footer_jsx(ALink/* default */.Z, {
    href: "#"
  }, "Privacy& Policy")), footer_jsx("li", null, footer_jsx(ALink/* default */.Z, {
    href: token ? "/pages/orders" : "#"
  }, "Orders")), footer_jsx("li", null, footer_jsx(ALink/* default */.Z, {
    href: "#"
  }, "Become a seller")), footer_jsx("li", null, footer_jsx(ALink/* default */.Z, {
    href: "/pages/login"
  }, "Login")))))), footer_jsx("div", {
    className: "col-md-6 col-lg-3"
  }, footer_jsx("div", {
    className: "widget"
  }, footer_jsx("h3", {
    className: "widget-title"
  }, "More Information"), footer_jsx("div", {
    className: "widget-content"
  }, footer_jsx("ul", null, footer_jsx("li", null, footer_jsx(ALink/* default */.Z, {
    href: token ? "/pages/account" : "/pages/login"
  }, "My Profile")), footer_jsx("li", null, footer_jsx(ALink/* default */.Z, {
    href: token ? "/pages/wishlist" : "/pages/login"
  }, "whislist")), footer_jsx("li", null, footer_jsx(ALink/* default */.Z, {
    href: "/pages/cart"
  }, "Cart")), footer_jsx("li", null, footer_jsx(ALink/* default */.Z, {
    href: "/pages/offers"
  }, "OfferZone")))))), footer_jsx("div", {
    className: "col-md-6 col-lg-3"
  }, footer_jsx("div", {
    className: "widget"
  }, footer_jsx("h3", {
    className: "widget-title"
  }, "Social Media"), footer_jsx("div", {
    className: "widget-content"
  }, footer_jsx("div", {
    className: "social-icons",
    style: {
      display: "flex",
      gap: "20px"
    }
  }, footer_jsx(ALink/* default */.Z, {
    href: "#",
    className: "social-icon social-facebook icon-facebook",
    title: "Facebook"
  }), footer_jsx("div", {
    className: "twitter-cus-icon",
    style: {
      width: "40px",
      height: "40px"
    }
  }, " ", footer_jsx(fa6_index_esm/* FaXTwitter */.LCd, {
    className: "twitter-color"
  })), footer_jsx("div", {
    className: "twitter-cus-icon",
    style: {
      width: "40px",
      height: "40px"
    }
  }, " ", footer_jsx(fa_index_esm/* FaLinkedinIn */.BUd, {
    className: "twitter-color"
  })), footer_jsx("div", {
    className: "twitter-cus-icon",
    style: {
      width: "40px",
      height: "40px"
    }
  }, " ", footer_jsx(ai_index_esm/* AiFillYoutube */.b1v, {
    className: "twitter-color"
  }))))), footer_jsx("h3", {
    className: "widget-title",
    style: {
      marginTop: "60px"
    }
  }, "PAYMENT METHODS"), footer_jsx("div", null, footer_jsx("div", {
    className: "custom-pay",
    style: {
      display: "flex",
      gap: "10px"
    }
  }, footer_jsx(ALink/* default */.Z, {
    href: "#"
  }, footer_jsx("img", {
    src: "/images/visa.svg"
  })), footer_jsx(ALink/* default */.Z, {
    href: "#"
  }, footer_jsx("img", {
    src: "/images/paypal.svg"
  })), footer_jsx(ALink/* default */.Z, {
    href: "#"
  }, footer_jsx("img", {
    src: "/images/stripe.svg"
  })), footer_jsx(ALink/* default */.Z, {
    href: "#"
  }, footer_jsx("img", {
    src: "/images/verisign.svg"
  }))))))), footer_jsx("div", {
    className: "responsive-footer",
    style: {
      marginTop: "56px"
    }
  }, footer_jsx("div", {
    className: "col-md-12 offset-lg-1 col-lg-3 custom-helpline"
  }, footer_jsx("img", {
    src: "images/helpline.svg",
    style: {
      width: "30px"
    }
  }), footer_jsx("p", {
    style: {
      color: "rgba(27, 27, 27, 1)"
    }
  }, "Helpline"), footer_jsx("h4", null, "1800 456 84788")), footer_jsx("div", {
    className: "footer-flexcolumns"
  }, footer_jsx("div", {
    className: "footer-sub"
  }, footer_jsx("h6", {
    style: {
      letterSpacing: "0.75px"
    }
  }, "IMPORTANT LINKS"), footer_jsx("span", null, "Privacy & Policy"), footer_jsx("span", null, "Become a Seller"), footer_jsx("span", null, "Orders")), footer_jsx("div", {
    className: "footer-sub"
  }, footer_jsx("h6", {
    style: {
      letterSpacing: "0.75px"
    }
  }, "ABOUT US"), footer_jsx("span", null, "About us"), footer_jsx("span", null, "Careers"), footer_jsx("span", null, "Our Stores"), footer_jsx("span", null, "Sales"), footer_jsx("span", null, "Rhoncus"))), footer_jsx("div", {
    className: "footer-socialdiv"
  }, footer_jsx("h6", null, "SOCIAL MEDIA"), footer_jsx("div", {
    className: "footer-socialmedia"
  }, footer_jsx("div", {
    className: "social-circle"
  }, footer_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "19",
    height: "19",
    viewBox: "0 0 19 19",
    fill: "none"
  }, footer_jsx("path", {
    d: "M11.7577 4.67167H13.1165V2.3733C12.4586 2.30489 11.7976 2.27112 11.1361 2.27212C9.17024 2.27212 7.82592 3.47189 7.82592 5.66907V7.56269H5.60706V10.1357H7.82592V16.7272H10.4857V10.1357H12.6973L13.0298 7.56269H10.4857V5.92204C10.4857 5.16314 10.688 4.67167 11.7577 4.67167Z",
    fill: "#121212"
  }))), footer_jsx("div", {
    className: "social-circle"
  }, footer_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "18",
    height: "19",
    viewBox: "0 0 18 19",
    fill: "none"
  }, footer_jsx("rect", {
    x: "0.598267",
    y: "0.82666",
    width: "17.3462",
    height: "17.3462",
    rx: "8.67308",
    fill: "#E9E9E9"
  }), footer_jsx("path", {
    d: "M16.499 5.0187C15.9557 5.25438 15.3812 5.41019 14.7932 5.48126C15.4135 5.11072 15.8783 4.52779 16.1014 3.8406C15.5186 4.18757 14.8805 4.43203 14.215 4.56336C13.7702 4.08097 13.1779 3.75987 12.5309 3.65041C11.8839 3.54095 11.2189 3.64933 10.6401 3.95855C10.0614 4.26777 9.60164 4.76033 9.33299 5.359C9.06435 5.95766 9.00201 6.62856 9.15575 7.26647C7.97724 7.20686 6.82445 6.9 5.77227 6.36581C4.72009 5.83163 3.79206 5.08208 3.04845 4.16584C2.78764 4.6213 2.65059 5.1371 2.65094 5.66195C2.65001 6.14936 2.76963 6.62944 2.99913 7.05944C3.22863 7.48945 3.5609 7.85603 3.96635 8.12655C3.4951 8.11373 3.03392 7.98727 2.62203 7.75794V7.79408C2.62556 8.47701 2.86487 9.13775 3.29948 9.66455C3.73409 10.1913 4.33731 10.5519 5.00712 10.6851C4.74928 10.7636 4.48159 10.8049 4.21209 10.808C4.02554 10.8058 3.83946 10.7889 3.65557 10.7574C3.84631 11.3448 4.21543 11.8582 4.71157 12.2261C5.20771 12.594 5.80619 12.7981 6.42373 12.81C5.38094 13.6305 4.09348 14.0783 2.76658 14.0821C2.52499 14.0829 2.28359 14.0684 2.04382 14.0387C3.39858 14.9134 4.97736 15.3778 6.58996 15.3758C7.70278 15.3873 8.80675 15.177 9.83739 14.7572C10.868 14.3373 11.8047 13.7163 12.5926 12.9303C13.3805 12.1444 14.004 11.2094 14.4265 10.1798C14.849 9.15027 15.0621 8.04685 15.0534 6.934C15.0534 6.81113 15.0534 6.68103 15.0534 6.55094C15.6206 6.12799 16.1097 5.60949 16.499 5.0187Z",
    fill: "#121212"
  }))), footer_jsx("div", {
    className: "social-circle"
  }, footer_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "16",
    height: "15",
    viewBox: "0 0 16 15",
    fill: "none"
  }, footer_jsx("g", {
    "clip-path": "url(#clip0_198_9113)"
  }, footer_jsx("rect", {
    width: "14.8094",
    height: "14.1923",
    transform: "translate(0.946411 0.403931)",
    fill: "#E9E9E9"
  }), footer_jsx("path", {
    d: "M0.946411 2.05265C0.946411 1.57479 1.11319 1.18056 1.44673 0.869961C1.78027 0.559351 2.21388 0.404053 2.74755 0.404053C3.2717 0.404053 3.69576 0.556957 4.01978 0.862793C4.35332 1.17818 4.5201 1.58912 4.5201 2.09566C4.5201 2.5544 4.3581 2.93667 4.03408 3.24251C3.70054 3.55789 3.26216 3.71559 2.71896 3.71559H2.70467C2.18052 3.71559 1.75645 3.55789 1.43243 3.24251C1.10841 2.92713 0.946411 2.5305 0.946411 2.05265ZM1.13224 14.5963V5.02013H4.30568V14.5963H1.13224ZM6.06393 14.5963H9.23737V9.24914C9.23737 8.91463 9.27549 8.65659 9.35173 8.47502C9.48514 8.15007 9.68765 7.8753 9.95925 7.65072C10.2309 7.42612 10.5715 7.31383 10.9813 7.31383C12.0487 7.31383 12.5823 8.03539 12.5823 9.47851V14.5963H15.7558V9.10579C15.7558 7.69133 15.4222 6.61855 14.7551 5.88743C14.088 5.15632 13.2065 4.79076 12.1106 4.79076C10.8813 4.79076 9.92352 5.32118 9.23737 6.38201V6.41069H9.22307L9.23737 6.38201V5.02013H6.06393C6.08299 5.32595 6.09252 6.27688 6.09252 7.87292C6.09252 9.46895 6.08299 11.7101 6.06393 14.5963Z",
    fill: "#121212"
  })), footer_jsx("defs", null, footer_jsx("clipPath", {
    id: "clip0_198_9113"
  }, footer_jsx("rect", {
    width: "14.8094",
    height: "14.1923",
    fill: "white",
    transform: "translate(0.946411 0.403931)"
  }))))), footer_jsx("div", {
    className: "social-circle"
  }, footer_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "18",
    height: "19",
    viewBox: "0 0 18 19",
    fill: "none"
  }, footer_jsx("g", {
    "clip-path": "url(#clip0_198_9118)"
  }, footer_jsx("rect", {
    x: "0.139404",
    y: "0.82666",
    width: "17.3462",
    height: "17.3462",
    rx: "8.67308",
    fill: "#E9E9E9"
  }), footer_jsx("path", {
    d: "M16.7628 7.84466C16.7986 6.81014 16.5723 5.78337 16.1051 4.85967C15.7881 4.48066 15.3482 4.22488 14.862 4.13692C12.8509 3.95444 10.8316 3.87965 8.81253 3.91286C6.80084 3.87814 4.78873 3.95052 2.78474 4.12969C2.38854 4.20176 2.02188 4.3876 1.72951 4.66453C1.07903 5.26442 1.00676 6.29073 0.934482 7.15804C0.829619 8.71743 0.829619 10.2821 0.934482 11.8415C0.955392 12.3297 1.02807 12.8142 1.15131 13.287C1.23846 13.6521 1.41477 13.9898 1.66447 14.27C1.95882 14.5616 2.33402 14.758 2.74137 14.8337C4.29958 15.0261 5.86962 15.1058 7.43929 15.0722C9.96894 15.1084 12.1878 15.0722 14.8114 14.8699C15.2288 14.7988 15.6145 14.6021 15.9172 14.3061C16.1196 14.1037 16.2707 13.8559 16.3581 13.5833C16.6166 12.7902 16.7435 11.9601 16.7339 11.126C16.7628 10.7212 16.7628 8.27831 16.7628 7.84466ZM7.1791 11.5596V7.08576L11.4578 9.33354C10.258 9.99847 8.6752 10.7501 7.1791 11.5596Z",
    fill: "#121212"
  })), footer_jsx("defs", null, footer_jsx("clipPath", {
    id: "clip0_198_9118"
  }, footer_jsx("rect", {
    x: "0.139404",
    y: "0.82666",
    width: "17.3462",
    height: "17.3462",
    rx: "8.67308",
    fill: "white"
  })))))), footer_jsx("div", {
    className: "custom-paymentdiv"
  }, footer_jsx("h6", null, "Payment Methods"), footer_jsx("div", {
    style: {
      display: "flex",
      gap: "10px"
    }
  }, footer_jsx("div", {
    className: "custom-pay"
  }, footer_jsx(ri_index_esm/* RiVisaLine */.yT$, {
    style: {
      fontSize: "40px",
      fontWeight: "600"
    }
  })), footer_jsx("div", {
    className: "custom-pay"
  }, footer_jsx(fa_index_esm/* FaStripe */.g6c, {
    style: {
      fontSize: "40px",
      fontWeight: "600"
    }
  })))))))), footer_jsx("footer", {
    className: "footer font2",
    style: {
      background: "#F4F4F4",
      marginTop: "5.5rem"
    }
  }, footer_jsx("div", {
    className: "container"
  }, footer_jsx("div", {
    className: "footer-middle"
  }, footer_jsx("div", {
    className: "row"
  }, footer_jsx("div", {
    className: "col-md-12 col-lg-8 mb-3 mb-lg-0"
  }, footer_jsx("ul", {
    className: "footer-category-list mb-0"
  }, footer_jsx("li", null, footer_jsx("h4", {
    className: "d-inline-block"
  }, "Categories:"), " ", categories.map((value, index) => footer_jsx((external_react_default()).Fragment, {
    key: index
  }, footer_jsx(ALink/* default */.Z, {
    href: {
      pathname: "/shop",
      query: {
        category: value._id
      }
    }
  }, value.categoryName), " ", index !== categoryData.getAllChildCategories.records.length - 1 && "| ")), footer_jsx(ALink/* default */.Z, {
    className: "view-all",
    href: {
      pathname: "/shop"
    }
  }, "View All")), footer_jsx("li", null, footer_jsx("h4", {
    className: "d-inline-block"
  }, "Brands:"), " ", brands === null || brands === void 0 ? void 0 : brands.map((value, index) => {
    var _brndData$getAllTopBr;

    return footer_jsx((external_react_default()).Fragment, {
      key: index
    }, footer_jsx(ALink/* default */.Z, {
      href: {
        pathname: "/shop",
        query: {
          category: value._id
        }
      }
    }, value.brandName), " ", index !== ((_brndData$getAllTopBr = brndData.getAllTopBrandRecords) === null || _brndData$getAllTopBr === void 0 ? void 0 : _brndData$getAllTopBr.records.length) - 1 && "| ");
  }), footer_jsx(ALink/* default */.Z, {
    className: "view-all",
    href: {
      pathname: "/shop"
    }
  }, "View All")))), footer_jsx("div", {
    className: "col-md-12 offset-lg-1 col-lg-3 custom-helplineweb"
  }, footer_jsx("img", {
    src: "images/helpline.svg",
    style: {
      width: "30px"
    }
  }), footer_jsx("p", {
    style: {
      color: "rgba(27, 27, 27, 1)"
    }
  }, "Helpline"), footer_jsx("h4", null, "1800 456 84788")))), footer_jsx("div", {
    className: "footer-bottom d-sm-flex align-items-center justify-content-center",
    style: {
      background: "#F4F4F4"
    }
  }, footer_jsx("span", {
    className: "footer-copyright"
  }, "Arab Deals \xA9 2024. All Rights Reserved")))));
}

/* harmony default export */ var footer = ((0,apollo/* default */.Z)({
  ssr: true
})(Footer));
// EXTERNAL MODULE: external "react-slide-toggle"
var external_react_slide_toggle_ = __webpack_require__(3920);
// EXTERNAL MODULE: ./utils/data/menu.js
var menu = __webpack_require__(9955);
;// CONCATENATED MODULE: ./components/common/partials/mobile-menu.jsx
var mobile_menu_jsx = (external_react_default()).createElement;


 // Import Custom Component




function MobileMenu({
  router
}) {
  const pathname = router.pathname;
  const {
    0: searchText,
    1: setSearchText
  } = (0,external_react_.useState)('');
  (0,external_react_.useEffect)(() => {
    router.events.on('routeChangeStart', closeMobileMenu);
    return () => {
      router.events.off('routeChangeStart', closeMobileMenu);
    };
  }, []);

  function isOtherPage() {
    return menu/* mainMenu.other.find */.c.other.find(variation => variation.url === pathname);
  }

  function closeMobileMenu() {
    document.querySelector("body").classList.remove("mmenu-active");

    if (document.querySelector(".menu-toggler")) {
      document.querySelector(".menu-toggler").classList.remove("active");
    }
  }

  function searchProducts(e) {
    e.preventDefault();
    router.push({
      pathname: '/shop',
      query: {
        search: searchText
      }
    });
  }

  function onChangeSearchText(e) {
    setSearchText(e.target.value);
  }

  return mobile_menu_jsx((external_react_default()).Fragment, null, mobile_menu_jsx("div", {
    className: "mobile-menu-overlay",
    onClick: closeMobileMenu
  }), mobile_menu_jsx("div", {
    className: "mobile-menu-container"
  }, mobile_menu_jsx("div", {
    className: "mobile-menu-wrapper"
  }, mobile_menu_jsx("span", {
    className: "mobile-menu-close",
    onClick: closeMobileMenu
  }, mobile_menu_jsx("i", {
    className: "fa fa-times"
  })), mobile_menu_jsx("nav", {
    className: "mobile-nav"
  }, mobile_menu_jsx("ul", {
    className: "mobile-menu"
  }, mobile_menu_jsx("li", {
    className: pathname === '/' ? 'active' : ''
  }, mobile_menu_jsx(ALink/* default */.Z, {
    href: "/"
  }, "Home"))), mobile_menu_jsx("ul", {
    className: "mobile-menu mt-2 mb-2"
  }, mobile_menu_jsx("li", {
    className: "border-0"
  }, mobile_menu_jsx(ALink/* default */.Z, {
    href: "/pages/offers"
  }, "Special Offer!"))), mobile_menu_jsx("ul", {
    className: "mobile-menu"
  }, mobile_menu_jsx("li", null, mobile_menu_jsx(ALink/* default */.Z, {
    href: "/pages/login",
    className: "login-link"
  }, "Log In")))), mobile_menu_jsx("form", {
    className: "search-wrapper mb-2",
    action: "#",
    onSubmit: searchProducts
  }, mobile_menu_jsx("input", {
    type: "text",
    className: "form-control mb-0",
    placeholder: "Search...",
    required: true,
    onChange: onChangeSearchText
  }), mobile_menu_jsx("button", {
    className: "btn icon-search text-white bg-transparent p-0",
    type: "submit"
  })), mobile_menu_jsx("div", {
    className: "social-icons"
  }, mobile_menu_jsx(ALink/* default */.Z, {
    href: "#",
    className: "social-icon social-facebook icon-facebook"
  }), mobile_menu_jsx(ALink/* default */.Z, {
    href: "#",
    className: "social-icon social-twitter icon-twitter"
  }), mobile_menu_jsx(ALink/* default */.Z, {
    href: "#",
    className: "social-icon social-instagram icon-instagram"
  })))));
}

/* harmony default export */ var mobile_menu = ((0,router_.withRouter)(MobileMenu));
// EXTERNAL MODULE: external "react-modal"
var external_react_modal_ = __webpack_require__(9997);
var external_react_modal_default = /*#__PURE__*/__webpack_require__.n(external_react_modal_);
// EXTERNAL MODULE: ./components/partials/product/media/product-media-one.jsx
var product_media_one = __webpack_require__(6775);
// EXTERNAL MODULE: ./components/partials/product/details/product-detail-one.jsx
var product_detail_one = __webpack_require__(2915);
;// CONCATENATED MODULE: ./components/features/modals/quickview.jsx
var quickview_jsx = (external_react_default()).createElement;





 // Import Apollo Server and Query

 // import { GET_PRODUCT } from '../../../server/queries';
// Import Action

 // Import Custom Component



external_react_modal_default().setAppElement('#__next');
const customStyles = {
  content: {
    position: 'relative',
    maxWidth: '930px',
    width: '100%',
    padding: '3rem',
    marginLeft: '2rem',
    marginRight: '2rem',
    overflow: 'hidden auto',
    boxShadow: '0 10px 25px rgba(0,0,0,0.5)',
    maxHeight: 'calc( 100vh - 4rem )'
  }
};
const GET_PRODUCT = client_.gql`query GetProduct($input: ProductId!) {
    getProduct(input: $input) {
      message
      product {
        _id
        vendorId
        brandId
        brandName
        productName
        shortDescription
        skuId
        description
        productInfo
        productShortInfo
        images {
          fileType
          fileURL
          mimeType
          originalName
        }
        rating
        sellingPrice
        price
        mrp
        tags
        productCode
        categoryId
        categoryNamePath
        categoryIdPath
        isBlocked
        stock
        status
        offerPrice
        attributes {
          attributeId
          attributeName
          attributeValueId
          attributeValue
          attributeDescription
        }
      }
    }
  }`;

function QuickModal(props) {
  const {
    slug
  } = props;
  if (!slug) return quickview_jsx("div", null); // const { data, loading, error } = useQuery( GET_PRODUCT, { variables: { demo: 4, slug, onlyData: true } } );

  const {
    data,
    loading,
    error
  } = (0,react_hooks_.useQuery)(GET_PRODUCT, {
    variables: {
      input: {
        _id: slug.toString()
      }
    }
  });
  const router = (0,router_.useRouter)();
  const product = data && data.getProduct.product;
  (0,external_react_.useEffect)(() => {
    router.events.on('routeChangeStart', closeModal);
    return () => {
      router.events.off('routeChangeStart', closeModal);
    };
  }, []);

  if (error) {
    return quickview_jsx("div", null, error.message);
  }

  function closeModal() {
    if (!document.querySelector('.open-modal')) return;
    document.querySelector('.open-modal').classList.add("close-modal");
    setTimeout(() => {
      props.hideQuickView();
    }, 350);
  }

  return quickview_jsx((external_react_default()).Fragment, null, quickview_jsx((external_react_modal_default()), {
    isOpen: props.modalShow,
    onRequestClose: closeModal,
    className: "product-single-container product-single-default product-quick-view custom-scrollbar mb-0",
    overlayClassName: "ajax-overlay open-modal",
    closeTimeoutMS: 100,
    shouldReturnFocusAfterClose: false,
    style: customStyles
  }, quickview_jsx("div", {
    className: `row skeleton-body skel-shop-products ${loading ? '' : 'loaded'}`
  }, quickview_jsx(product_media_one/* default */.Z, {
    product: product,
    parent: ".product-quick-view",
    adClass: "col-md-6 mb-md-0"
  }), quickview_jsx("div", {
    className: "col-md-6"
  }, quickview_jsx(product_detail_one/* default */.Z, {
    product: product,
    parent: ".product-quick-view",
    isNav: false,
    adClass: "mb-0"
  }))), quickview_jsx("button", {
    title: "Close (Esc)",
    type: "button",
    className: "mfp-close",
    onClick: closeModal
  }, "\xD7")));
}

const quickview_mapStateToProps = state => {
  return {
    slug: state.modal.single,
    modalShow: state.modal.quickShow
  };
};

/* harmony default export */ var quickview = ((0,apollo/* default */.Z)({
  ssr: true
})((0,external_react_redux_.connect)(quickview_mapStateToProps, modal/* actions */.Nw)(QuickModal)));
;// CONCATENATED MODULE: ./components/features/modals/video-modal.jsx
var video_modal_jsx = (external_react_default()).createElement;


 // Import Action

 // Import Utils


const video_modal_customStyles = {
  content: {
    top: '50%',
    transform: 'translateY(-50%)'
  },
  overlay: {
    backgroundColor: 'rgba(0,0,0,0.8)',
    zIndex: '10000'
  }
};
external_react_modal_default().setAppElement('#__next');

function VideoModal(props) {
  const {
    showModal
  } = props;

  function closeHandler() {
    document.querySelector('.ReactModal__Overlay').classList.add("close-modal");
    setTimeout(() => {
      props.hideVideo();
    }, 350);
  }

  return showModal ? video_modal_jsx((external_react_modal_default()), {
    isOpen: showModal,
    style: video_modal_customStyles,
    onRequestClose: closeHandler,
    shouldReturnFocusAfterClose: false,
    contentLabel: "Video Modal",
    className: "video-modal",
    closeTimeoutMS: 100
  }, video_modal_jsx("button", {
    type: "button",
    className: "modal-close",
    "data-dismiss": "modal",
    "aria-label": "Close",
    onClick: closeHandler
  }, "\xD7"), video_modal_jsx("iframe", {
    className: "mfp-iframe",
    src: "//www.youtube.com/embed/vBPgmASQ1A0?autoplay=1",
    frameBorder: "0",
    allowFullScreen: "",
    title: "youtube"
  })) : '';
}

const video_modal_mapStateToProps = state => {
  return {
    showModal: state.modal.videoShow
  };
};
/* harmony default export */ var video_modal = ((0,external_react_redux_.connect)(video_modal_mapStateToProps, modal/* actions */.Nw)(VideoModal));
;// CONCATENATED MODULE: ./components/layout.jsx

var layout_jsx = (external_react_default()).createElement;






 // Import Custom Coponent







 // Import Modal Action

 // Import Utils



function Layout({
  children,
  hideQuickView,
  hideVideo
}) {
  (0,external_react_.useEffect)(() => {
    window.addEventListener("scroll", utils/* stickyInit */.ad, {
      passive: true
    });
    window.addEventListener("scroll", utils/* scrollTopInit */.jV, {
      passive: true
    });
    window.addEventListener("resize", utils/* stickyInit */.ad);
    hideQuickView();
    hideVideo();
    return () => {
      window.removeEventListener("scroll", utils/* stickyInit */.ad, {
        passive: true
      });
      window.removeEventListener("scroll", utils/* scrollTopInit */.jV, {
        passive: true
      });
      window.removeEventListener("resize", utils/* stickyInit */.ad);
    };
  }, []);
  return layout_jsx((external_react_default()).Fragment, null, layout_jsx("div", {
    className: "page-wrapper"
  }, layout_jsx(header, null), children, layout_jsx(footer, null), layout_jsx(external_react_toastify_.ToastContainer, {
    autoClose: 3000,
    duration: 300,
    newestOnTo: true,
    draggable: false,
    className: "toast-container",
    position: "bottom-right",
    closeButton: false,
    hideProgressBar: true,
    newestOnTop: true
  }), layout_jsx(quickview, null), layout_jsx(video_modal, null), layout_jsx("div", {
    className: "wishlist-popup"
  }, layout_jsx("div", {
    className: "wishlist-popup-msg"
  }, "Product added!"))), layout_jsx(mobile_menu, null), layout_jsx("a", {
    id: "scroll-top",
    href: "#",
    title: "Top",
    role: "button",
    className: "btn-scroll",
    onClick: utils/* scrollTopHandlder */.F8
  }, layout_jsx("i", {
    className: "icon-angle-up"
  })));
}

/* harmony default export */ var layout = ((0,external_react_redux_.connect)(null, modal/* actions */.Nw)(Layout));
;// CONCATENATED MODULE: ./pages/_app.js

var _app_jsx = (external_react_default()).createElement;





 // import { ApolloProvider } from '@apollo/react-hooks';






const App = ({
  Component,
  pageProps
}) => {
  const store = (0,external_react_redux_.useStore)(); // useEffect(() => {
  //     if (store.getState().demo.current !== 36) {
  //         store.dispatch(DemoAction.refreshStore(36));
  //     }
  // }, [])

  return (// <ApolloProvider client={apolloClient}>
    _app_jsx(external_react_redux_.Provider, {
      store: store
    }, _app_jsx(react_namespaceObject.PersistGate, {
      persistor: store.__persistor,
      loading: _app_jsx("div", {
        className: "loading-overlay"
      }, _app_jsx("div", {
        className: "bounce-loader"
      }, _app_jsx("div", {
        className: "bounce1"
      }), _app_jsx("div", {
        className: "bounce2"
      }), _app_jsx("div", {
        className: "bounce3"
      })))
    }, _app_jsx((external_react_helmet_default()), null, _app_jsx("meta", {
      charSet: "UTF-8"
    }), _app_jsx("meta", {
      "http-equiv": "X-UA-Compatible",
      content: "IE=edge"
    }), _app_jsx("meta", {
      name: "viewport",
      content: "width=device-width, initial-scale=1, shrink-to-fit=no"
    }), _app_jsx("title", null, "Arab Deal"), _app_jsx("meta", {
      name: "keywords",
      content: "React Template"
    }), _app_jsx("meta", {
      name: "description",
      content: "Porto - React eCommerce Template"
    }), _app_jsx("meta", {
      name: "author",
      content: "SW-THEMES"
    })), _app_jsx(layout, null, _app_jsx(Component, pageProps))))
  );
};

App.getInitialProps = async ({
  Component,
  ctx
}) => {
  let pageProps = {};

  if (Component.getInitialProps) {
    pageProps = await Component.getInitialProps(ctx);
  }

  return {
    pageProps
  };
};

/* harmony default export */ var _app = (wrapper.withRedux(App));

/***/ }),

/***/ 6767:
/***/ (function(module) {

// Exports
module.exports = {
	"circle": "header_circle__1TiYM",
	"innercontainer": "header_innercontainer__2nvE4",
	"header-search-category": "header_header-search-category__9ACv1",
	"btn": "header_btn__S6dW4",
	"offerdiv": "header_offerdiv__bhh8a",
	"navcontainer": "header_navcontainer__3OIdt",
	"navbarborder": "header_navbarborder__3Hwcr",
	"flagimg": "header_flagimg__11Cq0",
	"langimg": "header_langimg__1jpSw"
};


/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 6481:
/***/ (function(module) {

"use strict";
module.exports = require("react-helmet");;

/***/ }),

/***/ 2662:
/***/ (function(module) {

"use strict";
module.exports = require("react-hook-form");;

/***/ }),

/***/ 6302:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-lightbox");;

/***/ }),

/***/ 7773:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-magnifiers");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 9997:
/***/ (function(module) {

"use strict";
module.exports = require("react-modal");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,8193,8179,6285,7164,6723,4733,2806,5708,4229,4138,8509,9915,7029,7684,2915,6775,980,6442], function() { return __webpack_exec__(5022); });
module.exports = __webpack_exports__;

})();