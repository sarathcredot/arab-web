(function() {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 92:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "CMS": function() { return /* binding */ CMS; },
  "default": function() { return /* binding */ pages; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
// EXTERNAL MODULE: ./components/partials/home/brand-section.jsx
var brand_section = __webpack_require__(4184);
// EXTERNAL MODULE: external "react-awesome-reveal"
var external_react_awesome_reveal_ = __webpack_require__(104);
// EXTERNAL MODULE: external "react-lazy-load-image-component"
var external_react_lazy_load_image_component_ = __webpack_require__(9290);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var common_ALink = __webpack_require__(8974);
// EXTERNAL MODULE: ./components/features/owl-carousel.jsx
var owl_carousel = __webpack_require__(4138);
// EXTERNAL MODULE: ./utils/data/slider.js
var slider = __webpack_require__(8509);
// EXTERNAL MODULE: ./utils/data/keyframes.js
var keyframes = __webpack_require__(9905);
;// CONCATENATED MODULE: ./components/partials/home/category-section.jsx
var __jsx = (external_react_default()).createElement;


 // Import Custom Component


 // Import Settigns




function CategorySection() {
  return __jsx(Reveal, {
    keyframes: fadeIn,
    delay: 100,
    duration: 1000,
    triggerOnce: true
  }, __jsx("section", {
    className: "categories-section"
  }, __jsx(OwlCarousel, {
    adClass: "categories-slider show-nav-hover nav-outer",
    options: categorySlider
  }, __jsx("div", {
    className: "product-category media-with-lazy"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'fashion'
      }
    }
  }, __jsx("figure", null, __jsx(LazyLoadImage, {
    alt: "category",
    src: "images/home/products/categories/category-1.jpg",
    width: "100%",
    height: "auto",
    threshold: 500,
    effect: "black and white"
  })), __jsx("div", {
    className: "category-content"
  }, __jsx("h3", null, "Fashion"), __jsx("span", null, __jsx("mark", {
    className: "count"
  }, "7"), " products")))), __jsx("div", {
    className: "product-category media-with-lazy"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'furniture'
      }
    }
  }, __jsx("figure", null, __jsx(LazyLoadImage, {
    alt: "category",
    src: "images/home/products/categories/category-2.jpg",
    width: "100%",
    height: "auto",
    threshold: 500,
    effect: "black and white"
  })), __jsx("div", {
    className: "category-content"
  }, __jsx("h3", null, "Furniture"), __jsx("span", null, __jsx("mark", {
    className: "count"
  }, "1"), " products")))), __jsx("div", {
    className: "product-category media-with-lazy"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'sports'
      }
    }
  }, __jsx("figure", null, __jsx(LazyLoadImage, {
    alt: "category",
    src: "images/home/products/categories/category-3.jpg",
    width: "100%",
    height: "auto",
    threshold: 500,
    effect: "black and white"
  })), __jsx("div", {
    className: "category-content"
  }, __jsx("h3", null, "Sports"), __jsx("span", null, __jsx("mark", {
    className: "count"
  }, "2"), " products")))), __jsx("div", {
    className: "product-category media-with-lazy"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'toys'
      }
    }
  }, __jsx("figure", null, __jsx(LazyLoadImage, {
    alt: "category",
    src: "images/home/products/categories/category-4.jpg",
    width: "100%",
    height: "auto",
    threshold: 500,
    effect: "black and white"
  })), __jsx("div", {
    className: "category-content"
  }, __jsx("h3", null, "Toys"), __jsx("span", null, __jsx("mark", {
    className: "count"
  }, "2"), " products")))), __jsx("div", {
    className: "product-category media-with-lazy"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'cameras'
      }
    }
  }, __jsx("figure", null, __jsx(LazyLoadImage, {
    alt: "category",
    src: "images/home/products/categories/category-5.jpg",
    width: "100%",
    height: "auto",
    threshold: 500,
    effect: "black and white"
  })), __jsx("div", {
    className: "category-content"
  }, __jsx("h3", null, "Cameras"), __jsx("span", null, __jsx("mark", {
    className: "count"
  }, "1"), " products")))), __jsx("div", {
    className: "product-category media-with-lazy"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gaming'
      }
    }
  }, __jsx("figure", null, __jsx(LazyLoadImage, {
    alt: "category",
    src: "images/home/products/categories/category-6.jpg",
    width: "100%",
    height: "auto",
    threshold: 500,
    effect: "black and white"
  })), __jsx("div", {
    className: "category-content"
  }, __jsx("h3", null, "Gaming"), __jsx("span", null, __jsx("mark", {
    className: "count"
  }, "1"), " products")))), __jsx("div", {
    className: "product-category media-with-lazy"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'headphones'
      }
    }
  }, __jsx("figure", null, __jsx(LazyLoadImage, {
    alt: "category",
    src: "images/home/products/categories/category-7.jpg",
    width: "100%",
    height: "auto",
    threshold: 500,
    effect: "black and white"
  })), __jsx("div", {
    className: "category-content"
  }, __jsx("h3", null, "Headphones"), __jsx("span", null, __jsx("mark", {
    className: "count"
  }, "1"), " products")))), __jsx("div", {
    className: "product-category media-with-lazy"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'smartphones'
      }
    }
  }, __jsx("figure", null, __jsx(LazyLoadImage, {
    alt: "category",
    src: "images/home/products/categories/category-8.jpg",
    width: "100%",
    height: "auto",
    threshold: 500,
    effect: "black and white"
  })), __jsx("div", {
    className: "category-content"
  }, __jsx("h3", null, "Smartphones"), __jsx("span", null, __jsx("mark", {
    className: "count"
  }, "1"), " products")))))));
}

/* harmony default export */ var category_section = (/*#__PURE__*/(/* unused pure expression or super */ null && (React.memo(CategorySection))));
// EXTERNAL MODULE: ./components/partials/home/category-filter-section.jsx
var category_filter_section = __webpack_require__(199);
// EXTERNAL MODULE: ./components/partials/home/home-section.jsx
var home_section = __webpack_require__(5837);
// EXTERNAL MODULE: ./components/features/modals/newsletter-modal.jsx
var newsletter_modal = __webpack_require__(3576);
;// CONCATENATED MODULE: ./components/partials/home/promo-section.jsx
var promo_section_jsx = (external_react_default()).createElement;

 // Import Custom Component

 // Import Utils



function PromoSection() {
  return promo_section_jsx(Reveal, {
    keyframes: fadeIn,
    delay: 200,
    duration: 1000,
    triggerOnce: true
  }, promo_section_jsx("div", {
    className: "promo-section bg-white"
  }, promo_section_jsx("div", {
    className: "promo-banner banner container text-uppercase bg-transparent"
  }, promo_section_jsx("div", {
    className: " banner-content d-flex align-items-center justify-content-center flex-column\r flex-md-row text-center"
  }, promo_section_jsx("h1", {
    className: "text-white text-animate text-shadow font1"
  }, "DOWNLOAD OUR APP DOWNLOAD OUR APP DOWNLOAD OUR APP DOWNLOAD OUR APP DOWNLOAD OUR APP DOWNLOAD OUR APP DOWNLOAD OUR APP DOWNLOAD OUR APP"), promo_section_jsx("h6", {
    className: "font1 mb-md-0 mb-1 pt-2 pt-md-0 pb-1"
  }, "EXCLUSIVE SALES, GET IT NOW!"), promo_section_jsx("h4", {
    className: "d-inline-block mb-0 pl-3 pr-3 pt-1 pb-1 mb-md-0 mb-1"
  }, "DOWNLOAD OUR APP"), promo_section_jsx(ALink, {
    href: "/shop",
    className: "btn btn-dark"
  }, "Get NOW!")))));
}

/* harmony default export */ var promo_section = (/*#__PURE__*/(/* unused pure expression or super */ null && (React.memo(PromoSection))));
;// CONCATENATED MODULE: ./components/partials/home/info-section.jsx
var info_section_jsx = (external_react_default()).createElement;

 // Import Custom Component

 // Import Settigns



function InfoSection() {
  return info_section_jsx(Reveal, {
    keyframes: fadeInUpShorter,
    delay: 200,
    duration: 1000,
    triggerOnce: true
  }, info_section_jsx(OwlCarousel, {
    adClass: "info-boxes-slider owl-theme",
    options: infoBoxSlider
  }, info_section_jsx("div", {
    className: "info-box info-box-icon-left"
  }, info_section_jsx("i", {
    className: "icon-shipping text-primary"
  }), info_section_jsx("div", {
    className: "info-box-content"
  }, info_section_jsx("h4", null, "FREE SHIPPING & RETURN"), info_section_jsx("p", {
    className: "text-body"
  }, "Free shipping on all orders over $99."))), info_section_jsx("div", {
    className: "info-box info-box-icon-left"
  }, info_section_jsx("i", {
    className: "icon-money text-primary"
  }), info_section_jsx("div", {
    className: "info-box-content"
  }, info_section_jsx("h4", null, "MONEY BACK GUARANTEE"), info_section_jsx("p", {
    className: "text-body"
  }, "100% money back guarantee"))), info_section_jsx("div", {
    className: "info-box info-box-icon-left"
  }, info_section_jsx("i", {
    className: "icon-support text-primary"
  }), info_section_jsx("div", {
    className: "info-box-content"
  }, info_section_jsx("h4", null, "ONLINE SUPPORT 24/7"), info_section_jsx("p", {
    className: "text-body"
  }, "Lorem ipsum dolor sit amet."))), info_section_jsx("div", {
    className: "info-box info-box-icon-left"
  }, info_section_jsx("i", {
    className: "icon-password-lock text-primary"
  }), info_section_jsx("div", {
    className: "info-box-content"
  }, info_section_jsx("h4", null, "SECURE PAYMENT"), info_section_jsx("p", {
    className: "text-body"
  }, "Lorem ipsum dolor sit amet.")))));
}
// EXTERNAL MODULE: ./components/partials/home/banner-section.jsx
var banner_section = __webpack_require__(8037);
// EXTERNAL MODULE: ./components/partials/home/deal-section.jsx + 1 modules
var deal_section = __webpack_require__(4385);
// EXTERNAL MODULE: ./components/partials/home/electronic-collection.jsx
var electronic_collection = __webpack_require__(6924);
// EXTERNAL MODULE: ./components/partials/home/gift-collection.jsx
var gift_collection = __webpack_require__(5729);
// EXTERNAL MODULE: ./components/partials/home/garden-collection.jsx
var garden_collection = __webpack_require__(5249);
// EXTERNAL MODULE: ./components/partials/home/selected-collection.jsx
var selected_collection = __webpack_require__(8048);
// EXTERNAL MODULE: ./components/partials/home/recent-collection.jsx
var recent_collection = __webpack_require__(2413);
// EXTERNAL MODULE: external "react-tabs"
var external_react_tabs_ = __webpack_require__(7659);
// EXTERNAL MODULE: ./components/features/products/product-one.jsx
var product_one = __webpack_require__(4011);
// EXTERNAL MODULE: external "react-owl-carousel2"
var external_react_owl_carousel2_ = __webpack_require__(7033);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(8074);
;// CONCATENATED MODULE: ./components/partials/home/top-brand.jsx
var top_brand_jsx = (external_react_default()).createElement;


 // Import Custom Component



 // Import Settigns






const TOP_BRANDS = client_.gql`query GetAllTopBrandRecords($input: BrandRecordsFilter) {
  getAllTopBrandRecords(input: $input) {
    maxRecords
    message
    records {
      _id
      brandName
      logo {
        fileType
        originalName
        fileURL
      }
    }
  }
}`;

function TopBrand({
  sectionFourData
}) {
  var _data$getAllTopBrandR, _data$getAllTopBrandR2, _sectionFourData$imag;

  const {
    data,
    loading,
    error
  } = useQuery(TOP_BRANDS);
  const options = {
    items: 7,
    // Number of items to show
    // Space between items
    loop: true,
    // Enable loop
    // autoplay: true, // Autoplay the slider
    autoplayTimeout: 3000,
    // Autoplay interval (3 seconds in this example)
    dots: false,
    responsive: {
      0: {
        items: 4,
        loop: true,
        autoplay: true // Number of items to show on small screens

      },
      768: {
        items: 5 // Number of items to show on medium screens

      },
      992: {
        items: 7 // Number of items to show on large screens

      }
    },
    nav: false
  };
  const {
    0: startIndex,
    1: setStartIndex
  } = useState(0);
  const {
    0: brandsPerPage,
    1: setBrandsPerPage
  } = useState(window.innerWidth < 700 ? 4 : 7); // const brandsPerPage = 7;

  const totalBrands = (data === null || data === void 0 ? void 0 : (_data$getAllTopBrandR = data.getAllTopBrandRecords) === null || _data$getAllTopBrandR === void 0 ? void 0 : _data$getAllTopBrandR.records.length) || 0;

  const handleNext = () => {
    if (startIndex + brandsPerPage >= totalBrands) {
      setStartIndex(0); // If reaching the end, loop back to the beginning
    } else {
      setStartIndex(startIndex + 1);
    }
  };

  const handlePrev = () => {
    if (window.innerWidth > 700) {
      if (totalBrands > 7) {
        if (startIndex === 0) {
          setStartIndex(totalBrands - brandsPerPage); // If at the beginning, loop to the end
        } else {
          setStartIndex(startIndex - 1);
        }
      }
    } else {
      if (startIndex === 0) {
        setStartIndex(totalBrands - brandsPerPage); // If at the beginning, loop to the end
      } else {
        setStartIndex(startIndex - 1);
      }
    }
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 700) {
        setBrandsPerPage(4); // If screen width is less than 700, set to 4
      } else {
        setBrandsPerPage(7); // Otherwise, set to default 7
      }
    };

    window.addEventListener('resize', handleResize); // Clean up event listener on unmount

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [window.innerWidth]);
  return top_brand_jsx(React.Fragment, null, top_brand_jsx("div", {
    className: "container custom-brand-title"
  }, top_brand_jsx("div", null, top_brand_jsx("h4", {
    className: "mb-4 mt-4",
    style: {
      borderBottom: "1px solid #EEE",
      paddingBottom: "20px"
    }
  }, "Top Brands"))), top_brand_jsx("div", {
    className: "mb-5 mt-5 custom-brandouter-container" // style={{display:"flex",alignItems:"center",padding:"0 60px"}}

  }, top_brand_jsx("div", {
    className: "custom-top-prevbutton",
    onClick: handlePrev
  }, top_brand_jsx(MdKeyboardArrowLeft, {
    style: {
      color: "black",
      fontSize: "20px"
    }
  })), top_brand_jsx("div", {
    className: "custom-topbrandcontainer container"
  }, data && (data === null || data === void 0 ? void 0 : (_data$getAllTopBrandR2 = data.getAllTopBrandRecords) === null || _data$getAllTopBrandR2 === void 0 ? void 0 : _data$getAllTopBrandR2.records.slice(startIndex, startIndex + brandsPerPage).map((brand, index) => top_brand_jsx("div", {
    key: index,
    className: "item  custom-brand"
  }, brand.logo && top_brand_jsx("img", {
    src: brand.logo.fileURL,
    alt: `Brand ${startIndex + index + 1}` // style={{ width: "128px", height: "128px" }}

  }))))), top_brand_jsx("div", {
    className: "custom-top-prevbutton",
    onClick: handleNext
  }, top_brand_jsx(MdKeyboardArrowRight, {
    style: {
      color: "black",
      fontSize: "20px"
    }
  }))), top_brand_jsx("div", {
    className: "custom-topbrand-img mt-9"
  }, top_brand_jsx("img", {
    src: sectionFourData === null || sectionFourData === void 0 ? void 0 : (_sectionFourData$imag = sectionFourData.images[0]) === null || _sectionFourData$imag === void 0 ? void 0 : _sectionFourData$imag.fileURL
  })));
}

/* harmony default export */ var top_brand = (/*#__PURE__*/(/* unused pure expression or super */ null && (React.memo(TopBrand))));
// EXTERNAL MODULE: ./components/partials/home/footerbanner.jsx
var footerbanner = __webpack_require__(2239);
;// CONCATENATED MODULE: ./components/partials/home/apple-products.jsx
var apple_products_jsx = (external_react_default()).createElement;


function appleproducts({
  products
}) {
  return apple_products_jsx("div", {
    className: "custom-mobOnlyapple"
  }, apple_products_jsx("div", {
    className: "custom-apple-title"
  }, "Apple Products", apple_products_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "16",
    height: "9",
    viewBox: "0 0 16 9",
    fill: "none"
  }, apple_products_jsx("path", {
    d: "M8 9L15.7942 0H0.205771L8 9Z",
    fill: "white"
  }))), apple_products_jsx("div", {
    className: "apple-container"
  }, apple_products_jsx("div", {
    className: "row row-joined"
  }, products ? products.filter(item => item.until === null).slice(0, 6).map((item, index) => apple_products_jsx("div", {
    className: "col-xl-4 col-sm-4 col-6",
    key: "All Products:" + index,
    style: {
      border: "1px solid rgba(185, 185, 185, 1)"
    }
  }, apple_products_jsx(ProductOne // adClass="inner-quickview inner-icon"
  , {
    product: item // customStyle="60%"

  }))) : new Array(8).fill(1).map((item, index) => apple_products_jsx("div", {
    className: "col-xl-3 col-sm-4 col-6",
    key: "All Products:" + index
  }, apple_products_jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "Skeleton:" + index
  }))))));
}
// EXTERNAL MODULE: ./components/common/partials/main-menu.jsx
var main_menu = __webpack_require__(980);
// EXTERNAL MODULE: external "react-helmet"
var external_react_helmet_ = __webpack_require__(6481);
;// CONCATENATED MODULE: ./pages/index.js

var pages_jsx = (external_react_default()).createElement;
// import { useQuery } from "@apollo/react-hooks";
// Import Apollo Server and Query

 // Import Custom Component






















const CMS = react_hooks_.gql`
  query getCmsRecord($input: cmsRecordFilter!) {
    getCmsRecord(input: $input) {
      record {
        _id
        images {
          fileType
          fileURL
          originalName
        }
        buttons {
          buttonText
          redirectionURL
        }
        sectionName
        pageName
      }
    }
  }
`;

function Home() {
  const {
    0: sectionOneDatastate,
    1: setSectionOneDataState
  } = (0,external_react_.useState)({});
  const {
    0: sectionTwoDatastate,
    1: setSectionTwoDataStae
  } = (0,external_react_.useState)({});
  const {
    0: sectionThreeDatastate,
    1: setSectionThreeDataState
  } = (0,external_react_.useState)({});
  const {
    0: sectionFourDatastate,
    1: setSectionFourDataState
  } = (0,external_react_.useState)({});
  const {
    0: sectionFiveDatastate,
    1: setSectionFiveDataState
  } = (0,external_react_.useState)({});
  const {
    0: sectionSixDatastate,
    1: setSectionSixDataState
  } = (0,external_react_.useState)({});
  const {
    data: sectionOneData,
    loading,
    error
  } = (0,react_hooks_.useQuery)(CMS, {
    variables: {
      input: {
        pageName: "Home",
        sectionName: "SECTION-1"
      }
    }
  });
  const {
    data: sectionTwoData,
    loading: loading2,
    error: error2
  } = (0,react_hooks_.useQuery)(CMS, {
    variables: {
      input: {
        pageName: "Home",
        sectionName: "SECTION-2"
      }
    }
  });
  const {
    data: sectionThreeData,
    loading: loading3,
    error: error3
  } = (0,react_hooks_.useQuery)(CMS, {
    variables: {
      input: {
        pageName: "Home",
        sectionName: "SECTION-3"
      }
    }
  });
  const {
    data: sectionFourData,
    loading: loading4,
    error: error4
  } = (0,react_hooks_.useQuery)(CMS, {
    variables: {
      input: {
        pageName: "Home",
        sectionName: "SECTION-4"
      }
    }
  });
  const {
    data: sectionFiveData,
    loading: loading5,
    error: error5
  } = (0,react_hooks_.useQuery)(CMS, {
    variables: {
      input: {
        pageName: "Home",
        sectionName: "SECTION-5"
      }
    }
  });
  (0,external_react_.useEffect)(() => {
    if (sectionOneData) {
      var _sectionOneData$getCm;

      setSectionOneDataState(sectionOneData === null || sectionOneData === void 0 ? void 0 : (_sectionOneData$getCm = sectionOneData.getCmsRecord) === null || _sectionOneData$getCm === void 0 ? void 0 : _sectionOneData$getCm.record);
    }

    if (sectionTwoData) {
      var _sectionTwoData$getCm;

      setSectionTwoDataStae(sectionTwoData === null || sectionTwoData === void 0 ? void 0 : (_sectionTwoData$getCm = sectionTwoData.getCmsRecord) === null || _sectionTwoData$getCm === void 0 ? void 0 : _sectionTwoData$getCm.record);
    }

    if (sectionThreeData) {
      var _sectionThreeData$get;

      setSectionThreeDataState(sectionThreeData === null || sectionThreeData === void 0 ? void 0 : (_sectionThreeData$get = sectionThreeData.getCmsRecord) === null || _sectionThreeData$get === void 0 ? void 0 : _sectionThreeData$get.record);
    }

    if (sectionFourData) {
      var _sectionFourData$getC;

      setSectionFourDataState(sectionFourData === null || sectionFourData === void 0 ? void 0 : (_sectionFourData$getC = sectionFourData.getCmsRecord) === null || _sectionFourData$getC === void 0 ? void 0 : _sectionFourData$getC.record);
    }

    if (sectionFiveData) {
      var _sectionFiveData$getC;

      setSectionFiveDataState(sectionFiveData === null || sectionFiveData === void 0 ? void 0 : (_sectionFiveData$getC = sectionFiveData.getCmsRecord) === null || _sectionFiveData$getC === void 0 ? void 0 : _sectionFiveData$getC.record);
    }
  }, [sectionOneData, sectionTwoData, sectionThreeData, sectionFourData, sectionFiveData]);
  return pages_jsx((external_react_default()).Fragment, null, pages_jsx(external_react_helmet_.Helmet, null, pages_jsx("title", null, "Home | Arab Deals")), pages_jsx("main", {
    className: "home"
  }, pages_jsx("div", {
    style: {
      position: "relative"
    }
  }, pages_jsx("div", {
    className: "header-bottom d-flex",
    style: {
      zIndex: "99",
      position: "absolute",
      width: "100%"
    }
  }, pages_jsx("div", {
    className: "container",
    style: {
      marginBottom: "-15px"
    }
  }, pages_jsx("div", null, pages_jsx(main_menu/* default */.ZP, null)))), pages_jsx("div", {
    className: "homebannerpadding"
  }, !loading && pages_jsx(home_section/* default */.Z, {
    className: "pb-5",
    data: sectionOneDatastate
  }))), pages_jsx("div", {
    className: `container skeleton-body skel-shop-products pt-2 ${ false ? 0 : "loaded"}`
  }, !loading2 && !loading3 && pages_jsx(banner_section/* default */.Z, {
    sectionTwoData: sectionTwoDatastate,
    sectionThreeData: sectionThreeDatastate,
    sectionSixData: sectionSixDatastate
  }), pages_jsx(deal_section/* default */.Z, null)), pages_jsx("div", {
    className: `container skeleton-body skel-shop-products `
  }, !loading4 && pages_jsx(brand_section/* default */.Z, null)), pages_jsx(footerbanner/* default */.Z, {
    data: sectionFourDatastate
  }), pages_jsx("div", {
    className: ` skeleton-body skel-shop-products ${ false ? 0 : "loaded"}`
  }, pages_jsx(electronic_collection/* default */.Z, null)), !loading5 && pages_jsx(footerbanner/* default */.Z, {
    data: sectionFiveDatastate
  })));
}

/* harmony default export */ var pages = ((0,apollo/* default */.Z)({
  ssr: true
})(Home));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 7381:
/***/ (function(module) {

"use strict";
module.exports = require("@emotion/react");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 6155:
/***/ (function(module) {

"use strict";
module.exports = require("js-cookie");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 104:
/***/ (function(module) {

"use strict";
module.exports = require("react-awesome-reveal");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 6481:
/***/ (function(module) {

"use strict";
module.exports = require("react-helmet");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 9997:
/***/ (function(module) {

"use strict";
module.exports = require("react-modal");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 7659:
/***/ (function(module) {

"use strict";
module.exports = require("react-tabs");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,8193,6285,7164,6723,4733,2806,5708,4229,4011,4138,8509,9915,9905,980,5580], function() { return __webpack_exec__(92); });
module.exports = __webpack_exports__;

})();