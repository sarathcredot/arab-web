(function() {
var exports = {};
exports.id = 9296;
exports.ids = [9296];
exports.modules = {

/***/ 356:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7164);
/* harmony import */ var _server_queries__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4733);
/* harmony import */ var _components_common_ALink__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8974);
/* harmony import */ var _components_partials_product_media_product_media_one__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6775);
/* harmony import */ var _components_partials_product_details_product_detail_one__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2915);
/* harmony import */ var _components_partials_product_widgets_product_widget_container__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4181);
/* harmony import */ var _components_partials_product_widgets_related_products__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5655);
/* harmony import */ var _components_partials_product_tabs_single_tab_five__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2644);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1649);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);


 // Import Apollo Server and Query


 // Import Custom Component









function ProductCustomTab() {
  if (!(0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)().query.slug) return __jsx("div", {
    className: "loading-overlay"
  }, __jsx("div", {
    className: "bounce-loader"
  }, __jsx("div", {
    className: "bounce1"
  }), __jsx("div", {
    className: "bounce2"
  }), __jsx("div", {
    className: "bounce3"
  })));
  const slug = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)().query.slug;
  const {
    data,
    loading,
    error
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__.useQuery)(_server_queries__WEBPACK_IMPORTED_MODULE_4__/* .GET_PRODUCT */ .N4, {
    variables: {
      slug
    }
  });
  const product = data && data.product.data;
  const related = data && data.product.related; // if ( error ) {
  //     return useRouter().push( '/pages/404' );
  // }

  return __jsx("main", {
    className: "main"
  }, __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-3"
  }, __jsx("div", {
    className: "container"
  }, __jsx("ol", {
    className: "breadcrumb"
  }, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    href: "/"
  }, __jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_11__/* .IoMdHome */ .QO$, {
    style: {
      fontSize: '16px'
    }
  }))), __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    href: "/shop"
  }, "Shop")), __jsx("li", {
    className: "breadcrumb-item"
  }, product && product.categories.map((item, index) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), {
    key: `category-${index}`
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    href: {
      pathname: "/shop",
      query: {
        category: item.slug
      }
    }
  }, item.name), index < product.categories.length - 1 ? ',' : ''))), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, product && product.name)))), __jsx("div", {
    className: `container pt-2 skeleton-body skel-shop-products ${loading ? '' : 'loaded'}`
  }, __jsx("div", {
    className: `product-single-container product-single-default`
  }, __jsx("div", {
    className: "row"
  }, __jsx(_components_partials_product_media_product_media_one__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
    product: product
  }), __jsx(_components_partials_product_details_product_detail_one__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
    product: product,
    prev: product && data.product.prev,
    next: product && data.product.next
  }))), __jsx(_components_partials_product_tabs_single_tab_five__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z, {
    product: product,
    isCustomTab: true
  }), __jsx(_components_partials_product_widgets_related_products__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
    products: related,
    loading: loading
  }), __jsx("hr", {
    className: "mt-0 m-b-5"
  })), __jsx(_components_partials_product_widgets_product_widget_container__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, null));
}

/* harmony default export */ __webpack_exports__["default"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)({
  ssr: true
})(ProductCustomTab));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 7381:
/***/ (function(module) {

"use strict";
module.exports = require("@emotion/react");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 104:
/***/ (function(module) {

"use strict";
module.exports = require("react-awesome-reveal");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 6302:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-lightbox");;

/***/ }),

/***/ 7773:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-magnifiers");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 7659:
/***/ (function(module) {

"use strict";
module.exports = require("react-tabs");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,2806,5708,4229,4011,4138,8509,9915,9905,7029,7684,5023,2915,6775,2644], function() { return __webpack_exec__(356); });
module.exports = __webpack_exports__;

})();