(function() {
var exports = {};
exports.id = 3014;
exports.ids = [3014];
exports.modules = {

/***/ 1350:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _slug_; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: external "react-image-lightbox"
var external_react_image_lightbox_ = __webpack_require__(6302);
var external_react_image_lightbox_default = /*#__PURE__*/__webpack_require__.n(external_react_image_lightbox_);
// EXTERNAL MODULE: external "react-image-magnifiers"
var external_react_image_magnifiers_ = __webpack_require__(7773);
// EXTERNAL MODULE: ./components/features/owl-carousel.jsx
var owl_carousel = __webpack_require__(4138);
// EXTERNAL MODULE: ./utils/data/slider.js
var slider = __webpack_require__(8509);
;// CONCATENATED MODULE: ./components/partials/product/media/product-media-six.jsx

var __jsx = (external_react_default()).createElement;


 //Import Custom Component

 //Import Utils


function ProductMediaOne(props) {
  const {
    adClass = 'col-lg-5 col-md-6',
    product,
    parent = ".product-single-default"
  } = props;
  const {
    0: openLB,
    1: setOpenLB
  } = (0,external_react_.useState)(false);
  const {
    0: photoIndex,
    1: setPhotoIndex
  } = (0,external_react_.useState)(0);
  const {
    0: mediaRef,
    1: setMediaRef
  } = (0,external_react_.useState)(null);
  let verticalCarousel,
      thumbs,
      thumbsWrap,
      productThumb,
      thumbStyle,
      thumbCount,
      thumbsHight,
      thumbUp,
      thumbDown,
      thumbsDots,
      count = 0;
  const events = {
    onTranslate: function (e) {
      document.querySelector(`${parent} .vertical-thumbs .owl-dot.active`).classList.remove('active');
      let thumbs = document.querySelectorAll(`${parent} .vertical-thumbs .owl-dot`);
      thumbs[e.item.index].classList.add('active');
      thumbsSetActive(e.item.index);
    },
    onTranslated: function (e) {
      setPhotoIndex(e.item.index);
    }
  };
  (0,external_react_.useEffect)(() => {
    window.addEventListener('resize', calcHeight);
    return () => {
      window.removeEventListener('resize', calcHeight);
    };
  });
  (0,external_react_.useEffect)(() => {
    product && thumbsInit();
  });
  (0,external_react_.useEffect)(() => {
    if (product) {
      setOpenLB(false);
      setPhotoIndex(0);
      calcHeight();
      document.querySelector(`${parent} .vertical-thumbs .owl-dot.active`) && document.querySelector(`${parent} .vertical-thumbs .owl-dot.active`).classList.remove('active');
      document.querySelector(`${parent} .vertical-thumbs .owl-dot`).classList.add('active');
    }
  }, [product]);

  function calcHeight() {
    thumbsRefresh();
    thumbsHight = parseInt(productThumb.offsetHeight * 3) + parseInt(thumbStyle * 2) + 3;
    if (document.querySelector('.product-thumbs-wrap')) document.querySelector('.product-thumbs-wrap').style.height = thumbsHight + 'px';
  }

  function isSale() {
    return product.price[0] !== product.price[1] && product.variants.length === 0 ? '-' + (100 * (product.price[1] - product.price[0]) / product.price[1]).toFixed(0) + '%' : product.variants.find(variant => variant.sale_price) ? "Sale" : false;
  }

  function openLightBox() {
    setOpenLB(true);
  }

  function closeLightBox() {
    setOpenLB(false);
  }

  function moveNextPhoto() {
    setPhotoIndex((photoIndex + 1) % product.large_pictures.length);
  }

  function movePrevPhoto() {
    setPhotoIndex((photoIndex + product.large_pictures.length - 1) % product.large_pictures.length);
  }

  function changeMediaIndex(index, e) {
    if (!e.currentTarget.classList.contains('active')) {
      let thumbs = e.currentTarget.closest('.vertical-thumbs');
      thumbs.querySelector('.owl-dot.active') && thumbs.querySelector('.owl-dot.active').classList.remove('active');
      e.currentTarget.classList.add('active');
    }

    mediaRef.current.goTo(index);
    let defaultTop = thumbsWrap.getBoundingClientRect().top + window.pageYOffset + parseInt(productThumb.offsetHeight) + parseInt(thumbStyle);

    if (thumbCount > 3) {
      let curThumb = thumbsDots[index];
      let offsetTop = curThumb.getBoundingClientRect().top + pageYOffset;

      if (offsetTop > defaultTop && offsetTop !== defaultTop && index < thumbCount - 1) {
        thumbsSetActive(index + 1);
      } else if (offsetTop < defaultTop && offsetTop !== defaultTop && index !== 0) {
        thumbsSetActive(index - 1);
      }
    }
  }

  function thumbsSetActive(index) {
    let top = parseInt(window.getComputedStyle(thumbs).getPropertyValue('top').slice(0, -2));
    let offset = top + index * (parseInt(productThumb.offsetHeight) + parseInt(thumbStyle));
    let curThumb = thumbsDots[index];

    if (offset < 0) {
      if (curThumb.previousSibling == null) {
        !thumbUp.classList.contains('disabled') && thumbUp.classList.add('disabled');
      } else {
        thumbUp.classList.contains('disabled') && thumbUp.classList.remove('disabled');
      }

      thumbDown.classList.contains('disabled') && thumbDown.classList.remove('disabled');
      thumbs.setAttribute('style', 'top: ' + parseInt(top - offset) + 'px');
    } else {
      offset = thumbs.getBoundingClientRect().top + thumbs.offsetHeight - curThumb.getBoundingClientRect().top - curThumb.offsetHeight;

      if (offset < 0) {
        if (curThumb.nextSibling == null) {
          !thumbDown.classList.contains('disabled') && thumbDown.classList.add('disabled');
        } else {
          thumbDown.classList.contains('disabled') && thumbDown.classList.remove('disabled');
        }

        thumbUp.classList.contains('disabled') && thumbUp.classList.remove('disabled');
        thumbs.setAttribute('style', 'top: ' + parseInt(top + offset) + 'px');
      }
    }
  }

  function thumbsInit() {
    verticalCarousel = document.querySelector('.pg-vertical');
    thumbs = verticalCarousel.querySelector('.product-thumbs');
    thumbStyle = window.getComputedStyle(thumbs.querySelector('.owl-dot')).getPropertyValue('margin-bottom').slice(0, -2);
    productThumb = thumbs.querySelector('.owl-dot');
    thumbsWrap = thumbs.parentElement;
    thumbsDots = thumbs.querySelectorAll('.owl-dot');
    thumbCount = thumbsDots.length;
    thumbsHight = productThumb.offsetHeight * thumbCount + thumbStyle * (thumbCount - 1);
    thumbUp = document.querySelector('.vertical-thumbs .thumb-up');
    thumbDown = document.querySelector('.vertical-thumbs .thumb-down');
  }

  function thumbsUp(e) {
    let maxTop = thumbsWrap.getBoundingClientRect().top + window.pageYOffset,
        curTop = thumbs.getBoundingClientRect().top + window.pageYOffset,
        top = parseInt(window.getComputedStyle(thumbs).getPropertyValue('top').slice(0, -2)) + parseInt(productThumb.offsetHeight) + parseInt(thumbStyle);
    if (count !== 0) count--;

    if (maxTop > curTop) {
      thumbs.setAttribute('style', 'top: ' + top + 'px');

      if (count == 0) {
        !thumbUp.classList.contains('disabled') && thumbUp.classList.add('disabled');
        thumbDown.classList.contains('disabled') && thumbDown.classList.remove('disabled');
      }
    }
  }

  function thumbsDown(e) {
    let maxBottom = thumbsWrap.getBoundingClientRect().top + window.pageYOffset + thumbsWrap.offsetHeight,
        curBottom = thumbsHight + thumbs.getBoundingClientRect().top + window.pageYOffset,
        top = parseInt(window.getComputedStyle(thumbs).getPropertyValue('top').slice(0, -2)) - parseInt(productThumb.offsetHeight) - parseInt(thumbStyle);
    if (count !== thumbCount - 3) count++;

    if (maxBottom <= curBottom) {
      thumbs.setAttribute('style', 'top: ' + top + 'px');

      if (count == thumbCount - 3) {
        thumbUp.classList.contains('disabled') && thumbUp.classList.remove('disabled');
        !thumbDown.classList.contains('disabled') && thumbDown.classList.add('disabled');
      }
    }
  }

  function thumbsRefresh() {
    if (thumbCount <= 3) {
      thumbDown && thumbDown.setAttribute('style', 'visibility: hidden');
      thumbUp && thumbUp.setAttribute('style', 'visibility: hidden');
    } else {
      if (thumbs) thumbs.style.top = 0 + 'px';
      thumbDown && thumbDown.setAttribute('style', 'visibility: visible');
      thumbUp && thumbUp.setAttribute('style', 'visibility: visible');
      thumbUp && !thumbUp.classList.contains('disabled') && thumbUp.classList.add('disabled');
      thumbDown && thumbDown.classList.contains('disabled') && thumbDown.classList.remove('disabled');
    }
  }

  return __jsx("div", {
    className: `product-single-gallery ${adClass}`
  }, __jsx("div", {
    className: `skel-pro skel-magnifier-vertical skel-full ${adClass}`
  }), product && __jsx((external_react_default()).Fragment, null, __jsx("div", {
    className: "product-slider-container"
  }, __jsx("div", {
    className: "label-group"
  }, product.is_hot ? __jsx("div", {
    className: "product-label label-hot"
  }, "HOT") : '', isSale() ? __jsx("div", {
    className: "product-label label-sale"
  }, isSale()) : ''), __jsx(owl_carousel/* default */.Z, {
    adClass: "product-single-carousel owl-carousel owl-theme show-nav-hover",
    options: slider/* productSingleSlider */.Kk,
    events: events,
    onChangeRef: setMediaRef
  }, product.large_pictures.map((item, index) => __jsx("div", {
    className: "product-item",
    key: `product-item-${index}`
  }, __jsx(external_react_image_magnifiers_.Magnifier, {
    style: {
      paddingTop: "100%",
      position: "relative"
    },
    imageSrc: process.env.NEXT_PUBLIC_ASSET_URI + item.url,
    imageAlt: "product",
    mouseActivation: "hover",
    cursorStyleActive: "crosshair",
    dragToMove: false,
    className: "product-single-image"
  })))), __jsx("span", {
    className: "prod-full-screen",
    onClick: openLightBox
  }, __jsx("i", {
    className: "icon-plus"
  })), openLB && __jsx((external_react_image_lightbox_default()), {
    mainSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[photoIndex].url,
    prevSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[(photoIndex + product.large_pictures.length - 1) % product.large_pictures.length].url,
    nextSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[(photoIndex + 1) % product.large_pictures.length].url,
    onCloseRequest: closeLightBox,
    onMoveNextRequest: moveNextPhoto,
    onMovePrevRequest: movePrevPhoto
  })), __jsx("div", {
    className: "vertical-thumbs"
  }, __jsx("button", {
    className: "thumb-up disabled",
    onClick: thumbsUp
  }, __jsx("i", {
    className: "icon-angle-up"
  })), __jsx("div", {
    className: "product-thumbs-wrap"
  }, __jsx("div", {
    className: "product-thumbs owl-dots"
  }, product.pictures.map((item, index) => __jsx("div", {
    className: "owl-dot media-with-lazy",
    key: `owl-dot-${index}`,
    onClick: e => changeMediaIndex(index, e)
  }, __jsx("figure", null, __jsx("img", {
    src: process.env.NEXT_PUBLIC_ASSET_URI + item.url,
    alt: "Thumbnail"
  })))))), __jsx("button", {
    className: "thumb-down disabled",
    onClick: thumbsDown
  }, __jsx("i", {
    className: "icon-angle-down"
  })))));
}
// EXTERNAL MODULE: ./components/partials/product/details/product-detail-one.jsx
var product_detail_one = __webpack_require__(2915);
// EXTERNAL MODULE: ./components/partials/product/tabs/single-tab-three.jsx + 1 modules
var single_tab_three = __webpack_require__(7520);
// EXTERNAL MODULE: ./components/partials/product/widgets/related-products.jsx
var related_products = __webpack_require__(5655);
// EXTERNAL MODULE: ./components/partials/product/widgets/product-widget-container.jsx
var product_widget_container = __webpack_require__(4181);
;// CONCATENATED MODULE: ./pages/product/transparent/[slug].js
var _slug_jsx = (external_react_default()).createElement;



 // import Apollo Server and Query


 // Import Custom Component








function ProductTransparent() {
  var _data$product, _data$product2;

  if (!(0,router_.useRouter)().query.slug) return _slug_jsx("div", {
    className: "loading-overlay"
  }, _slug_jsx("div", {
    className: "bounce-loader"
  }, _slug_jsx("div", {
    className: "bounce1"
  }), _slug_jsx("div", {
    className: "bounce2"
  }), _slug_jsx("div", {
    className: "bounce3"
  })));
  const slug = (0,router_.useRouter)().query.slug;
  const {
    data,
    loading,
    error
  } = (0,react_hooks_.useQuery)(queries/* GET_PRODUCT */.N4, {
    variables: {
      slug
    }
  });
  const product = data && (data === null || data === void 0 ? void 0 : (_data$product = data.product) === null || _data$product === void 0 ? void 0 : _data$product.data);
  const related = data && ((_data$product2 = data.product) === null || _data$product2 === void 0 ? void 0 : _data$product2.related); // if ( error ) {
  //     return useRouter().push( '/pages/404' );
  // }

  return _slug_jsx("main", {
    className: "main"
  }, _slug_jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-3"
  }, _slug_jsx("div", {
    className: "container"
  }, _slug_jsx("ol", {
    className: "breadcrumb"
  }, _slug_jsx("li", {
    className: "breadcrumb-item"
  }, _slug_jsx(ALink/* default */.Z, {
    href: "/"
  }, _slug_jsx(index_esm/* IoMdHome */.QO$, null))), _slug_jsx("li", {
    className: "breadcrumb-item"
  }, _slug_jsx(ALink/* default */.Z, {
    href: "/shop"
  }, "Shop")), _slug_jsx("li", {
    className: "breadcrumb-item"
  }, product && product.categories.map((item, index) => _slug_jsx((external_react_default()).Fragment, {
    key: `category-${index}`
  }, _slug_jsx(ALink/* default */.Z, {
    href: {
      pathname: "/shop",
      query: {
        category: item.slug
      }
    }
  }, item.name), index < product.categories.length - 1 ? ',' : ''))), _slug_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, product && product.name)))), _slug_jsx("div", {
    className: `product-single-container product-single-default product-transparent-image pb-3  bg-gray skeleton-body skel-shop-products ${loading ? '' : 'loaded'}`
  }, _slug_jsx("div", {
    className: "container"
  }, _slug_jsx("div", {
    className: "row"
  }, _slug_jsx("div", {
    className: "col-xl-7"
  }, _slug_jsx(ProductMediaOne, {
    product: product,
    adClass: "pg-vertical"
  })), _slug_jsx(product_detail_one/* default */.Z, {
    adClass: "col-xl-5 pt-3",
    product: product,
    prev: product && data.product.prev,
    next: product && data.product.next
  })))), _slug_jsx("div", {
    className: `container skeleton-body skel-shop-products ${loading ? '' : 'loaded'}`
  }, _slug_jsx(single_tab_three/* default */.Z, {
    product: product,
    adClass: "mb-6"
  }), _slug_jsx(related_products/* default */.Z, {
    products: related,
    loading: loading
  }), _slug_jsx("hr", {
    className: "mt-0 m-b-5"
  })), _slug_jsx(product_widget_container/* default */.Z, null));
}

/* harmony default export */ var _slug_ = ((0,apollo/* default */.Z)({
  ssr: true
})(ProductTransparent));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 7381:
/***/ (function(module) {

"use strict";
module.exports = require("@emotion/react");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 104:
/***/ (function(module) {

"use strict";
module.exports = require("react-awesome-reveal");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 6302:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-lightbox");;

/***/ }),

/***/ 7773:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-magnifiers");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,2806,5708,4229,4011,4138,8509,9915,9905,7029,7684,5023,2915,7520], function() { return __webpack_exec__(1350); });
module.exports = __webpack_exports__;

})();