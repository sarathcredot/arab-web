(function() {
var exports = {};
exports.id = 3831;
exports.ids = [3831];
exports.modules = {

/***/ 7095:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _slug_; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: ./components/partials/product/media/product-media-one.jsx
var product_media_one = __webpack_require__(6775);
// EXTERNAL MODULE: ./components/partials/product/details/product-detail-one.jsx
var product_detail_one = __webpack_require__(2915);
// EXTERNAL MODULE: ./components/partials/product/tabs/single-tab-three.jsx + 1 modules
var single_tab_three = __webpack_require__(7520);
// EXTERNAL MODULE: ./components/partials/product/widgets/related-products.jsx
var related_products = __webpack_require__(5655);
// EXTERNAL MODULE: ./components/partials/product/widgets/product-widget-container.jsx
var product_widget_container = __webpack_require__(4181);
// EXTERNAL MODULE: external "react-slide-toggle"
var external_react_slide_toggle_ = __webpack_require__(3920);
var external_react_slide_toggle_default = /*#__PURE__*/__webpack_require__.n(external_react_slide_toggle_);
// EXTERNAL MODULE: external "react-sticky-box"
var external_react_sticky_box_ = __webpack_require__(9058);
var external_react_sticky_box_default = /*#__PURE__*/__webpack_require__.n(external_react_sticky_box_);
// EXTERNAL MODULE: external "rc-tree"
var external_rc_tree_ = __webpack_require__(5768);
var external_rc_tree_default = /*#__PURE__*/__webpack_require__.n(external_rc_tree_);
// EXTERNAL MODULE: external "react-lazy-load-image-component"
var external_react_lazy_load_image_component_ = __webpack_require__(9290);
// EXTERNAL MODULE: ./components/features/products/product-three.jsx
var product_three = __webpack_require__(9915);
// EXTERNAL MODULE: ./components/features/owl-carousel.jsx
var owl_carousel = __webpack_require__(4138);
// EXTERNAL MODULE: ./utils/data/slider.js
var slider = __webpack_require__(8509);
;// CONCATENATED MODULE: ./components/partials/product/sidebars/sidebar-one.jsx
var __jsx = (external_react_default()).createElement;






 // Import Aollo Server and Query


 // Import Custom Component



 // Import Settings



const TreeNode = props => {
  return __jsx((external_react_default()).Fragment, null, props.name, __jsx("span", {
    className: "products-count"
  }, "(", props.count, ")"));
};

function ProductSidebarOne(props) {
  const router = (0,router_.useRouter)();
  const query = router.query;
  const {
    adClass = ""
  } = props;
  const {
    data,
    loading,
    error
  } = (0,react_hooks_.useQuery)(queries/* GET_SHOP_SIDEBAR_DATA */.EP, {
    variables: {
      featured: true
    }
  });
  const categories = (0,external_react_.useMemo)(() => {
    let cats = data ? data.shopSidebarData.categories : [];
    let stack = [],
        result = [];
    result = cats.reduce((acc, cur) => {
      if (!cur.parent) {
        let newNode = {
          key: cur.slug,
          title: __jsx(TreeNode, {
            name: cur.name,
            count: cur.count
          }),
          children: []
        };
        acc.push(newNode);
        stack.push({
          name: cur.name,
          children: newNode.children
        });
      }

      return acc;
    }, []);
    let temp, children, childNode;

    while (stack.length) {
      temp = stack[stack.length - 1];
      stack.pop();
      children = cats.filter(item => item.parent === temp.name);
      children.forEach(child => {
        childNode = {
          key: child.slug,
          title: __jsx(TreeNode, {
            name: child.name,
            count: child.count
          }),
          children: []
        };
        temp.children.push(childNode);
        stack.push({
          name: child.name,
          children: childNode.children
        });
      });
    }

    return result;
  }, [data]);
  (0,external_react_.useEffect)(() => {
    return () => {
      closeSidebar();
    };
  }, []);

  function sidebarToggle(e) {
    let body = document.querySelector('body');
    e.preventDefault();

    if (body.classList.contains('sidebar-opened')) {
      body.classList.remove('sidebar-opened');
    } else {
      body.classList.add('sidebar-opened');
    }
  }

  function filterByCategory(selected) {
    router.push({
      pathname: '/shop',
      query: {
        category: selected[0],
        grid: query.grid
      }
    });
  }

  function closeSidebar() {
    document.querySelector('body').classList.contains('sidebar-opened') && document.querySelector('body').classList.remove('sidebar-opened');
  }

  return __jsx((external_react_default()).Fragment, null, __jsx("div", {
    className: "sidebar-overlay",
    onClick: closeSidebar
  }), __jsx("div", {
    className: "sidebar-toggle custom-sidebar-toggle",
    onClick: e => sidebarToggle(e)
  }, __jsx("i", {
    className: "fas fa-sliders-h"
  })), __jsx("aside", {
    className: `sidebar-product col-lg-3 mobile-sidebar skeleton-body skel-shop-products ${adClass} ${loading ? '' : 'loaded'}`
  }, __jsx((external_react_sticky_box_default()), {
    className: "sticky-wrapper",
    offsetTop: 70
  }, loading ? __jsx("div", {
    className: "skel-widget"
  }) : __jsx("div", {
    className: "widget widget-product-categories mb-3"
  }, __jsx((external_react_slide_toggle_default()), null, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => __jsx((external_react_default()).Fragment, null, __jsx("h3", {
    className: "widget-title"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      e.preventDefault(), onToggle();
    },
    className: toggleState === 'COLLAPSED' ? 'collapsed' : ''
  }, "Categories")), __jsx("div", {
    className: "overflow-hidden",
    ref: setCollapsibleElement
  }, __jsx("div", {
    className: "widget-body"
  }, __jsx((external_rc_tree_default()), {
    className: "no-icon cat-list border-0",
    selectable: true,
    showIcon: false,
    defaultExpandedKeys: query.category ? [query.category] : [],
    switcherIcon: props => {
      return !props.isLeaf ? __jsx("span", {
        className: "toggle"
      }) : '';
    },
    selectedKeys: query.category ? [query.category] : [],
    treeData: categories,
    onSelect: filterByCategory
  })))))), loading ? __jsx("div", {
    className: "skel-widget"
  }) : __jsx("div", {
    className: "widget"
  }, __jsx("div", {
    className: "maga-sale-container"
  }, __jsx("figure", {
    className: "mega-image"
  }, __jsx(external_react_lazy_load_image_component_.LazyLoadImage, {
    alt: "banner",
    src: "images/banners/banner-sidebar.jpg",
    threshold: 500,
    effect: "blur",
    width: 100,
    height: 335
  })), __jsx("div", {
    className: "mega-content"
  }, __jsx("div", {
    className: "mega-price-box"
  }, __jsx("span", {
    className: "price-big"
  }, "50"), __jsx("span", {
    className: "price-desc"
  }, __jsx("em", null, "%"), "OFF")), __jsx("div", {
    className: "mega-desc"
  }, __jsx("h3", {
    className: "mega-title mb-0"
  }, "MEGA SALE"), __jsx("span", {
    className: "mega-subtitle"
  }, "MANY ITEM"))))), __jsx("div", {
    className: "widget widget-featured"
  }, __jsx("h3", {
    className: "widget-title"
  }, "Featured"), __jsx("div", {
    className: "widget-body"
  }, __jsx(owl_carousel/* default */.Z, {
    adClass: "widget-featured-products",
    isTheme: false,
    options: slider/* widgetFeaturedProductSlider */.nV
  }, __jsx("div", {
    className: "featured-col"
  }, loading ? [0, 1, 2].map((item, index) => __jsx("div", {
    className: "skel-product-col skel-pro mb-2",
    key: "product-one" + index
  })) : data.shopSidebarData.featured.map((item, index) => __jsx(product_three/* default */.Z, {
    product: item,
    key: "product-three" + index
  }))), __jsx("div", {
    className: "featured-col"
  }, data && data.shopSidebarData.featured.map((item, index) => __jsx(product_three/* default */.Z, {
    product: item,
    key: `featured-${index}`
  })))))))));
}

/* harmony default export */ var sidebar_one = ((0,apollo/* default */.Z)({
  ssr: true
})(ProductSidebarOne));
;// CONCATENATED MODULE: ./pages/product/left-sidebar/[slug].js
var _slug_jsx = (external_react_default()).createElement;



 // Import Apollo Server and Query


 // Import Custom Component









function ProductLeftSidebar() {
  if (!(0,router_.useRouter)().query.slug) return _slug_jsx("div", {
    className: "loading-overlay"
  }, _slug_jsx("div", {
    className: "bounce-loader"
  }, _slug_jsx("div", {
    className: "bounce1"
  }), _slug_jsx("div", {
    className: "bounce2"
  }), _slug_jsx("div", {
    className: "bounce3"
  })));
  const slug = (0,router_.useRouter)().query.slug;
  const {
    data,
    loading,
    error
  } = (0,react_hooks_.useQuery)(queries/* GET_PRODUCT */.N4, {
    variables: {
      slug
    }
  });
  const product = data && data.product.data;
  const related = data && data.product.related; // if ( error ) {
  //     return useRouter().push( '/pages/404' );
  // }

  return _slug_jsx("main", {
    className: "main"
  }, _slug_jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-3"
  }, _slug_jsx("div", {
    className: "container"
  }, _slug_jsx("ol", {
    className: "breadcrumb"
  }, _slug_jsx("li", {
    className: "breadcrumb-item"
  }, _slug_jsx(ALink/* default */.Z, {
    href: "/"
  }, _slug_jsx(index_esm/* IoMdHome */.QO$, {
    style: {
      fontSize: "16px"
    }
  }))), _slug_jsx("li", {
    className: "breadcrumb-item"
  }, _slug_jsx(ALink/* default */.Z, {
    href: "/shop"
  }, "Shop")), _slug_jsx("li", {
    className: "breadcrumb-item"
  }, product && product.categories.map((item, index) => _slug_jsx((external_react_default()).Fragment, {
    key: `category-${index}`
  }, _slug_jsx(ALink/* default */.Z, {
    href: {
      pathname: "/shop",
      query: {
        category: item.slug
      }
    }
  }, item.name), index < product.categories.length - 1 ? ',' : ''))), _slug_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, product && product.name)))), _slug_jsx("div", {
    className: "container pt-2"
  }, _slug_jsx("div", {
    className: "row"
  }, _slug_jsx(sidebar_one, null), _slug_jsx("div", {
    className: `col-lg-9 main-content pb-2 pt-0 skeleton-body skel-shop-products ${loading ? '' : 'loaded'}`
  }, _slug_jsx("div", {
    className: "product-single-container product-single-default product-left-sidebar pt-0"
  }, _slug_jsx("div", {
    className: "row"
  }, _slug_jsx(product_media_one/* default */.Z, {
    product: product,
    adClass: "col-lg-7 col-md-6"
  }), _slug_jsx(product_detail_one/* default */.Z, {
    adClass: "col-lg-5 col-md-6",
    product: product,
    prev: product && data.product.prev,
    next: product && data.product.next
  }))), _slug_jsx(single_tab_three/* default */.Z, {
    product: product,
    loading: loading
  }), _slug_jsx(related_products/* default */.Z, {
    adClass: "mb-1 border-0",
    products: related,
    loading: loading
  }))), _slug_jsx("hr", {
    className: "mt-0 m-b-5"
  })), _slug_jsx(product_widget_container/* default */.Z, null));
}

/* harmony default export */ var _slug_ = ((0,apollo/* default */.Z)({
  ssr: true
})(ProductLeftSidebar));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 7381:
/***/ (function(module) {

"use strict";
module.exports = require("@emotion/react");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 5768:
/***/ (function(module) {

"use strict";
module.exports = require("rc-tree");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 104:
/***/ (function(module) {

"use strict";
module.exports = require("react-awesome-reveal");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 6302:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-lightbox");;

/***/ }),

/***/ 7773:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-magnifiers");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 9058:
/***/ (function(module) {

"use strict";
module.exports = require("react-sticky-box");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,2806,5708,4229,4011,4138,8509,9915,9905,7029,7684,5023,2915,6775,7520], function() { return __webpack_exec__(7095); });
module.exports = __webpack_exports__;

})();