(function() {
var exports = {};
exports.id = 201;
exports.ids = [201];
exports.modules = {

/***/ 6280:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _slug_; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: external "react-image-lightbox"
var external_react_image_lightbox_ = __webpack_require__(6302);
var external_react_image_lightbox_default = /*#__PURE__*/__webpack_require__.n(external_react_image_lightbox_);
// EXTERNAL MODULE: external "react-image-magnifiers"
var external_react_image_magnifiers_ = __webpack_require__(7773);
// EXTERNAL MODULE: external "react-lazy-load-image-component"
var external_react_lazy_load_image_component_ = __webpack_require__(9290);
// EXTERNAL MODULE: ./components/features/owl-carousel.jsx
var owl_carousel = __webpack_require__(4138);
// EXTERNAL MODULE: ./utils/data/slider.js
var slider = __webpack_require__(8509);
;// CONCATENATED MODULE: ./components/partials/product/media/product-media-seven.jsx
var __jsx = (external_react_default()).createElement;



 //Import Custom Component



function ProductMediaSeven(props) {
  const {
    adClass = '',
    product,
    parent = ".product-single-default"
  } = props;
  const {
    0: mediaRef,
    1: setMediaRef
  } = (0,external_react_.useState)(null);
  const {
    0: openLB,
    1: setOpenLB
  } = (0,external_react_.useState)(false);
  const {
    0: photoIndex,
    1: setPhotoIndex
  } = (0,external_react_.useState)(0);
  const events = {
    onTranslate: function (e) {
      document.querySelector(`${parent} .prod-thumbnail .owl-dot.active`) && document.querySelector(`${parent} .prod-thumbnail .owl-dot.active`).classList.remove('active');
      let thumbs = document.querySelectorAll(`${parent} .prod-thumbnail .owl-dot`);
      thumbs[e.item.index].classList.add('active');
    },
    onTranslated: function (e) {
      setPhotoIndex(e.item.index);
    }
  };
  (0,external_react_.useEffect)(() => {
    if (product) {
      setOpenLB(false);
      setPhotoIndex(0);
      document.querySelector(`${parent} .prod-thumbnail .owl-dot.active`) && document.querySelector(`${parent} .prod-thumbnail .owl-dot.active`).classList.remove('active');
      document.querySelector(`${parent} .prod-thumbnail .owl-dot`).classList.add('active');
    }
  }, [product]);

  function isSale() {
    return product.price[0] !== product.price[1] && product.variants.length === 0 ? '-' + (100 * (product.price[1] - product.price[0]) / product.price[1]).toFixed(0) + '%' : product.variants.find(variant => variant.sale_price) ? "Sale" : false;
  }

  function openLightBox() {
    setOpenLB(true);
  }

  function closeLightBox() {
    setOpenLB(false);
  }

  function moveNextPhoto() {
    setPhotoIndex((photoIndex + 1) % product.large_pictures.length);
  }

  function movePrevPhoto() {
    setPhotoIndex((photoIndex + product.large_pictures.length - 1) % product.large_pictures.length);
  }

  function changeMediaIndex(index, e) {
    if (!e.currentTarget.classList.contains('active')) {
      let thumbs = e.currentTarget.closest('.prod-thumbnail');
      thumbs.querySelector('.owl-dot.active') && thumbs.querySelector('.owl-dot.active').classList.remove('active');
      e.currentTarget.classList.add('active');
    }

    mediaRef.current.goTo(index);
  }

  return __jsx("div", {
    className: `product-single-gallery ${adClass}`
  }, __jsx("div", {
    className: "skel-pro skel-magnifier-vertical skel-full col-12"
  }), product && __jsx((external_react_default()).Fragment, null, __jsx("div", {
    className: "product-slider-container mb-auto"
  }, __jsx("div", {
    className: "label-group"
  }, product.is_hot ? __jsx("div", {
    className: "product-label label-hot"
  }, "HOT") : '', isSale() ? __jsx("div", {
    className: "product-label label-sale"
  }, isSale()) : ''), __jsx(owl_carousel/* default */.Z, {
    adClass: "product-single-carousel owl-carousel owl-theme show-nav-hover",
    options: slider/* productSingleSlider */.Kk,
    events: events,
    onChangeRef: setMediaRef
  }, product && product.large_pictures.map((item, index) => __jsx("div", {
    className: "product-item",
    key: `product-item-${index}`
  }, __jsx(external_react_image_magnifiers_.Magnifier, {
    style: {
      paddingTop: "100%",
      position: "relative"
    },
    imageSrc: process.env.NEXT_PUBLIC_ASSET_URI + item.url,
    imageAlt: "product",
    mouseActivation: "hover",
    cursorStyleActive: "crosshair",
    dragToMove: false,
    className: "product-single-image"
  })))), __jsx("span", {
    className: "prod-full-screen",
    onClick: openLightBox
  }, __jsx("i", {
    className: "icon-plus"
  }))), __jsx("div", {
    className: "prod-thumbnail thumb-vertical owl-dots order-lg-first",
    id: "carousel-quick-dots"
  }, product && product.pictures.map((item, index) => __jsx("div", {
    className: "owl-dot media-with-lazy",
    key: `owl-dot-${index}`,
    onClick: e => changeMediaIndex(index, e)
  }, __jsx("figure", null, __jsx(external_react_lazy_load_image_component_.LazyLoadImage, {
    src: process.env.NEXT_PUBLIC_ASSET_URI + item.url,
    alt: "Thumbnail",
    width: "100%",
    height: "auto"
  }))))), openLB && __jsx((external_react_image_lightbox_default()), {
    mainSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[photoIndex].url,
    prevSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[(photoIndex + product.large_pictures.length - 1) % product.large_pictures.length].url,
    nextSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[(photoIndex + 1) % product.large_pictures.length].url,
    onCloseRequest: closeLightBox,
    onMoveNextRequest: moveNextPhoto,
    onMovePrevRequest: movePrevPhoto
  })));
}
// EXTERNAL MODULE: ./components/partials/product/details/product-detail-five.jsx
var product_detail_five = __webpack_require__(3825);
// EXTERNAL MODULE: ./components/partials/product/widgets/product-widget-container.jsx
var product_widget_container = __webpack_require__(4181);
// EXTERNAL MODULE: ./components/partials/product/widgets/related-products.jsx
var related_products = __webpack_require__(5655);
// EXTERNAL MODULE: external "react-tabs"
var external_react_tabs_ = __webpack_require__(7659);
;// CONCATENATED MODULE: ./components/partials/product/tabs/single-tab-four.jsx
var single_tab_four_jsx = (external_react_default()).createElement;




function SingleTab(props) {
  const {
    adClass = "",
    product
  } = props;

  function activeHandler(e) {
    e.preventDefault();
    document.querySelector('.add-product-review .active') && document.querySelector('.add-product-review .active').classList.remove('active');
    e.currentTarget.classList.add('active');
  }

  return single_tab_four_jsx((external_react_default()).Fragment, null, single_tab_four_jsx("div", {
    className: "skel-pro-tabs"
  }), product && single_tab_four_jsx(external_react_tabs_.Tabs, {
    className: `product-single-tabs ${adClass}`,
    selectedTabClassName: "active",
    selectedTabPanelClassName: "show"
  }, single_tab_four_jsx("div", {
    className: "row"
  }, single_tab_four_jsx("div", {
    className: "col-lg-2"
  }, single_tab_four_jsx(external_react_tabs_.TabList, {
    className: "nav nav-tabs"
  }, single_tab_four_jsx(external_react_tabs_.Tab, {
    className: "nav-item"
  }, single_tab_four_jsx(ALink/* default */.Z, {
    href: "#",
    className: "nav-link"
  }, "Description")), single_tab_four_jsx(external_react_tabs_.Tab, {
    className: "nav-item"
  }, single_tab_four_jsx(ALink/* default */.Z, {
    href: "#",
    className: "nav-link"
  }, "Size Guide")), single_tab_four_jsx(external_react_tabs_.Tab, {
    className: "nav-item"
  }, single_tab_four_jsx(ALink/* default */.Z, {
    href: "#",
    className: "nav-link"
  }, "Reviews (", product.reviews, ")")))), single_tab_four_jsx("div", {
    className: "col-lg-10"
  }, single_tab_four_jsx("div", {
    className: "tab-content"
  }, single_tab_four_jsx(external_react_tabs_.TabPanel, {
    className: "tab-pane fade"
  }, single_tab_four_jsx("div", {
    className: "product-desc-content"
  }, single_tab_four_jsx("p", null, product.short_description), single_tab_four_jsx("ul", null, single_tab_four_jsx("li", null, "Any Product types that You want - Simple, Configurable"), single_tab_four_jsx("li", null, "Downloadable/Digital Products, Virtual Products"), single_tab_four_jsx("li", null, "Inventory Management with Backordered items")), single_tab_four_jsx("p", null, "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "))), single_tab_four_jsx(external_react_tabs_.TabPanel, {
    className: "tab-pane fade"
  }, single_tab_four_jsx("div", {
    className: "product-size-content"
  }, single_tab_four_jsx("div", {
    className: "row"
  }, single_tab_four_jsx("div", {
    className: "col-md-4"
  }, single_tab_four_jsx("img", {
    src: "images/products/single/body-shape.png",
    alt: "body shape"
  })), single_tab_four_jsx("div", {
    className: "col-md-8"
  }, single_tab_four_jsx("table", {
    className: "table table-size"
  }, single_tab_four_jsx("thead", null, single_tab_four_jsx("tr", null, single_tab_four_jsx("th", null, "SIZE"), single_tab_four_jsx("th", null, "CHEST (in.)"), single_tab_four_jsx("th", null, "WAIST (in.)"), single_tab_four_jsx("th", null, "HIPS (in.)"))), single_tab_four_jsx("tbody", null, single_tab_four_jsx("tr", null, single_tab_four_jsx("td", null, "XS"), single_tab_four_jsx("td", null, "34-36"), single_tab_four_jsx("td", null, "27-29"), single_tab_four_jsx("td", null, "34.5-36.5")), single_tab_four_jsx("tr", null, single_tab_four_jsx("td", null, "S"), single_tab_four_jsx("td", null, "36-38"), single_tab_four_jsx("td", null, "29-31"), single_tab_four_jsx("td", null, "36.5-38.5")), single_tab_four_jsx("tr", null, single_tab_four_jsx("td", null, "M"), single_tab_four_jsx("td", null, "38-40"), single_tab_four_jsx("td", null, "31-33"), single_tab_four_jsx("td", null, "38.5-40.5")), single_tab_four_jsx("tr", null, single_tab_four_jsx("td", null, "L"), single_tab_four_jsx("td", null, "40-42"), single_tab_four_jsx("td", null, "33-36"), single_tab_four_jsx("td", null, "40.5-43.5")), single_tab_four_jsx("tr", null, single_tab_four_jsx("td", null, "XL"), single_tab_four_jsx("td", null, "42-45"), single_tab_four_jsx("td", null, "36-40"), single_tab_four_jsx("td", null, "43.5-47.5")), single_tab_four_jsx("tr", null, single_tab_four_jsx("td", null, "XLL"), single_tab_four_jsx("td", null, "45-48"), single_tab_four_jsx("td", null, "40-44"), single_tab_four_jsx("td", null, "47.5-51.5")))))))), single_tab_four_jsx(external_react_tabs_.TabPanel, {
    className: "tab-pane fade"
  }, single_tab_four_jsx("div", {
    className: "product-reviews-content"
  }, product.reviews !== 0 ? single_tab_four_jsx((external_react_default()).Fragment, null, single_tab_four_jsx("h3", {
    className: "reviews-title"
  }, "1 review for Men Black Sports Shoes"), single_tab_four_jsx("div", {
    className: "comment-list"
  }, single_tab_four_jsx("div", {
    className: "comments"
  }, single_tab_four_jsx("figure", {
    className: "img-thumbnail"
  }, single_tab_four_jsx("img", {
    src: "images/blog/author.jpg",
    alt: "author",
    width: "80",
    className: "80"
  })), single_tab_four_jsx("div", {
    className: "comment-block"
  }, single_tab_four_jsx("div", {
    className: "comment-header"
  }, single_tab_four_jsx("div", {
    className: "comment-arrow"
  }), single_tab_four_jsx("div", {
    className: "ratings-container float-sm-right"
  }, single_tab_four_jsx("div", {
    className: "product-ratings"
  }, single_tab_four_jsx("span", {
    className: "ratings",
    style: {
      width: `${20 * product.ratings}%`
    }
  }), single_tab_four_jsx("span", {
    className: "tooltiptext tooltip-top"
  }, product.ratings.toFixed(2)))), single_tab_four_jsx("span", {
    className: "comment-by"
  }, single_tab_four_jsx("strong", null, "Joe Doe"), " \u2013 April 12, 2018")), single_tab_four_jsx("div", {
    className: "comment-content"
  }, single_tab_four_jsx("p", null, "Excellent.")))))) : single_tab_four_jsx((external_react_default()).Fragment, null, single_tab_four_jsx("h3", {
    className: "reviews-title"
  }, "Review"), single_tab_four_jsx("p", null, "There are no reviews yet.")), single_tab_four_jsx("div", {
    className: "divider"
  }), single_tab_four_jsx("div", {
    className: "add-product-review"
  }, single_tab_four_jsx("div", {
    className: "add-product-review"
  }, single_tab_four_jsx("h3", {
    className: "review-title"
  }, "Add a review"), single_tab_four_jsx("form", {
    action: "#",
    className: "comment-form m-0"
  }, single_tab_four_jsx("div", {
    className: "rating-form"
  }, single_tab_four_jsx("label", {
    htmlFor: "rating"
  }, "Your rating ", single_tab_four_jsx("span", {
    className: "required"
  }, "*")), single_tab_four_jsx("span", {
    className: "rating-stars"
  }, single_tab_four_jsx("a", {
    className: "star-1",
    href: "#",
    onClick: activeHandler
  }, "1"), single_tab_four_jsx("a", {
    className: "star-2",
    href: "#",
    onClick: activeHandler
  }, "2"), single_tab_four_jsx("a", {
    className: "star-3",
    href: "#",
    onClick: activeHandler
  }, "3"), single_tab_four_jsx("a", {
    className: "star-4",
    href: "#",
    onClick: activeHandler
  }, "4"), single_tab_four_jsx("a", {
    className: "star-5",
    href: "#",
    onClick: activeHandler
  }, "5"))), single_tab_four_jsx("div", {
    className: "form-group"
  }, single_tab_four_jsx("label", null, "Your review ", single_tab_four_jsx("span", {
    className: "required"
  }, "*")), single_tab_four_jsx("textarea", {
    cols: "5",
    rows: "6",
    className: "form-control form-control-sm"
  })), single_tab_four_jsx("div", {
    className: "row"
  }, single_tab_four_jsx("div", {
    className: "col-md-6 col-xl-12"
  }, single_tab_four_jsx("div", {
    className: "form-group"
  }, single_tab_four_jsx("label", null, "Name ", single_tab_four_jsx("span", {
    className: "required"
  }, "*")), single_tab_four_jsx("input", {
    type: "text",
    className: "form-control form-control-sm",
    required: true
  }))), single_tab_four_jsx("div", {
    className: "col-md-6 col-xl-12"
  }, single_tab_four_jsx("div", {
    className: "form-group"
  }, single_tab_four_jsx("label", null, "Email ", single_tab_four_jsx("span", {
    className: "required"
  }, "*")), single_tab_four_jsx("input", {
    type: "text",
    className: "form-control form-control-sm",
    required: true
  }))), single_tab_four_jsx("div", {
    className: "col-md-12"
  }, single_tab_four_jsx("div", {
    className: "custom-control custom-checkbox"
  }, single_tab_four_jsx("input", {
    type: "checkbox",
    className: "custom-control-input",
    id: "save-name"
  }), single_tab_four_jsx("label", {
    className: "custom-control-label mb-0",
    htmlFor: "save-name"
  }, "Save my name, email, and website in this browser for the next time I comment.")))), single_tab_four_jsx("input", {
    type: "submit",
    className: "btn btn-primary",
    value: "Submit"
  })))))))))));
}

/* harmony default export */ var single_tab_four = (SingleTab);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/product/center/[slug].js
var _slug_jsx = (external_react_default()).createElement;


 // Import Apollo Server and Query


 // Import Custom Component









function ProductCenter() {
  if (!(0,router_.useRouter)().query.slug) return _slug_jsx("div", {
    className: "loading-overlay"
  }, _slug_jsx("div", {
    className: "bounce-loader"
  }, _slug_jsx("div", {
    className: "bounce1"
  }), _slug_jsx("div", {
    className: "bounce2"
  }), _slug_jsx("div", {
    className: "bounce3"
  })));
  const slug = (0,router_.useRouter)().query.slug;
  const {
    data,
    loading,
    error
  } = (0,react_hooks_.useQuery)(queries/* GET_PRODUCT */.N4, {
    variables: {
      slug
    }
  });
  const product = data && data.product.data;
  const related = data && data.product.related; // if ( error ) {
  //     return useRouter().push( '/pages/404' );
  // }

  return _slug_jsx("main", {
    className: "main"
  }, _slug_jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-4"
  }, _slug_jsx("div", {
    className: "container"
  }, _slug_jsx("ol", {
    className: "breadcrumb"
  }, _slug_jsx("li", {
    className: "breadcrumb-item"
  }, _slug_jsx(ALink/* default */.Z, {
    href: "/"
  }, _slug_jsx(index_esm/* IoMdHome */.QO$, {
    style: {
      fontSize: "16px"
    }
  }))), _slug_jsx("li", {
    className: "breadcrumb-item"
  }, _slug_jsx(ALink/* default */.Z, {
    href: "/shop"
  }, "Shop")), _slug_jsx("li", {
    className: "breadcrumb-item"
  }, product && product.categories.map((item, index) => _slug_jsx((external_react_default()).Fragment, {
    key: `category-${index}`
  }, _slug_jsx(ALink/* default */.Z, {
    href: {
      pathname: "/shop",
      query: {
        category: item.slug
      }
    }
  }, item.name), index < product.categories.length - 1 ? ',' : ''))), _slug_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, product && product.name)))), _slug_jsx("div", {
    className: `container pt-2 skeleton-body skel-shop-products ${loading ? '' : 'loaded'}`
  }, _slug_jsx("div", {
    className: `product-single-container product-single-default product-center-vertical`
  }, _slug_jsx("div", {
    className: "row"
  }, _slug_jsx(product_detail_five/* default */.Z, {
    adClassOne: "order-1 order-lg-0",
    adClassTwo: "order-2 order-lg-2",
    type: "1",
    product: product,
    prev: product && data.product.prev,
    next: product && data.product.next
  }), _slug_jsx(ProductMediaSeven, {
    adClass: "col-lg-6 d-lg-flex order-0 order-lg-0",
    subClass: "col-lg-12",
    product: product
  }))), _slug_jsx(single_tab_four, {
    product: product,
    adClass: "product-tabs-list pt-3 mb-0 mt-1"
  }), _slug_jsx(related_products/* default */.Z, {
    products: related,
    loading: loading
  }), _slug_jsx("hr", {
    className: "mt-0 m-b-5"
  })), _slug_jsx(product_widget_container/* default */.Z, null));
}

/* harmony default export */ var _slug_ = ((0,apollo/* default */.Z)({
  ssr: true
})(ProductCenter));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 7381:
/***/ (function(module) {

"use strict";
module.exports = require("@emotion/react");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 104:
/***/ (function(module) {

"use strict";
module.exports = require("react-awesome-reveal");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 6302:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-lightbox");;

/***/ }),

/***/ 7773:
/***/ (function(module) {

"use strict";
module.exports = require("react-image-magnifiers");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 9058:
/***/ (function(module) {

"use strict";
module.exports = require("react-sticky-box");;

/***/ }),

/***/ 7659:
/***/ (function(module) {

"use strict";
module.exports = require("react-tabs");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,2806,5708,4229,4011,4138,8509,9915,9905,7029,7684,5023,3825], function() { return __webpack_exec__(6280); });
module.exports = __webpack_exports__;

})();