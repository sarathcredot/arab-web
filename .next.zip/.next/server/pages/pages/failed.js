(function() {
var exports = {};
exports.id = 5178;
exports.ids = [5178];
exports.modules = {

/***/ 3870:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);



function failed() {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();

  const shopHandle = e => {
    e.preventDefault();
    router.push('/shop');
  };

  return __jsx("div", {
    className: "container ",
    style: {
      textAlign: "center"
    }
  }, __jsx("div", {
    class: "centered-content",
    style: {
      marginBottom: "134px"
    }
  }, __jsx("img", {
    src: "/images/failed.svg",
    alt: "Thank You Image"
  }), __jsx("h4", null, "Oops! something Went Wrong"), __jsx("span", {
    style: {
      fontWeight: "400px",
      fontSize: "12px",
      color: "#000000"
    }
  }, "We are unable to process your order at this time"), __jsx("div", {
    class: "buttons"
  }, __jsx("button", {
    onClick: e => shopHandle(e)
  }, "TRY AGAIN"))), __jsx("hr", null));
}

/* harmony default export */ __webpack_exports__["default"] = (failed);

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(3870));
module.exports = __webpack_exports__;

})();