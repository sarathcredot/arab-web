(function() {
var exports = {};
exports.id = 2749;
exports.ids = [2749];
exports.modules = {

/***/ 9270:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ AboutUs; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_ALink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8974);
/* harmony import */ var _components_features_owl_carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4138);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6442);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);





function AboutUs() {
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .countTo */ .yZ)();
  }, []);
  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx(Helmet, null, __jsx("title", null, "About Us | Arab Deals")), __jsx("main", {
    className: "main about"
  }, __jsx("div", {
    className: "page-header page-header-bg text-left",
    style: {
      background: `50%/cover #D4E1EA url(images/page-header-bg.jpg)`
    }
  }, __jsx("div", {
    className: "container"
  }, __jsx("h1", null, __jsx("span", null, "ABOUT US"), "OUR COMPANY"), __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "/pages/contact-us",
    className: "btn btn-dark"
  }, "Contact"))), __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav"
  }, __jsx("div", {
    className: "container"
  }, __jsx("ol", {
    className: "breadcrumb"
  }, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "/"
  }, "Home")), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, "About Us")))), __jsx("div", {
    className: "about-section"
  }, __jsx("div", {
    className: "container"
  }, __jsx("h2", {
    className: "subtitle"
  }, "OUR STORY"), __jsx("p", null, "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged."), __jsx("p", null, "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."), __jsx("p", {
    className: "lead"
  }, "\u201C Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model search for evolved over sometimes by accident, sometimes on purpose \u201D"))), __jsx("div", {
    className: "features-section bg-gray"
  }, __jsx("div", {
    className: "container"
  }, __jsx("h2", {
    className: "subtitle"
  }, "WHY CHOOSE US"), __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-4 mb-4"
  }, __jsx("div", {
    className: "feature-box bg-white"
  }, __jsx("i", {
    className: "icon-shipped"
  }), __jsx("div", {
    className: "feature-box-content p-0"
  }, __jsx("h3", null, "Free Shipping"), __jsx("p", null, "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industr.")))), __jsx("div", {
    className: "col-lg-4 mb-4"
  }, __jsx("div", {
    className: "feature-box bg-white"
  }, __jsx("i", {
    className: "icon-us-dollar"
  }), __jsx("div", {
    className: "feature-box-content p-0"
  }, __jsx("h3", null, "100% Money Back Guarantee"), __jsx("p", null, "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industr.")))), __jsx("div", {
    className: "col-lg-4 mb-4"
  }, __jsx("div", {
    className: "feature-box bg-white"
  }, __jsx("i", {
    className: "icon-online-support"
  }), __jsx("div", {
    className: "feature-box-content p-0"
  }, __jsx("h3", null, "Online Support 24/7"), __jsx("p", null, "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industr."))))))), __jsx("div", {
    className: "testimonials-section"
  }, __jsx("div", {
    className: "container"
  }, __jsx("h2", {
    className: "subtitle text-center"
  }, "HAPPY CLIENTS"), __jsx(_components_features_owl_carousel__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    adClass: "testimonials-carousel owl-theme images-left",
    options: {
      margin: 20,
      nav: false,
      dots: false,
      responsive: {
        0: {
          items: 1
        },
        992: {
          items: 2
        }
      }
    }
  }, __jsx("div", {
    className: "testimonial"
  }, __jsx("div", {
    className: "testimonial-owner"
  }, __jsx("figure", null, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__.LazyLoadImage, {
    src: "images/clients/client1.png",
    alt: "client",
    width: "40",
    height: "40"
  })), __jsx("div", null, __jsx("strong", {
    className: "testimonial-title"
  }, "John Smith"), __jsx("span", null, "SMARTWAVE CEO"))), __jsx("blockquote", null, __jsx("p", null, "Lorem ipsum dolor sit amet, consectetur elitad adipiscing Cras non placerat mipsum dolor sit amet, consectetur elitad adipiscing cas non placerat mi."))), __jsx("div", {
    className: "testimonial"
  }, __jsx("div", {
    className: "testimonial-owner"
  }, __jsx("figure", null, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__.LazyLoadImage, {
    src: "images/clients/client2.png",
    alt: "client",
    width: "40",
    height: "40"
  })), __jsx("div", null, __jsx("strong", {
    className: "testimonial-title"
  }, "Bob Smith"), __jsx("span", null, "SMARTWAVE CEO"))), __jsx("blockquote", null, __jsx("p", null, "Lorem ipsum dolor sit amet, consectetur elitad adipiscing Cras non placerat mipsum dolor sit amet, consectetur elitad adipiscing cas non placerat mi."))), __jsx("div", {
    className: "testimonial"
  }, __jsx("div", {
    className: "testimonial-owner"
  }, __jsx("figure", null, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__.LazyLoadImage, {
    src: "images/clients/client1.png",
    alt: "client",
    width: "40",
    height: "40"
  })), __jsx("div", null, __jsx("strong", {
    className: "testimonial-title"
  }, "John Smith"), __jsx("span", null, "SMARTWAVE CEO"))), __jsx("blockquote", null, __jsx("p", null, "Lorem ipsum dolor sit amet, consectetur elitad adipiscing Cras non placerat mipsum dolor sit amet, consectetur elitad adipiscing cas non placerat mi.")))))), __jsx("div", {
    className: "counters-section bg-gray"
  }, __jsx("div", {
    className: "container"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-6 col-md-4 count-container"
  }, __jsx("div", {
    className: "count-wrapper"
  }, __jsx("span", {
    className: "count-to",
    "data-from": "0",
    "data-to": "200",
    "data-speed": "2000",
    "data-refresh-interval": "50"
  }, "200"), "+"), __jsx("h4", {
    className: "count-title"
  }, "MILLION CUSTOMERS")), __jsx("div", {
    className: "col-6 col-md-4 count-container"
  }, __jsx("div", {
    className: "count-wrapper"
  }, __jsx("span", {
    className: "count-to",
    "data-from": "0",
    "data-to": "1800",
    "data-speed": "2000",
    "data-refresh-interval": "50"
  }, "1800"), "+"), __jsx("h4", {
    className: "count-title"
  }, "TEAM MEMBERS")), __jsx("div", {
    className: "col-6 col-md-4 count-container"
  }, __jsx("div", {
    className: "count-wrapper line-height-1"
  }, __jsx("span", {
    className: "count-to",
    "data-from": "0",
    "data-to": "24",
    "data-speed": "2000",
    "data-refresh-interval": "50"
  }, "24"), __jsx("span", null, "HR")), __jsx("h4", {
    className: "count-title"
  }, "SUPPORT AVAILABLE")), __jsx("div", {
    className: "col-6 col-md-4 count-container"
  }, __jsx("div", {
    className: "count-wrapper"
  }, __jsx("span", {
    className: "count-to",
    "data-from": "0",
    "data-to": "265",
    "data-speed": "2000",
    "data-refresh-interval": "50"
  }, "265"), "+"), __jsx("h4", {
    className: "count-title"
  }, "SUPPORT AVAILABLE")), __jsx("div", {
    className: "col-6 col-md-4 count-container"
  }, __jsx("div", {
    className: "count-wrapper line-height-1"
  }, __jsx("span", {
    className: "count-to",
    "data-from": "0",
    "data-to": "99",
    "data-speed": "2000",
    "data-refresh-interval": "50"
  }, "99"), __jsx("span", null, "%")), __jsx("h4", {
    className: "count-title"
  }, "SUPPORT AVAILABLE")))))));
}

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,6285,4138,6442], function() { return __webpack_exec__(9270); });
module.exports = __webpack_exports__;

})();