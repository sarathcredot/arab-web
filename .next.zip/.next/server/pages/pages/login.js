(function() {
var exports = {};
exports.id = 8158;
exports.ids = [8158];
exports.modules = {

/***/ 9334:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "LOGIN": function() { return /* binding */ LOGIN; },
  "OTP_VERIFY": function() { return /* binding */ OTP_VERIFY; },
  "default": function() { return /* binding */ login; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
;// CONCATENATED MODULE: external "react-otp-input"
var external_react_otp_input_namespaceObject = require("react-otp-input");;
var external_react_otp_input_default = /*#__PURE__*/__webpack_require__.n(external_react_otp_input_namespaceObject);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(8074);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(2034);
// EXTERNAL MODULE: ./components/common/partials/main-menu.jsx
var main_menu = __webpack_require__(980);
// EXTERNAL MODULE: external "react-helmet"
var external_react_helmet_ = __webpack_require__(6481);
;// CONCATENATED MODULE: ./pages/pages/login.js
var __jsx = (external_react_default()).createElement;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



 // import { useQuery,gql,useMutation } from "@apollo/react-hooks";







 // import { useForm, Controller } from "react-hook-form";

const LOGIN = client_.gql`
  mutation UserLoginOtp($input: userLoginOtpInput!) {
    userLoginOtp(input: $input) {
      message
      mobileNumber
      _id
    }
  }
`;
const OTP_VERIFY = client_.gql`
  mutation UserVerifyOtp($input: userVerifyOtpInput!) {
    userVerifyOtp(input: $input) {
      message
      token
      userId
    }
  }
`;

function Login({
  mutate
}) {
  const router = (0,router_.useRouter)();
  const {
    origin
  } = router.query;
  const formatedOrigin = origin ? origin === null || origin === void 0 ? void 0 : origin.replace("-", "/") : null;
  const {
    0: isOtp,
    1: SetIsOtp
  } = (0,external_react_.useState)(false);
  const {
    0: mobileNumber,
    1: setMobileNumber
  } = (0,external_react_.useState)("");
  const {
    0: error,
    1: setError
  } = (0,external_react_.useState)("");
  const {
    0: otperror,
    1: setOtperror
  } = (0,external_react_.useState)("");
  const {
    0: otp,
    1: setOtp
  } = (0,external_react_.useState)("");
  const {
    0: otpId,
    1: setOtpTd
  } = (0,external_react_.useState)("");
  const [userLoginOtp] = (0,client_.useMutation)(LOGIN);
  const [UserVerifyOtp] = (0,client_.useMutation)(OTP_VERIFY);

  const handleOtpChange = async event => {
    event.preventDefault();

    try {
      if (!mobileNumber.trim()) {
        setError("Mobile number is required");
        return;
      }

      const response = await userLoginOtp({
        variables: {
          input: {
            mobileNumber: `+968 ${mobileNumber}`
          }
        }
      });
      setOtpTd(response.data.userLoginOtp._id);
      external_react_toastify_.toast.success(__jsx("div", {
        style: {
          padding: "10px"
        }
      }, "OTP sent successfully"));
      SetIsOtp(true);
    } catch (error) {
      console.log("error", error);
    }
  };

  const handleResentotp = async () => {
    try {
      const response = await userLoginOtp({
        variables: {
          input: {
            mobileNumber: `+968 ${mobileNumber}`
          }
        }
      });

      if (response) {
        external_react_toastify_.toast.success(__jsx("div", {
          style: {
            padding: "10px"
          }
        }, "OTP sent successfully"));
      }
    } catch (error) {
      external_react_toastify_.toast.error(__jsx("div", {
        style: {
          padding: "10px"
        }
      }, error === null || error === void 0 ? void 0 : error.message));
      console.log("error", error);
    }
  };

  const BULK_ADD_TO_CART = client_.gql`
    mutation BulkAddToCart($input: BulkAddToCartInput!) {
      bulkAddToCart(input: $input) {
        message
      }
    }
  `;
  const [BulkAddToCart] = (0,client_.useMutation)(BULK_ADD_TO_CART);

  const handleVerifyOTP = async event => {
    event.preventDefault();

    try {
      if (!otp) {
        setOtperror("Otp is required");
        return;
      }

      const response = await UserVerifyOtp({
        variables: {
          input: {
            code: otp,
            _id: otpId
          }
        }
      });

      if (response) {
        var _response$data, _response$data$userVe, _response$data2, _response$data2$userV;

        localStorage.setItem("arabtoken", response === null || response === void 0 ? void 0 : (_response$data = response.data) === null || _response$data === void 0 ? void 0 : (_response$data$userVe = _response$data.userVerifyOtp) === null || _response$data$userVe === void 0 ? void 0 : _response$data$userVe.token);
        localStorage.setItem("userId", response === null || response === void 0 ? void 0 : (_response$data2 = response.data) === null || _response$data2 === void 0 ? void 0 : (_response$data2$userV = _response$data2.userVerifyOtp) === null || _response$data2$userV === void 0 ? void 0 : _response$data2$userV.userId);

        try {
          const cartItems = JSON.parse(localStorage.getItem("cart"));

          if ((cartItems === null || cartItems === void 0 ? void 0 : cartItems.length) > 0) {
            const result = await BulkAddToCart({
              variables: {
                input: {
                  products: cartItems.map(item => ({
                    productId: item.productId,
                    quantity: item.quantity
                  }))
                }
              }
            });
          }

          localStorage.removeItem("cart");
        } catch (error) {
          console.log(error);
        }

        if (formatedOrigin) {
          return router.push(`/${formatedOrigin}`);
        }

        const historyUrl = localStorage.getItem("historyUrl");

        if (historyUrl) {
          return router.push(historyUrl);
        } else {
          return router.push("/");
        }
      }
    } catch (error) {
      console.log("error", error);
    }
  };

  return __jsx((external_react_default()).Fragment, null, __jsx(external_react_helmet_.Helmet, null, __jsx("title", null, "Login | Arab Deals")), __jsx("main", {
    className: "main"
  }, __jsx("div", {
    className: " login-container container",
    style: {
      marginTop: "0",
      position: "relative"
    }
  }, __jsx("div", {
    style: {
      zIndex: "99",
      position: "absolute",
      width: "100%",
      left: "0",
      right: "0",
      background: "white"
    },
    className: "custom_loginresp"
  }, __jsx("div", null, __jsx(main_menu/* default */.ZP, null))), __jsx("div", {
    className: "container custom_login_space "
  }, __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-0",
    style: {
      paddingBottom: "15px",
      borderBottom: "1px solid #F0F0F0"
    }
  })), __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-12 mx-auto custom_headlog"
  }, isOtp ? __jsx("div", {
    className: "row custom-loginleft" // style={{ marginLeft: "115px" }}

  }, __jsx("div", {
    className: "col-md-6"
  }, __jsx("div", {
    className: "heading mb-1 otpcontainer"
  }, __jsx("h2", {
    className: "title"
  }, "Verify Phone Number"), __jsx("div", {
    className: ""
  }, __jsx("p", {
    className: "",
    style: {
      marginTop: "20px",
      paddingBottom: "20px",
      fontSize: "12px",
      color: "#777777",
      fontWeight: "400"
    }
  }, "Secure Your Account, Shop With Confidence."))), __jsx("form", {
    style: {
      marginTop: "70px"
    }
  }, __jsx("div", {
    className: "mt-3"
  }, __jsx((external_react_otp_input_default()), {
    value: otp,
    onChange: setOtp,
    numInputs: 5,
    containerStyle: {
      textAlign: "center",
      width: "60px",
      height: "60px",
      gap: "24px"
    },
    renderInput: props => __jsx("input", _extends({}, props, {
      className: "otpbox" // style={{
      //   width: "60px",
      //   height: "60px",
      //   textAlign: "center",
      //   fontSize: "18px ",
      //   borderColor: "#ECECEC",
      //   outline: "none",
      //   border: "1px solid #ECECEC",
      // }}

    }))
  }), __jsx("button", {
    type: "submit",
    className: "btn btn-dark btn-md ",
    style: {
      marginTop: "48px",
      fontWeight: "600"
    },
    onClick: handleVerifyOTP
  }, "Verify OTP"), otperror && __jsx("div", {
    style: {
      color: "red"
    }
  }, otperror), __jsx("div", {
    className: "resend-action",
    style: {
      marginTop: "33px"
    }
  }, __jsx("p", {
    style: {
      fontWeight: "400",
      fontSize: "12px",
      color: "#000000"
    }
  }, "Don't have OTP ?", __jsx("span", {
    style: {
      paddingLeft: "5px",
      color: "#399E0A",
      fontWeight: "500",
      cursor: "pointer"
    },
    className: "btn-text",
    onClick: handleResentotp
  }, "Resend")))))), __jsx("div", {
    className: "col-md-6"
  }, __jsx("div", null, __jsx("img", {
    class: "google-icon",
    src: "images\\brands\\loginBanner.svg"
  })))) : __jsx("div", {
    className: "row custom-loginleft"
  }, __jsx("div", {
    className: "col-md-6 left-login-section"
  }, __jsx("div", {
    className: "heading mb-1"
  }, __jsx("h2", {
    className: "title"
  }, "Login/ Register to your account"), __jsx("div", {
    className: ""
  }, __jsx("p", {
    className: "",
    style: {
      marginTop: "20px",
      fontSize: "12px",
      color: "#777777",
      fontWeight: "400"
    }
  }, "Access Exclusive Offer Now."))), __jsx("div", null), __jsx("form", {
    style: {
      marginTop: "70px"
    }
  }, __jsx("div", {
    className: "container"
  }, __jsx("div", {
    className: "input-group",
    style: {
      position: "relative"
    }
  }, __jsx("div", {
    className: "input-group-prepend",
    style: {
      position: "absolute"
    }
  }, __jsx("span", {
    className: "input-group-text countrycodeinput",
    style: {
      padding: "10px"
    }
  }, __jsx("img", {
    src: "images/brands/flag1.svg",
    alt: "Flag",
    width: "24",
    height: "20"
  }), "+968")), __jsx("input", {
    type: "number",
    placeholder: "Enter Mobile Number",
    className: "form-input form-wide",
    value: mobileNumber,
    onChange: e => setMobileNumber(e.target.value),
    style: {
      outline: "none",
      paddingLeft: "80px"
    }
  }))), error && __jsx("div", {
    style: {
      color: "red"
    }
  }, error), __jsx("button", {
    type: "submit",
    className: "btn btn-dark btn-md ",
    style: {
      marginTop: "36px",
      fontWeight: "600"
    },
    onClick: handleOtpChange
  }, "GET OTP"))), __jsx("div", {
    className: "col-md-6",
    style: {
      paddingRight: "0"
    }
  }, __jsx("div", null, __jsx("img", {
    class: "google-icon",
    src: "images\\brands\\loginBanner.svg"
  })))))))));
}

/* harmony default export */ var login = ((0,apollo/* default */.Z)({
  ssr: true
})(Login));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 6481:
/***/ (function(module) {

"use strict";
module.exports = require("react-helmet");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,8193,6285,7164,4733,4229,4138,9915,980], function() { return __webpack_exec__(9334); });
module.exports = __webpack_exports__;

})();