(function() {
var exports = {};
exports.id = 5426;
exports.ids = [5426];
exports.modules = {

/***/ 2052:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ACCOUNT_DETAIL": function() { return /* binding */ ACCOUNT_DETAIL; },
/* harmony export */   "USER_DETAIL": function() { return /* binding */ USER_DETAIL; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_ALink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8974);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7164);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_6__);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);







const ACCOUNT_DETAIL = _apollo_client__WEBPACK_IMPORTED_MODULE_4__.gql`
  mutation UpdateUserProfile($input: updateUserProfileInput!) {
    updateUserProfile(input: $input) {
      message
    }
  }
`;
const USER_DETAIL = _apollo_client__WEBPACK_IMPORTED_MODULE_4__.gql`
  query GetUserRecord($input: userInput!) {
    getUserRecord(input: $input) {
      message
      record {
        _id
        firstName
        displayName
        email
        lastName
      }
    }
  }
`;

function accountdetails() {
  var _localStorage, _errors$firstName, _errors$lastName, _errors$displayName, _errors$email;

  const id = (_localStorage = localStorage) === null || _localStorage === void 0 ? void 0 : _localStorage.getItem("userId");
  const [userdetail, {
    loading: userloading,
    error: usererror,
    data: userData,
    refetch
  }] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_4__.useLazyQuery)(USER_DETAIL);
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: {
      errors
    },
    control
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    defaultValues: {
      firstName: "",
      lastName: "",
      displayName: "",
      email: "" // crLicense:""

    }
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    userdetail({
      variables: {
        input: {
          _id: id
        }
      }
    }); // setValue("firstName",userData?.getUserRecord?.record?.firstName)
  }, [id]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (userData && userData.getUserRecord && userData.getUserRecord.record) {
      var _userData$getUserReco, _userData$getUserReco2, _userData$getUserReco3, _userData$getUserReco4;

      const {
        firstName
      } = userData.getUserRecord.record;
      setValue("firstName", firstName);
      setValue("lastName", (_userData$getUserReco = userData.getUserRecord.record) === null || _userData$getUserReco === void 0 ? void 0 : _userData$getUserReco.lastName);
      setValue("email", (_userData$getUserReco2 = userData.getUserRecord.record) === null || _userData$getUserReco2 === void 0 ? void 0 : _userData$getUserReco2.email);
      setValue("displayName", userData === null || userData === void 0 ? void 0 : (_userData$getUserReco3 = userData.getUserRecord) === null || _userData$getUserReco3 === void 0 ? void 0 : (_userData$getUserReco4 = _userData$getUserReco3.record) === null || _userData$getUserReco4 === void 0 ? void 0 : _userData$getUserReco4.displayName);
    }
  }, [userData]);
  const [UpdateUserProfile] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_4__.useMutation)(ACCOUNT_DETAIL);

  const onSubmit = async values => {
    values._id = id; // e.preventDefault();

    try {
      // if (!mobileNumber.trim()) {
      //   setError("Mobile number is required");
      //   return;
      // }
      const response = await UpdateUserProfile({
        variables: {
          input: {
            firstName: values.firstName,
            email: values === null || values === void 0 ? void 0 : values.email,
            lastName: values === null || values === void 0 ? void 0 : values.lastName,
            displayName: values === null || values === void 0 ? void 0 : values.displayName
          }
        }
      });

      if (response) {
        var _response$data, _response$data$update;

        react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.success(response === null || response === void 0 ? void 0 : (_response$data = response.data) === null || _response$data === void 0 ? void 0 : (_response$data$update = _response$data.updateUserProfile) === null || _response$data$update === void 0 ? void 0 : _response$data$update.message);
        reset();
        refetch();
      }

      SetIsOtp(true);
    } catch (error) {
      console.log("error", error);
    }
  };

  const fieldRules = {
    firstName: {
      required: "FirstName is required"
    },
    lastName: {
      required: "LastName is required"
    },
    displayName: {
      required: "DisplayName is required"
    },
    email: {
      required: "Email is required"
    }
  };
  return __jsx("main", {
    className: "main main-test"
  }, __jsx("div", {
    className: " d-flex flex-column align-items-center",
    style: {
      backgroundColor: "#F9F9F9"
    }
  }, __jsx("ul", {
    className: "checkout-progress-bar d-flex justify-content-center flex-wrap"
  }, __jsx("li", null, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "/pages/account"
  }, "My Account")), __jsx("li", {
    className: "active"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "/pages/accountdetails"
  }, "Account Details")))), __jsx("div", {
    className: "container checkout-container"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-12"
  }, __jsx("ul", {
    className: "checkout-steps"
  }, __jsx("li", null, __jsx("div", {
    className: "container",
    style: {
      marginTop: "3rem",
      borderBottom: "1px solid",
      borderColor: "#E2E2E2",
      padding: "2px"
    }
  }, __jsx("h2", {
    className: "step-title"
  }, "Account Details")), __jsx("form", {
    onSubmit: handleSubmit(onSubmit),
    id: "checkout-form"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-md-6 mb-2"
  }, __jsx("div", {
    className: "form-group mb-0"
  }, __jsx("label", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      lineHeight: "20px"
    }
  }, "First name", " ", __jsx("ab", {
    className: "required",
    title: "required"
  }, "*")), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
    control: control,
    name: "firstName",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    }),
    rules: fieldRules.firstName
  })), errors !== null && errors !== void 0 && errors.firstName ? __jsx("div", {
    style: {
      color: "red",
      marginTop: "10px"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$firstName = errors.firstName) === null || _errors$firstName === void 0 ? void 0 : _errors$firstName.message) : null), __jsx("div", {
    className: "col-md-6"
  }, __jsx("div", {
    className: "form-group mb-0"
  }, __jsx("label", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      lineHeight: "20px"
    }
  }, "Last name", " ", __jsx("ab", {
    className: "required",
    title: "required"
  }, "*")), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
    control: control,
    name: "lastName",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    }),
    rules: fieldRules.lastName
  })), errors !== null && errors !== void 0 && errors.lastName ? __jsx("div", {
    style: {
      color: "red",
      marginTop: "10px"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$lastName = errors.lastName) === null || _errors$lastName === void 0 ? void 0 : _errors$lastName.message) : null), __jsx("div", {
    className: "col-md-6"
  }, __jsx("div", {
    className: "form-group mb-0"
  }, __jsx("label", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      lineHeight: "20px"
    }
  }, "Display name", " ", __jsx("ab", {
    className: "required",
    title: "required"
  }, "*")), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
    control: control,
    name: "displayName",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control mb-0",
      style: {
        marginTop: "10px"
      },
      value: value,
      onChange: onChange
    }),
    rules: fieldRules.displayName
  })), errors !== null && errors !== void 0 && errors.displayName ? __jsx("div", {
    style: {
      color: "red",
      marginTop: "10px"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$displayName = errors.displayName) === null || _errors$displayName === void 0 ? void 0 : _errors$displayName.message) : null)), __jsx("p", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      fontSize: "12px",
      lineHeight: "26px"
    }
  }, "This will be how your name will be displayed in the account section and in reviews"), __jsx("div", {
    className: "form-group mb-0"
  }, __jsx("label", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      lineHeight: "20px"
    }
  }, "Email address", " ", __jsx("ab", {
    className: "required",
    title: "required"
  }, "*")), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
    control: control,
    name: "email",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "email",
      className: "form-control ",
      style: {
        marginTop: "10px"
      },
      value: value,
      onChange: onChange
    }),
    rules: fieldRules.email
  }), errors !== null && errors !== void 0 && errors.email ? __jsx("div", {
    style: {
      color: "red",
      marginTop: "10px"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$email = errors.email) === null || _errors$email === void 0 ? void 0 : _errors$email.message) : null), __jsx("div", {
    className: "container",
    style: {
      display: "flex",
      justifyContent: "flex-end"
    }
  }, __jsx("div", {
    className: "mt-3"
  }, " ", __jsx("button", {
    type: "submit",
    className: "btn btn-dark mr-0"
  }, "Save changes"))))))))));
}

const mapStateToProps = state => {
  return {
    cartList: state.cartlist.cart ? state.cartlist.cart : []
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z)({
  ssr: true
})(accountdetails));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 2662:
/***/ (function(module) {

"use strict";
module.exports = require("react-hook-form");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,6285,7164], function() { return __webpack_exec__(2052); });
module.exports = __webpack_exports__;

})();