(function() {
var exports = {};
exports.id = 9493;
exports.ids = [9493];
exports.modules = {

/***/ 297:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ ContactUs; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: external "google-map-react"
var external_google_map_react_namespaceObject = require("google-map-react");;
var external_google_map_react_default = /*#__PURE__*/__webpack_require__.n(external_google_map_react_namespaceObject);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/pages/contact-us.js

var __jsx = (external_react_default()).createElement;




const AnyReactComponent = () => __jsx("div", null);

function ContactUs() {
  return __jsx("main", {
    className: "main contact-two"
  }, __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-0"
  }, __jsx("div", {
    className: "container"
  }, __jsx("ol", {
    className: "breadcrumb"
  }, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(ALink/* default */.Z, {
    href: "/"
  }, __jsx(index_esm/* IoMdHome */.QO$, {
    style: {
      fontSize: "16px"
    }
  }))), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, "Contact Us")))), __jsx("div", {
    id: "map"
  }, __jsx((external_google_map_react_default()), {
    bootstrapURLKeys: {
      key: 'your-api-key'
    },
    defaultCenter: {
      lat: 59.95,
      lng: 30.33
    },
    defaultZoom: 11
  }, __jsx(AnyReactComponent, {
    lat: 59.955413,
    lng: 30.337844
  }))), __jsx("div", {
    className: "container mb-4 mb-lg-1"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-md-6"
  }, __jsx("h2", {
    className: "font1 font-weight-light ls-n-10"
  }, __jsx("strong", null, "Contact"), " Us"), __jsx("form", {
    action: "#"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-md-6"
  }, __jsx("div", {
    className: "form-group required-field mb-2"
  }, __jsx("label", {
    htmlFor: "contact-name"
  }, "Your name"), __jsx("input", {
    type: "text",
    className: "form-control",
    id: "contact-name",
    name: "contact-name",
    required: true
  }))), __jsx("div", {
    className: "col-md-6"
  }, __jsx("div", {
    className: "form-group required-field mb-2"
  }, __jsx("label", {
    htmlFor: "contact-email"
  }, "Your email address"), __jsx("input", {
    type: "email",
    className: "form-control",
    id: "contact-email",
    name: "contact-email",
    required: true
  })))), __jsx("div", {
    className: "form-group mb-2"
  }, __jsx("label", {
    htmlFor: "contact-subject"
  }, "Subject"), __jsx("input", {
    type: "text",
    className: "form-control",
    id: "contact-subject",
    name: "contact-subject"
  })), __jsx("div", {
    className: "form-group mb-0"
  }, __jsx("label", {
    htmlFor: "contact-message"
  }, "Your Message"), __jsx("textarea", {
    cols: "30",
    rows: "1",
    id: "contact-message",
    className: "form-control",
    name: "contact-message",
    required: true
  })), __jsx("div", {
    className: "form-footer mb-0"
  }, __jsx("button", {
    type: "submit",
    className: "btn btn-primary font1"
  }, "Send Message")))), __jsx("div", {
    className: "col-md-6"
  }, __jsx("h2", {
    className: "contact-title font1 ls-n-10 text-primary"
  }, __jsx("strong", null, "Get in touch")), __jsx("p", null, "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur eget leo at velit imperdiet varius. In eu ipsum vitae velit congue iaculis vitae at risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit."), __jsx("hr", {
    className: "mt-3 mb-0"
  }), __jsx("div", {
    className: "contact-info mb-2"
  }, __jsx("h2", {
    className: "contact-title font1 ls-n-10 text-primary"
  }, __jsx("strong", null, "The Office")), __jsx("div", {
    className: "porto-sicon-box d-flex align-items-center"
  }, __jsx("div", {
    className: "porto-icon"
  }, __jsx("i", {
    className: "fas fa-map-marker-alt"
  })), __jsx("h3", {
    className: "porto-sicon-title font1 ls-n-10"
  }, __jsx("strong", null, "Address:"), " 1234 Street Name, City Name, United States")), __jsx("div", {
    className: "porto-sicon-box d-flex align-items-center"
  }, __jsx("div", {
    className: "porto-icon"
  }, __jsx("i", {
    className: "fa fa-phone"
  })), __jsx("h3", {
    className: "porto-sicon-title font1 ls-n-10"
  }, __jsx("strong", null, "Phone:"), " (123) 456-7890")), __jsx("div", {
    className: "porto-sicon-box d-flex align-items-center"
  }, __jsx("div", {
    className: "porto-icon"
  }, __jsx("i", {
    className: "fa fa-envelope"
  })), __jsx("h3", {
    className: "porto-sicon-title font1 ls-n-10"
  }, __jsx("strong", null, "Email:"), " mail@example.com"))), __jsx("hr", {
    className: "mt-1 mb-0"
  }), __jsx("div", {
    className: "contact-time"
  }, __jsx("h2", {
    className: "contact-title font1 ls-n-10 text-primary"
  }, __jsx("strong", null, "Business Hours")), __jsx("div", {
    className: "porto-sicon-box d-flex align-items-center"
  }, __jsx("div", {
    className: "porto-icon"
  }, __jsx("i", {
    className: "far fa-clock"
  })), __jsx("h3", {
    className: "porto-sicon-title font1 ls-n-10"
  }, "Monday - Friday 9am to 5pm")), __jsx("div", {
    className: "porto-sicon-box  d-flex align-items-center"
  }, __jsx("div", {
    className: "porto-icon"
  }, __jsx("i", {
    className: "far fa-clock"
  })), __jsx("h3", {
    className: "porto-sicon-title font1 ls-n-10"
  }, "Saturday - 9am to 2pm")), __jsx("div", {
    className: "porto-sicon-box d-flex align-items-center"
  }, __jsx("div", {
    className: "porto-icon"
  }, __jsx("i", {
    className: "far fa-clock"
  })), __jsx("h3", {
    className: "porto-sicon-title font1 ls-n-10"
  }, "Sunday - Closed")))))), __jsx("div", {
    className: "mb-8"
  }));
}

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285], function() { return __webpack_exec__(297); });
module.exports = __webpack_exports__;

})();