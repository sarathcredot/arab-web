(function() {
var exports = {};
exports.id = 1328;
exports.ids = [1328];
exports.modules = {

/***/ 4361:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7164);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);
;






const GET_ORDER_DETAILS = _apollo_client__WEBPACK_IMPORTED_MODULE_3__.gql`query GetUserOrderDetails($input: GetUserOrderDetailsInput!) {
  getUserOrderDetails(input: $input) {
    _id
    orderDate
    orderId
    orderPriceInfo {
      totalMRP
      totalSellingPrice
      totalShippingCharge
      totalRefundAmount
    }
    orderStatus
    paymentMode
    shippingAddress {
      firstname
      houseNumber
      streetName
    }
  }
}`;

function success() {
  var _data$getUserOrderDet, _data$getUserOrderDet2, _data$getUserOrderDet3, _data$getUserOrderDet4, _data$getUserOrderDet5, _data$getUserOrderDet6, _data$getUserOrderDet7, _data$getUserOrderDet8, _data$getUserOrderDet9, _data$getUserOrderDet10, _data$getUserOrderDet11;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();

  const shopHandle = e => {
    e.preventDefault();
    router.push('/shop');
  };

  const shopOrder = e => {
    e.preventDefault();
    router.push('/pages/orders');
  }; // Retrieve the order ID from the query parameters


  const {
    orderId
  } = router.query;
  const {
    loading,
    error,
    data
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_4__.useQuery)(GET_ORDER_DETAILS, {
    variables: {
      input: {
        orderId
      }
    }
  });

  const getExpectedDeliveryDate = orderDate => {
    const newDate = new Date(orderDate);
    newDate.setDate(newDate.getDate() + 10);
    return newDate.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const order = data === null || data === void 0 ? void 0 : data.getUserOrderDetails;
  const orderDate = order === null || order === void 0 ? void 0 : order.orderDate;
  const expectedDeliveryDate = getExpectedDeliveryDate(orderDate);
  return __jsx("div", {
    class: "container"
  }, __jsx("div", {
    class: "centered-content",
    style: {
      textAlign: "center",
      marginBottom: "134px"
    }
  }, __jsx("img", {
    src: "/images/thankyouIcon.svg",
    alt: "Thank You Image"
  }), __jsx("h4", null, "Your order Was Successfully Placed"), __jsx("span", {
    style: {
      fontWeight: "400px",
      fontSize: "12px",
      color: "#000000"
    }
  }, "Your order is confirmed. You will receive an order confirmation email/SMS shortly with the expected delivery date of your item."), __jsx("div", {
    class: "buttons"
  }, __jsx("button", {
    onClick: e => shopHandle(e)
  }, "CONTINUE SHOPPING"), __jsx("button", {
    onClick: e => shopOrder(e)
  }, "VIEW ORDER"))), __jsx("hr", null), __jsx("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-around',
      marginLeft: "20px"
    }
  }, __jsx("div", {
    className: "head-card"
  }, __jsx("h4", null, "Delivery to")), __jsx("div", {
    className: "head-card"
  }, __jsx("h4", null, "Payment by"))), __jsx("div", {
    class: "cards-container",
    style: {
      marginBottom: "40px "
    }
  }, __jsx("div", {
    class: "card"
  }, __jsx("div", {
    style: {
      marginTop: "40px",
      marginBottom: "40px",
      marginLeft: "20px"
    }
  }, __jsx("img", {
    src: "/images/locationIcon.svg",
    alt: "Card Image 1"
  })), __jsx("div", null, __jsx("p", {
    style: {
      fontWeight: "400px",
      fontSize: "18px",
      color: "#000000"
    }
  }, data === null || data === void 0 ? void 0 : (_data$getUserOrderDet = data.getUserOrderDetails) === null || _data$getUserOrderDet === void 0 ? void 0 : (_data$getUserOrderDet2 = _data$getUserOrderDet.shippingAddress) === null || _data$getUserOrderDet2 === void 0 ? void 0 : _data$getUserOrderDet2.firstname), __jsx("p", {
    style: {
      fontWeight: "400px",
      fontSize: "11px",
      color: "#000000"
    }
  }, data === null || data === void 0 ? void 0 : (_data$getUserOrderDet3 = data.getUserOrderDetails) === null || _data$getUserOrderDet3 === void 0 ? void 0 : (_data$getUserOrderDet4 = _data$getUserOrderDet3.shippingAddress) === null || _data$getUserOrderDet4 === void 0 ? void 0 : _data$getUserOrderDet4.houseNumber, ",", data === null || data === void 0 ? void 0 : (_data$getUserOrderDet5 = data.getUserOrderDetails) === null || _data$getUserOrderDet5 === void 0 ? void 0 : (_data$getUserOrderDet6 = _data$getUserOrderDet5.shippingAddress) === null || _data$getUserOrderDet6 === void 0 ? void 0 : _data$getUserOrderDet6.streetName, " "), __jsx("p", {
    style: {
      fontWeight: "400px",
      fontSize: "11px",
      color: "#000000"
    }
  }, data === null || data === void 0 ? void 0 : (_data$getUserOrderDet7 = data.getUserOrderDetails) === null || _data$getUserOrderDet7 === void 0 ? void 0 : (_data$getUserOrderDet8 = _data$getUserOrderDet7.shippingAddress) === null || _data$getUserOrderDet8 === void 0 ? void 0 : _data$getUserOrderDet8.phoneNumber))), __jsx("div", {
    class: "card"
  }, __jsx("div", {
    style: {
      marginTop: "40px",
      marginBottom: "40px",
      marginLeft: "20px"
    }
  }, __jsx("img", {
    src: "/images/card.svg",
    alt: "Card Image 1"
  })), __jsx("div", null, __jsx("p", {
    style: {
      fontWeight: "400px",
      fontSize: "18px",
      color: "#000000"
    }
  }, data === null || data === void 0 ? void 0 : (_data$getUserOrderDet9 = data.getUserOrderDetails) === null || _data$getUserOrderDet9 === void 0 ? void 0 : _data$getUserOrderDet9.paymentMode), __jsx("div", {
    style: {
      display: "flex",
      flexDirection: "row",
      gap: "20px"
    }
  }, __jsx("p", {
    style: {
      fontWeight: "400px",
      fontSize: "11px",
      color: "#000000"
    }
  }, "Subtotal"), __jsx("p", {
    style: {
      fontWeight: "400px",
      fontSize: "11px",
      color: "#000000"
    }
  }, "OMR ", data === null || data === void 0 ? void 0 : (_data$getUserOrderDet10 = data.getUserOrderDetails) === null || _data$getUserOrderDet10 === void 0 ? void 0 : (_data$getUserOrderDet11 = _data$getUserOrderDet10.orderPriceInfo) === null || _data$getUserOrderDet11 === void 0 ? void 0 : _data$getUserOrderDet11.totalSellingPrice)), __jsx("div", {
    style: {
      display: "flex",
      flexDirection: "row",
      gap: "20px"
    }
  }, __jsx("p", {
    style: {
      fontWeight: "400px",
      fontSize: "11px",
      color: "#000000"
    }
  }, "Expected Delivery"), __jsx("p", {
    style: {
      fontWeight: "400px",
      fontSize: "11px",
      color: "#000000"
    }
  }, expectedDeliveryDate))))), __jsx("hr", null));
}

/* harmony default export */ __webpack_exports__["default"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)({
  ssr: true
})(success));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [7164], function() { return __webpack_exec__(4361); });
module.exports = __webpack_exports__;

})();