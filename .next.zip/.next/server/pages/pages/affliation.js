(function() {
var exports = {};
exports.id = 4187;
exports.ids = [4187];
exports.modules = {

/***/ 3949:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ pages_affliation; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
;// CONCATENATED MODULE: ./components/features/affliation/StartAffliation.jsx
var __jsx = (external_react_default()).createElement;


function StartAffliation({
  toggleForm
}) {
  return __jsx("div", {
    className: "container",
    style: {
      marginTop: "30px"
    }
  }, __jsx("div", {
    className: " justify-content-center align-items-center"
  }, __jsx("div", {
    className: "col-12  d-flex justify-content-center align-items-center",
    style: {
      height: "200px"
    }
  }, __jsx("div", {
    style: {
      width: "170px",
      height: "170px",
      borderRadius: "50%",
      backgroundColor: "white",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, __jsx("img", {
    src: "images/icon/Group 741.svg",
    alt: "Affiliate Icon",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      padding: "10px"
    }
  }))), __jsx("div", {
    className: "col-12 "
  }, __jsx("h1", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "500",
      fontSize: "32px",
      lineHeight: "52.33px",
      textAlign: "center" // Center-align text

    }
  }, "Affiliate Program"), __jsx("div", {
    style: {
      maxWidth: "805px",
      margin: "0 auto",
      // Center-align the container
      textAlign: "center" // Center-align text

    }
  }, __jsx("p", {
    className: "text-center"
  }, "Lorem ipsum dolor sit amet consectetur. Libero ac et at arcu natoque tellus consequat id. Quis mauris dignissim congue elit id mattis commodo tincidunt. Nunc dignissim lectus volutpat consectetur donec")), __jsx("div", {
    className: "d-flex justify-content-center"
  }, __jsx("button", {
    type: "submit",
    className: "btn",
    style: {
      border: "1px solid",
      width: "100%",
      maxWidth: "223px",
      height: "50px",
      color: "black",
      backgroundColor: "white"
    },
    onClick: toggleForm
  }, "START AFFILIATION")))));
}

/* harmony default export */ var affliation_StartAffliation = (StartAffliation);
;// CONCATENATED MODULE: ./components/features/affliation/Loading.jsx
var Loading_jsx = (external_react_default()).createElement;


function Loading() {
  return Loading_jsx("div", null, Loading_jsx("div", {
    className: " container d-flex justify-content-center align-items-center",
    style: {
      height: "200px",
      marginTop: "30px"
    }
  }, Loading_jsx("div", {
    className: "d-flex align-items-center justify-content-center",
    style: {
      width: "170px",
      height: "170px",
      borderRadius: "50%",
      backgroundColor: "#F8F8F8"
    }
  }, Loading_jsx("img", {
    src: "images\\icon\\hourglass (1) 1.svg",
    style: {
      backgroundSize: "cover",
      padding: "10px"
    }
  }))), Loading_jsx("div", {
    className: " container  d-flex justify-content-around"
  }, Loading_jsx("h1", {
    className: "justify-content-around",
    style: {
      fontFamily: "Poppins",
      fontWeight: "500px",
      fontSize: "32px",
      lineHeight: "52.33px"
    }
  }, "It's worth waiting..")), Loading_jsx("div", {
    className: "container d-flex align-items-center justify-content-center"
  }, Loading_jsx("div", {
    style: {
      width: "805px",
      height: "58px"
    }
  }, Loading_jsx("p", {
    className: "text-center"
  }, "Lorem ipsum dolor sit amet consectetur. Libero ac et at arcu natoque tellus consequat id. Quis mauris dignissim congue elit id mattis commodo tincidunt. Nunc dignissim lectus volutpat consectetur donec"))));
}

/* harmony default export */ var affliation_Loading = (Loading);
;// CONCATENATED MODULE: ./components/features/affliation/Form.jsx
var Form_jsx = (external_react_default()).createElement;


function Form({
  onSaveBankDetails
}) {
  const {
    0: uploadedFile,
    1: setUploadedFile
  } = (0,external_react_.useState)(null);
  const fileInputRef = (0,external_react_.useRef)(null);

  const handleFileChange = e => {
    const file = e.target.files[0];

    if (file) {
      setUploadedFile(file);
    }
  };

  const handleRemoveFile = () => {
    setUploadedFile(null); // Reset the file input value to allow reselection of the same file

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSaveBankDetailsClick = () => {
    // Call the onSaveBankDetails function to trigger the loading state
    onSaveBankDetails();
  };

  return Form_jsx("div", {
    className: "container"
  }, Form_jsx("div", {
    className: "row"
  }, Form_jsx("div", {
    className: "col-12 col-md-6"
  }, Form_jsx("div", {
    className: "input-container d-flex flex-column align-items-center"
  }, Form_jsx("label", {
    htmlFor: "file-input",
    className: "file-label"
  }, Form_jsx("input", {
    type: "file",
    id: "file-input",
    style: {
      display: 'none'
    },
    onChange: handleFileChange,
    ref: fileInputRef
  }), Form_jsx("div", {
    className: "file-icon d-flex justify-content-center align-items-center",
    style: {
      paddingTop: '70px'
    }
  }, Form_jsx("div", {
    className: "icon d-flex justify-content-center align-items-center"
  }, Form_jsx("i", {
    className: "fas fa-plus fa-2x"
  })))), Form_jsx("p", {
    className: "header-content"
  }, "Upload ID Proof"), Form_jsx("p", {
    className: "content"
  }, "Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, assumenda dolore?")), uploadedFile && Form_jsx("div", {
    className: "uploade"
  }, Form_jsx("p", null, "Uploaded File"), Form_jsx("div", {
    className: "uplode-content"
  }, Form_jsx("div", {
    className: "icon-container"
  }, Form_jsx("img", {
    src: "images\\icon\\Vector documnt.svg",
    alt: "Uploaded Icon"
  })), Form_jsx("div", {
    className: "text-container"
  }, Form_jsx("p", null, uploadedFile.name)), Form_jsx("i", {
    className: "fas fa-times",
    onClick: handleRemoveFile
  })))), Form_jsx("div", {
    className: "col-12 col-md-6"
  }, Form_jsx("div", {
    className: "form-container"
  }, Form_jsx("div", {
    style: {
      padding: '50px',
      marginTop: '10px'
    }
  }, Form_jsx("p", {
    className: "form-header"
  }, "Submit your Bank Details"), Form_jsx("div", {
    className: "form-group"
  }, Form_jsx("label", null, "Holder Name"), Form_jsx("input", {
    type: "text",
    className: "form-control"
  })), Form_jsx("div", {
    className: "form-group"
  }, Form_jsx("label", null, "Select Bank *"), Form_jsx("input", {
    type: "text",
    className: "form-control"
  })), Form_jsx("div", {
    className: "form-group"
  }, Form_jsx("label", null, "Account Number *"), Form_jsx("input", {
    type: "text",
    className: "form-control"
  })), Form_jsx("div", {
    className: "form-group"
  }, Form_jsx("label", null, "Reenter Account Number*"), Form_jsx("input", {
    type: "text",
    className: "form-control"
  })), Form_jsx("div", {
    className: "form-group"
  }, Form_jsx("label", null, "Swift code"), Form_jsx("input", {
    type: "text",
    className: "form-control"
  })), Form_jsx("button", {
    className: "styled-button",
    onClick: handleSaveBankDetailsClick
  }, "Save Bank Details"))))));
}

/* harmony default export */ var affliation_Form = (Form);
;// CONCATENATED MODULE: ./components/features/affliation/Dashbord.jsx
var Dashbord_jsx = (external_react_default()).createElement;




function Dashbord() {
  return Dashbord_jsx("div", {
    className: "container",
    style: {
      padding: "0"
    }
  }, Dashbord_jsx("div", {
    className: "db-container"
  }, Dashbord_jsx("div", {
    className: "card gradient-1"
  }, Dashbord_jsx("div", {
    className: "card-content",
    style: {
      padding: "20px"
    }
  }, Dashbord_jsx("h4", null, "Affiliate Earnings"), Dashbord_jsx("div", {
    className: "content-with-image"
  }, Dashbord_jsx("p", {
    className: "",
    style: {
      marginTop: "20px"
    }
  }, Dashbord_jsx("span", {
    className: "number"
  }, "420"), "AD Points"), Dashbord_jsx("img", {
    src: "images\\icon\\coins 1.svg",
    alt: ""
  }))), Dashbord_jsx("button", {
    type: "submit",
    className: "btn ",
    style: {
      marginTop: "auto",
      backgroundColor: "#E30613",
      color: "white",
      fontWeight: "600"
    }
  }, "redeem points")), Dashbord_jsx("div", {
    className: "card gradient-2"
  }, Dashbord_jsx("div", {
    className: "card-content",
    style: {
      padding: "20px 20px 0 20px"
    }
  }, Dashbord_jsx("h4", null, "Link Clicks"), Dashbord_jsx("div", {
    className: "content-with-image"
  }, Dashbord_jsx("p", {
    className: "",
    style: {
      marginTop: "20px"
    }
  }, Dashbord_jsx("span", {
    className: "number"
  }, "84"), "Clicks"), Dashbord_jsx("img", {
    src: "images\\icon\\hand-tap 1.svg",
    alt: ""
  }))), Dashbord_jsx("p", {
    style: {
      padding: "20px 20px",
      color: "black"
    }
  }, "Share Product links for more Referals")), Dashbord_jsx("div", {
    className: "card gradient-3"
  }, Dashbord_jsx("div", {
    className: "card-content",
    style: {
      padding: "20px 20px 0 20px"
    }
  }, Dashbord_jsx("h4", null, "Successful Purchase"), Dashbord_jsx("div", {
    className: "content-with-image"
  }, Dashbord_jsx("p", {
    className: "",
    style: {
      marginTop: "20px"
    }
  }, Dashbord_jsx("span", {
    className: "number"
  }, "27"), "Buys"), Dashbord_jsx("img", {
    src: "images\\icon\\packet 1.svg",
    alt: ""
  }))), Dashbord_jsx("p", {
    style: {
      padding: "20px 20px",
      color: "black"
    }
  }, "Congrats keep going!"))), Dashbord_jsx("h6", {
    style: {
      fontWeight: '500',
      fontSize: "2rem"
    }
  }, "Purchase History"), Dashbord_jsx("div", {
    className: "col-lg-12 p-0"
  }, Dashbord_jsx("div", {
    className: "cart-table-container"
  }, Dashbord_jsx("table", {
    className: "table table-cart"
  }, Dashbord_jsx("thead", null, Dashbord_jsx("tr", null, Dashbord_jsx("th", {
    className: "thumbnail-col p-0"
  }, "item"), Dashbord_jsx("th", {
    className: "product-col"
  }), Dashbord_jsx("th", {
    className: "price-col"
  }, "PURCHASE DATE"), Dashbord_jsx("th", {
    className: "qty-col"
  }, "USER PURCHASED"), Dashbord_jsx("th", {
    className: "qty-col"
  }, "POINTS EARNED"))), Dashbord_jsx("tbody", null, Dashbord_jsx("tr", {
    key: "cart-item",
    className: "product-row",
    style: {
      color: "black"
    }
  }, Dashbord_jsx("td", null, Dashbord_jsx("figure", {
    className: "product-image-container",
    style: {
      width: "7rem",
      padding: "14px",
      background: "#F9F9F9",
      border: "none"
    }
  }, Dashbord_jsx(ALink/* default */.Z, {
    href: "/home",
    className: "product-image"
  }, Dashbord_jsx("img", {
    src: "images\\icon\\product.svg",
    alt: "product",
    style: {
      maxWidth: "100%",
      maxHeight: "100%",
      display: "block"
    }
  })))), Dashbord_jsx("td", {
    className: "product-col"
  }, Dashbord_jsx("h5", {
    className: "product-title",
    style: {
      fontWeight: "600",
      fontSize: "1.2rem"
    }
  }, Dashbord_jsx(ALink/* default */.Z, {
    href: `/product/default`
  }, "iPhone 14 Pro max 256GB - Deep Purple.."))), Dashbord_jsx("td", null, "21/07/2023"), Dashbord_jsx("td", null, "995023715"), Dashbord_jsx("td", null, "ADP 120.00"))), Dashbord_jsx("tfoot", null, Dashbord_jsx("tr", null, Dashbord_jsx("td", {
    colSpan: "5",
    className: "clearfix"
  }, Dashbord_jsx("div", {
    className: "float-left"
  }), Dashbord_jsx("div", {
    className: "float-right"
  }, Dashbord_jsx("button", {
    type: "submit",
    className: "btn btn-shop btn-update-cart",
    style: {
      border: "1px solid",
      background: "white"
    }
  }, "Raise a dispute")))))))));
}

/* harmony default export */ var affliation_Dashbord = (Dashbord);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/pages/affliation.js
var affliation_jsx = (external_react_default()).createElement;








function affliation() {
  const {
    0: showForm,
    1: setShowForm
  } = (0,external_react_.useState)(false);
  const {
    0: isLoading,
    1: setIsLoading
  } = (0,external_react_.useState)(false);
  const {
    0: currentStep,
    1: setCurrentStep
  } = (0,external_react_.useState)("startAffliation");

  const toggleForm = () => {
    setShowForm(!showForm);
    setCurrentStep("form");
  };

  const handleSaveBankDetails = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 3000);
    setCurrentStep("dashboard");
  };

  return affliation_jsx("div", null, affliation_jsx("main", {
    className: "main main-test"
  }, affliation_jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav"
  }, affliation_jsx("div", {
    className: "container"
  }, affliation_jsx("ol", {
    className: "breadcrumb"
  }, affliation_jsx("li", {
    className: "breadcrumb-item"
  }, affliation_jsx(ALink/* default */.Z, {
    href: "/"
  }, affliation_jsx(index_esm/* IoMdHome */.QO$, {
    style: {
      fontSize: "16px"
    }
  }))), affliation_jsx("li", {
    className: "breadcrumb-item"
  }, affliation_jsx(ALink/* default */.Z, {
    href: "/pages/account"
  }, "Account")), affliation_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, affliation_jsx(ALink/* default */.Z, {
    className: "activeitem",
    href: "/pages/affliation"
  }, "affliation"))))), affliation_jsx("div", {
    className: " d-flex flex-column align-items-center",
    style: {
      backgroundColor: "#F9F9F9"
    }
  }, affliation_jsx("ul", {
    className: "checkout-progress-bar d-flex justify-content-center flex-wrap"
  }, affliation_jsx("li", {
    className: ""
  }, affliation_jsx(ALink/* default */.Z, {
    href: "/pages/account"
  }, "My Account")), affliation_jsx("li", {
    className: "active"
  }, affliation_jsx(ALink/* default */.Z, {
    href: "/pages/affliation"
  }, "Affliation")))), affliation_jsx("div", {
    className: "container",
    style: {
      marginTop: "3rem",
      borderBottom: "1px solid",
      borderColor: "#E2E2E2",
      padding: "2px"
    }
  }, affliation_jsx("h2", {
    className: "step-title"
  }, "Affliation")), affliation_jsx("div", {
    className: "container",
    style: {
      marginTop: "20px"
    }
  })), affliation_jsx("div", {
    classNam: true,
    style: {
      marginBottom: "120px"
    }
  }, currentStep === "startAffliation" && affliation_jsx(affliation_StartAffliation, {
    toggleForm: toggleForm
  }), currentStep === "form" && affliation_jsx(affliation_Form, {
    onSaveBankDetails: handleSaveBankDetails
  }), isLoading ? affliation_jsx(affliation_Loading, null) : currentStep === "dashboard" && affliation_jsx(affliation_Dashbord, null)));
}

/* harmony default export */ var pages_affliation = (affliation);

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285], function() { return __webpack_exec__(3949); });
module.exports = __webpack_exports__;

})();