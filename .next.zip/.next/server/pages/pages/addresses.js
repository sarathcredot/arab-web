(function() {
var exports = {};
exports.id = 2732;
exports.ids = [2732];
exports.modules = {

/***/ 3252:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "DEFAULT_ADDRESS": function() { return /* binding */ DEFAULT_ADDRESS; },
  "GET_ADDRESSES": function() { return /* binding */ GET_ADDRESSES; },
  "REMOVE_ADDRESS": function() { return /* binding */ REMOVE_ADDRESS; },
  "default": function() { return /* binding */ pages_addresses; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: external "react-hook-form"
var external_react_hook_form_ = __webpack_require__(2662);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(8074);
;// CONCATENATED MODULE: ./components/features/adresses/Addresses.jsx
var __jsx = (external_react_default()).createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const ACCOUNT_DETAIL = client_.gql`mutation UpdateUserProfile($input: updateUserProfileInput!) {
    updateUserProfile(input: $input) {

      message
    }
  }`;
const USER_DETAIL = client_.gql`query Query($input: userInput!) {
    getUserRecord(input: $input) {
      message
      record {
        displayName
        lastName
        _id
        address
        city
        country
        countryCode
        email
        firstName
        houseNumber
        mobileNumber
        pincode
        streetName
        token
      }
    }
  }`;

function Addresses() {
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: {
      errors
    },
    control
  } = (0,external_react_hook_form_.useForm)({
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      mobileNumber: "",
      pincode: "",
      city: "",
      streetName: "",
      houseNumber: "",
      country: ""
    }
  });
  const [updateUserProfile] = (0,client_.useMutation)(ACCOUNT_DETAIL);

  const onSubmit = async values => {
    event.preventDefault();

    try {
      // if (!mobileNumber.trim()) {
      //   setError("Mobile number is required");
      //   return;
      // }
      const Id = "65bb85834825212140ac3aed";
      const response = await updateUserProfile({
        variables: {
          input: _objectSpread({
            _id: Id.toString()
          }, values)
        }
      });

      if (response) {
        var _response$data, _response$data$update;

        window.alert(response === null || response === void 0 ? void 0 : (_response$data = response.data) === null || _response$data === void 0 ? void 0 : (_response$data$update = _response$data.updateUserProfile) === null || _response$data$update === void 0 ? void 0 : _response$data$update.message);
        reset();
      }

      SetIsOtp(true);
    } catch (error) {}
  };

  return __jsx("div", null, __jsx("div", {
    className: "container checkout-container"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-12"
  }, __jsx("ul", {
    className: "checkout-steps"
  }, __jsx("li", null, __jsx("div", {
    className: "container",
    style: {
      marginTop: "6rem",
      // borderBottom:"1px solid",
      // borderColor:""
      padding: "2px"
    }
  }, __jsx("h4", {
    className: "step-title"
  }, "Billing address")), __jsx("form", {
    onSubmit: handleSubmit(onSubmit),
    id: "checkout-form",
    style: {
      marginTop: "40px"
    }
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-md-6"
  }, __jsx("div", {
    className: "form-group"
  }, __jsx("label", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      lineHeight: "20px"
    }
  }, "First name", " ", __jsx("ab", {
    className: "required",
    title: "required"
  }, "*")), __jsx(external_react_hook_form_.Controller, {
    control: control,
    name: "firstName",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    })
  }))), __jsx("div", {
    className: "col-md-6"
  }, __jsx("div", {
    className: "form-group"
  }, __jsx("label", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      lineHeight: "20px"
    }
  }, "Last name", " ", __jsx("ab", {
    className: "required",
    title: "required"
  }, "*")), __jsx(external_react_hook_form_.Controller, {
    control: control,
    name: "lastName",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      style: {
        marginTop: "10px"
      },
      value: value,
      onChange: onChange
    })
  })))), __jsx("div", {
    className: "form-group"
  }, __jsx("label", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      lineHeight: "20px"
    }
  }, "Country / Region ", " ", __jsx("ab", {
    className: "required",
    title: "required"
  }, "*")), __jsx(external_react_hook_form_.Controller, {
    control: control,
    name: "country",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    })
  })), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Street address ", __jsx("span", {
    className: "required"
  }, "*")), __jsx(external_react_hook_form_.Controller, {
    control: control,
    name: "houseNumber",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      placeholder: "House number and street name",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    })
  }), __jsx(external_react_hook_form_.Controller, {
    control: control,
    name: "streetName",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      placeholder: "Apartment, suite, unit, etc. (optional)",
      value: value,
      onChange: onChange
    })
  })), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Twon/City ", __jsx("span", {
    className: "required"
  }, "*")), __jsx(external_react_hook_form_.Controller, {
    control: control,
    name: "city",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      placeholder: "Abu Dhabi",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    })
  })), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Pincode/Zip ", __jsx("span", {
    className: "required"
  }, "*")), __jsx(external_react_hook_form_.Controller, {
    control: control,
    name: "pincode",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "number",
      className: "form-control",
      placeholder: "6730016",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    })
  })), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Phone", __jsx("span", {
    className: "required"
  }, "*")), __jsx("div", {
    className: "input-group",
    style: {
      marginTop: "10px"
    }
  }, __jsx("div", {
    className: "input-group-prepend"
  }, __jsx("span", {
    className: "input-group-text",
    style: {
      padding: "10px"
    }
  }, __jsx("img", {
    src: "images\\brands\\flag1.svg",
    alt: "Flag",
    width: "24",
    height: "16"
  }), "+971")), __jsx(external_react_hook_form_.Controller, {
    control: control,
    name: "mobileNumber",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "tel",
      className: "form-control",
      placeholder: "Enter your phone number",
      value: value,
      onChange: onChange
    })
  }))), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Email", __jsx("span", {
    className: "required"
  }, "*")), __jsx(external_react_hook_form_.Controller, {
    control: control,
    name: "email",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    })
  })), __jsx("div", {
    className: "container",
    style: {
      display: "flex",
      justifyContent: "flex-end"
    }
  }, __jsx("div", {
    className: "mt-3"
  }, __jsx("button", {
    type: "submit",
    className: "btn btn-dark mr-0"
  }, "Save changes"))))))))));
}

/* harmony default export */ var adresses_Addresses = ((0,apollo/* default */.Z)({
  ssr: true
})(Addresses));
// EXTERNAL MODULE: ./components/features/adresses/Shippingaddress.jsx
var Shippingaddress = __webpack_require__(9592);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: ./node_modules/react-icons/cg/index.esm.js
var index_esm = __webpack_require__(471);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(2034);
;// CONCATENATED MODULE: ./pages/pages/addresses.js

var addresses_jsx = (external_react_default()).createElement;








 // import { gql, useMutation,useLazyQuery } from "@apollo/client";

const GET_ADDRESSES = react_hooks_.gql`query GetUserShippingAddresses {
  getUserShippingAddresses {
    address {
      _id
      apartment
      city
     
      country
      email
      firstname
      houseNumber
      mobile
      postCode
      streetName
      suite
      unit
      isDefault
     
    }
  }
}`;
const REMOVE_ADDRESS = react_hooks_.gql`mutation RemoveUserShippingAddress($input: UserRemoveShippingAddressInput!) {
  removeUserShippingAddress(input: $input) {
    _id
    message
  }
}`;
const DEFAULT_ADDRESS = react_hooks_.gql`mutation UpdateUserShippingAddressAsDefault($input: updateUserShippingAddressAsDefaultInput!) {
  updateUserShippingAddressAsDefault(input: $input) {
    _id
    message
  }
}`;

function addresses() {
  var _data$getUserShipping, _data$getUserShipping2;

  // const [catLevel2, { loading:level2loading, error:level2error, data:level2Data }] = useLazyQuery(GET_SHIPPING_ADDRESS);
  const {
    0: isAddress,
    1: setIsAddress
  } = (0,external_react_.useState)(false);
  const {
    0: isShipping,
    1: setIsshipping
  } = (0,external_react_.useState)(false);
  const {
    data,
    loading,
    error,
    refetch
  } = (0,react_hooks_.useQuery)(GET_ADDRESSES);
  const {
    0: isEdit,
    1: setIsedit
  } = (0,external_react_.useState)(false);
  const {
    0: selectedAddressId,
    1: setSelectedAddressId
  } = (0,external_react_.useState)(null);
  const {
    0: isShippingOpen,
    1: setIsShippingOpen
  } = (0,external_react_.useState)(false);
  const [RemoveUserShippingAddress] = (0,react_hooks_.useMutation)(REMOVE_ADDRESS);
  const [UpdateUserShippingAddressAsDefault] = (0,react_hooks_.useMutation)(DEFAULT_ADDRESS);
  (0,external_react_.useEffect)(() => {
    refetch();
  }, []);

  const handleOpenShipping = () => {
    setIsShippingOpen(true);
  };

  const handleCloseShipping = () => {
    setIsshipping(false);
    refetch();
  };

  const handleRemove = async id => {
    const response = await RemoveUserShippingAddress({
      variables: {
        input: {
          _id: id
        }
      }
    });
    refetch();
  };

  const handleDefault = async id => {
    var _response$data, _response$data$update;

    const response = await UpdateUserShippingAddressAsDefault({
      variables: {
        input: {
          addressId: id
        }
      }
    });
    refetch();
    external_react_toastify_.toast.success(response === null || response === void 0 ? void 0 : (_response$data = response.data) === null || _response$data === void 0 ? void 0 : (_response$data$update = _response$data.updateUserShippingAddressAsDefault) === null || _response$data$update === void 0 ? void 0 : _response$data$update.message);
  };

  return addresses_jsx("main", {
    className: "main main-test"
  }, addresses_jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav"
  }, addresses_jsx("div", {
    className: "container"
  }, addresses_jsx("ol", {
    className: "breadcrumb"
  }, addresses_jsx("li", {
    className: "breadcrumb-item"
  }, addresses_jsx(ALink/* default */.Z, {
    href: "/"
  }, "Home")), addresses_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, "addresses")))), addresses_jsx("div", {
    className: " d-flex flex-column align-items-center",
    style: {
      backgroundColor: "#F9F9F9",
      marginTop: "10px"
    }
  }, addresses_jsx("ul", {
    className: "checkout-progress-bar d-flex justify-content-center flex-wrap mb-0"
  }, addresses_jsx("li", {
    className: ""
  }, addresses_jsx(ALink/* default */.Z, {
    href: "/pages/account"
  }, "My Account")), addresses_jsx("li", {
    className: "active"
  }, addresses_jsx(ALink/* default */.Z, {
    href: "/pages/orders"
  }, "Addresses")))), addresses_jsx("div", {
    className: "container",
    style: {
      marginTop: "3rem",
      borderBottom: "1px solid",
      borderColor: "#E2E2E2",
      padding: "2px"
    }
  }, addresses_jsx("h2", {
    className: "step-title addresstitle"
  }, "Address")), isAddress ? addresses_jsx((external_react_default()).Fragment, null, addresses_jsx(adresses_Addresses, null)) : isShipping ? addresses_jsx((external_react_default()).Fragment, null, addresses_jsx(Shippingaddress/* default */.ZP, {
    isEdit: isEdit,
    addressId: selectedAddressId,
    onClose: handleCloseShipping
  })) : addresses_jsx((external_react_default()).Fragment, null, addresses_jsx("div", {
    className: "container d-flex justify-content-between flex-column flex-sm-row w-sm-100",
    style: {
      gap: "5rem",
      marginBottom: "75px"
    }
  }, addresses_jsx("div", {
    className: "custom-addressbox" // style={{
    //   width: "653.45px",
    //   minHeight: "234px",
    //   border: "1px solid ",
    //   marginTop: "40px",
    //   borderColor: "#CDCDCD",
    // }}

  }, addresses_jsx("div", {
    className: "p-5"
  }, addresses_jsx("h4", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "600px",
      fontSize: "24px",
      lineHeight: "20px"
    }
  }, "Shipping Addresses"), data && (data === null || data === void 0 ? void 0 : (_data$getUserShipping = data.getUserShippingAddresses) === null || _data$getUserShipping === void 0 ? void 0 : _data$getUserShipping.address.length) > 0 ? data === null || data === void 0 ? void 0 : (_data$getUserShipping2 = data.getUserShippingAddresses) === null || _data$getUserShipping2 === void 0 ? void 0 : _data$getUserShipping2.address.map((address, index) => {
    var _data$getUserShipping3;

    return addresses_jsx((external_react_default()).Fragment, null, addresses_jsx("div", {
      key: index,
      style: {
        padding: "20px 0",
        display: "flex",
        lineHeight: "19px"
      }
    }, addresses_jsx(index_esm/* CgEditBlackPoint */.Aph, {
      style: {
        fontSize: "40px",
        color: "#E30613",
        paddingRight: "20px"
      }
    }), addresses_jsx("div", null, addresses_jsx("span", null, address === null || address === void 0 ? void 0 : address.firstname), addresses_jsx("br", null), addresses_jsx("span", null, address === null || address === void 0 ? void 0 : address.houseNumber, ", ", address === null || address === void 0 ? void 0 : address.streetName), addresses_jsx("br", null), addresses_jsx("span", null, "PostCode:\xA0", address === null || address === void 0 ? void 0 : address.postCode), addresses_jsx("br", null), addresses_jsx("span", null, address === null || address === void 0 ? void 0 : address.city, ", ", address === null || address === void 0 ? void 0 : address.country), addresses_jsx("div", {
      style: {
        display: "flex",
        gap: "35px",
        color: "black",
        marginTop: "10px"
      }
    }, addresses_jsx("button", {
      className: "editbtn",
      style: {
        cursor: "pointer",
        background: "none",
        border: "none",
        fontWeight: "600",
        color: "black !important"
      },
      onClick: () => {
        setIsshipping(true);
        setIsedit(true);
        setSelectedAddressId(address === null || address === void 0 ? void 0 : address._id);
      }
    }, "Edit"), data && (data === null || data === void 0 ? void 0 : (_data$getUserShipping3 = data.getUserShippingAddresses) === null || _data$getUserShipping3 === void 0 ? void 0 : _data$getUserShipping3.address.length) > 1 && addresses_jsx("button", {
      className: "editbtn",
      style: {
        cursor: "pointer",
        background: "none",
        border: "none",
        fontWeight: "600"
      },
      onClick: () => handleRemove(address === null || address === void 0 ? void 0 : address._id)
    }, "Remove"), !address.isDefault && addresses_jsx("button", {
      style: {
        cursor: "pointer",
        background: "none",
        border: "none",
        fontWeight: "600"
      },
      onClick: () => handleDefault(address === null || address === void 0 ? void 0 : address._id)
    }, "Set as default")))));
  }) : addresses_jsx("p", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      fontSize: "14px",
      lineHeight: "20px"
    }
  }, "You have not set up this type of address yet."), addresses_jsx("button", {
    type: "submit",
    className: "btn  mr-0",
    style: {
      border: "1px solid ",
      marginTop: "20px",
      width: "152px",
      height: "43px",
      padding: "10px",
      background: "white"
    },
    onClick: () => {
      setIsshipping(true);
    }
  }, "ADD ADDRESSES"))))));
}

const mapStateToProps = state => {
  return {
    cartList: state.cartlist.cart ? state.cartlist.cart : []
  };
};

/* harmony default export */ var pages_addresses = ((0,apollo/* default */.Z)({
  ssr: true
})(addresses));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 2662:
/***/ (function(module) {

"use strict";
module.exports = require("react-hook-form");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,471,6285,7164,9592], function() { return __webpack_exec__(3252); });
module.exports = __webpack_exports__;

})();