(function() {
var exports = {};
exports.id = 6436;
exports.ids = [6436];
exports.modules = {

/***/ 2023:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_common_ALink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8974);
/* harmony import */ var _store_wishlist__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5708);
/* harmony import */ var _store_cart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2806);
/* harmony import */ var _store_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6723);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7164);
/* harmony import */ var _components_features_modals_add_to_cart_popup__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4922);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6481);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















const GET_WISH_LIST = _apollo_client__WEBPACK_IMPORTED_MODULE_7__.gql`
  query Products {
    getWishListProducts {
      products {
        image
        productId
        productName
        sellingPrice
        shortDescription
      }
    }
  }
`;
const POST_CART = _apollo_client__WEBPACK_IMPORTED_MODULE_7__.gql`
  mutation AddToCart($input: addToCartInput!) {
    addToCart(input: $input) {
      message
    }
  }
`;
const GET_CART = _apollo_client__WEBPACK_IMPORTED_MODULE_7__.gql`
  query GetCart {
    getCart {
      products {
        _id
        productId
        quantity
        name
        shortDescription
        stock
        color
        size
        price
        image
        sellingPrice
        mrp
      }
      grandTotal
      subTotal
      deliveryCharge
    }
  }
`;
const REMOVE_WISHLIST = _apollo_client__WEBPACK_IMPORTED_MODULE_7__.gql`
  mutation RemoveFromWishList($input: RemoveFromWishListInput!) {
    removeFromWishList(input: $input) {
      message
    }
  }
`;

function Wishlist(props) {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_13__.useRouter)();
  const {
    wishlist,
    removeFromWishlist,
    showQuickView
  } = props;
  const {
    0: flag,
    1: setFlag
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: wishlistDatas,
    1: setWishlistDatas
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const [addToCart] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_7__.useMutation)(POST_CART);
  const [removeFromWishList] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_7__.useMutation)(REMOVE_WISHLIST);
  const token = localStorage.getItem("arabtoken");
  const {
    data: cartData,
    loading: cartLoading,
    error: cartError,
    refetch: cartRefetch
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_8__.useQuery)(GET_CART, {
    skip: !token
  });
  const {
    data: wishListData,
    loading: wishListLoading,
    error: wishListError,
    refetch: wishListRefetch
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_8__.useQuery)(GET_WISH_LIST, {
    skip: !token,
    fetchPolicy: "network-only"
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (wishListError) {
      console.log(wishListError);
    } else if (wishlistDatas) {
      setWishlistDatas((wishListData === null || wishListData === void 0 ? void 0 : wishListData.getWishListProducts.products) || []);
    }
  }, [wishListData]);

  const onMoveFromToWishlit = (e, item) => {
    setFlag(2);
    e.preventDefault();
    addToCart(item);
    removeFromWishlist(item);
  };

  const removeProduct = async (e, item) => {
    try {
      if (item) {
        const response = await removeFromWishList({
          variables: {
            input: {
              productId: item.productId
            }
          }
        });

        if (response) {
          wishListRefetch();
          return react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.success("Successfully product removed to cart");
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  const onQuickViewClick = (e, product) => {
    e.preventDefault();
    showQuickView(product.productId);
  };

  const onAddCartClick = async (e, product) => {
    e.preventDefault();

    try {
      if (product) {
        const response = await addToCart({
          variables: {
            input: {
              productId: product.productId,
              quantity: 1
            }
          }
        });

        if (response) {
          cartRefetch();
          wishListRefetch();
          return react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.success("Successfully product added to cart");
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx(react_helmet__WEBPACK_IMPORTED_MODULE_12__.Helmet, null, __jsx("title", null, "Wishlist | Arab Deals")), __jsx("main", {
    className: "main"
  }, __jsx("div", {
    className: "page-header"
  }, __jsx("div", {
    className: "container d-flex flex-column align-items-center"
  }, __jsx("h1", null, "Wishlist"))), __jsx("div", {
    className: "container"
  }, __jsx("div", {
    className: "success-alert"
  }, flag === 1 ? __jsx("p", null, "Product successfully removed.") : "", flag === 2 ? __jsx("p", null, "Product added to cart successfully.") : ""), wishListLoading && __jsx("div", null, "loading..."), !wishListLoading && (wishlistDatas === null || wishlistDatas === void 0 ? void 0 : wishlistDatas.length) === 0 ? __jsx("div", {
    className: "wishlist-table-container"
  }, __jsx("div", {
    className: "table table-wishlist mb-0"
  }, __jsx("div", {
    className: "wishlist-empty-page text-center"
  }, __jsx("i", {
    className: "far fa-heart"
  }), __jsx("p", null, "No products added to the wishlist"), __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: "/shop",
    className: "btn btn-dark btn-add-cart product-type-simple btn-shop font1 w-auto"
  }, "go shop", " ")))) : "", !wishListLoading && wishlistDatas.length ? __jsx("div", {
    className: "wishlist-table-container"
  }, __jsx("table", {
    className: "table table-wishlist mb-0"
  }, __jsx("thead", null, __jsx("tr", null, __jsx("th", {
    className: "thumbnail-col"
  }, "Product"), __jsx("th", {
    className: "product-col"
  }), __jsx("th", {
    className: "price-col"
  }, "Price"), __jsx("th", {
    className: "status-col"
  }, "Stock Status"), __jsx("th", {
    className: "action-col"
  }, "Actions"))), __jsx("tbody", null, wishlistDatas === null || wishlistDatas === void 0 ? void 0 : wishlistDatas.map((item, index) => {
    var _item$variants;

    return __jsx("tr", {
      key: "wishlist-item" + index,
      className: "product-row",
      style: {
        borderBottom: "1px solid #e7e7e7"
      }
    }, __jsx("td", {
      className: "media-with-lazy"
    }, __jsx("figure", {
      className: "product-image-container"
    }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
      href: `/product/default/${item === null || item === void 0 ? void 0 : item.productId}`,
      className: "product-image"
    }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__.LazyLoadImage, {
      alt: "product",
      src: item.image,
      threshold: 500,
      width: "80",
      height: "80"
    })), __jsx("a", {
      className: "btn-remove icon-cancel",
      title: "Remove Product",
      onClick: e => removeProduct(e, item)
    }))), __jsx("td", null, __jsx("h5", {
      className: "product-title"
    }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
      href: `/product/default/${item.productId}`
    }, item === null || item === void 0 ? void 0 : item.productName))), __jsx("td", {
      style: {
        color: "black"
      }
    }, __jsx("div", {
      className: "price-box"
    }, __jsx("span", {
      className: "product-price",
      style: {
        color: "#000"
      }
    }, "OMR " + (item === null || item === void 0 ? void 0 : item.sellingPrice)))), __jsx("td", null, __jsx("span", {
      className: "stock-status"
    }, item.stock <= 0 ? "Out of stock" : "In stock")), __jsx("td", {
      className: "action"
    }, __jsx("div", {
      className: "btn btn-quickview mt-1 mt-md-0",
      title: "View",
      style: {
        border: "1px solid"
      },
      onClick: e => router.push(`/product/default/${item.productId}`)
    }, "View"), (item === null || item === void 0 ? void 0 : (_item$variants = item.variants) === null || _item$variants === void 0 ? void 0 : _item$variants.length) > 0 ? __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
      className: "btn btn-dark btn-add-cart product-type-simple btn-shop",
      href: `/product/default/${item.slug}`
    }, "select options") : __jsx("button", {
      className: "btn btn-dark btn-add-cart product-type-simple btn-shop hoverbtn",
      onClick: e => {
        onAddCartClick(e, item);
      }
    }, "ADD TO CART")));
  })))) : "")));
}

const mapStateToProps = state => {
  return {
    wishlist: state.wishlist.list ? state.wishlist.list : []
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z)({
  ssr: true
})((0,react_redux__WEBPACK_IMPORTED_MODULE_1__.connect)(mapStateToProps, _objectSpread(_objectSpread(_objectSpread({}, _store_wishlist__WEBPACK_IMPORTED_MODULE_4__/* .actions */ .Nw), _store_cart__WEBPACK_IMPORTED_MODULE_5__/* .actions */ .Nw), _store_modal__WEBPACK_IMPORTED_MODULE_6__/* .actions */ .Nw))(Wishlist)));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 6481:
/***/ (function(module) {

"use strict";
module.exports = require("react-helmet");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,6285,7164,6723,2806,5708], function() { return __webpack_exec__(2023); });
module.exports = __webpack_exports__;

})();