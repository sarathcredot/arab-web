(function() {
var exports = {};
exports.id = 5924;
exports.ids = [5924];
exports.modules = {

/***/ 5985:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ ForgotPassword; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_ALink__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8974);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ForgotPassword() {
  return __jsx("main", {
    className: "main"
  }, __jsx("div", {
    className: "page-header"
  }, __jsx("div", {
    className: "container d-flex flex-column align-items-center"
  }, __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav"
  }, __jsx("div", {
    className: "container"
  }, __jsx("ol", {
    className: "breadcrumb"
  }, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: "/"
  }, "Home")), __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: "/shop"
  }, "Shop")), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, "My Account")))), __jsx("h1", null, "My Account"))), __jsx("div", {
    className: "container reset-password-container"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-6 offset-lg-3"
  }, __jsx("div", {
    className: "feature-box border-top-primary"
  }, __jsx("div", {
    className: "feature-box-content"
  }, __jsx("form", {
    className: "mb-0",
    action: "#"
  }, __jsx("p", null, "Lost your password? Please enter your username or email address. You will receive a link to create a new password via email."), __jsx("div", {
    className: "form-group mb-0"
  }, __jsx("label", {
    htmlFor: "reset-email",
    className: "font-weight-normal"
  }, "Username or email"), __jsx("input", {
    type: "email",
    className: "form-control",
    id: "reset-email",
    name: "reset-email",
    required: true
  })), __jsx("div", {
    className: "form-footer mb-0"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: "/pages/login"
  }, "Click here to login"), __jsx("button", {
    type: "submit",
    className: "btn btn-md btn-primary form-footer-right font-weight-normal text-transform-none mr-0"
  }, "Reset Password")))))))));
}

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,6285], function() { return __webpack_exec__(5985); });
module.exports = __webpack_exports__;

})();