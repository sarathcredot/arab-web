(function() {
var exports = {};
exports.id = 3065;
exports.ids = [3065];
exports.modules = {

/***/ 548:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "GET_ADDRESSES": function() { return /* binding */ GET_ADDRESSES; },
  "PLACE_ORDER": function() { return /* binding */ PLACE_ORDER; },
  "REMOVE_ADDRESS": function() { return /* binding */ REMOVE_ADDRESS; },
  "default": function() { return /* binding */ checkout; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: external "react-slide-toggle"
var external_react_slide_toggle_ = __webpack_require__(3920);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
;// CONCATENATED MODULE: external "react-select"
var external_react_select_namespaceObject = require("react-select");;
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(8074);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./components/features/adresses/Shippingaddress.jsx
var Shippingaddress = __webpack_require__(9592);
// EXTERNAL MODULE: ./node_modules/react-icons/io5/index.esm.js
var index_esm = __webpack_require__(155);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(2034);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "react-helmet"
var external_react_helmet_ = __webpack_require__(6481);
;// CONCATENATED MODULE: ./pages/pages/checkout.js

var __jsx = (external_react_default()).createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















const countryOptions = [{
  value: "uae",
  label: "+971",
  flag: "/images/uae.svg"
}, {
  value: "india",
  label: "+91",
  flag: "/images/ind.svg"
}, {
  value: "oman",
  label: "+98",
  flag: "/images/omn.png"
}, {
  value: "saudi",
  label: "+966",
  flag: "/images/sar.png"
}];
const GET_CART = client_.gql`
  query GetCart {
    getCart {
      products {
        _id
        productId
        quantity
        name
        stock
        sellingPrice
        price
        image
      }
      grandTotal
      subTotal
      deliveryCharge
    }
  }
`;
const GET_ADDRESSES = client_.gql`
  query GetUserShippingAddresses {
    getUserShippingAddresses {
      address {
        _id
        apartment
        city

        country
        email
        firstname
        houseNumber
        mobile
        postCode
        streetName
        suite
        unit
        isDefault
      }
    }
  }
`;
const REMOVE_ADDRESS = client_.gql`
  mutation RemoveUserShippingAddress($input: UserRemoveShippingAddressInput!) {
    removeUserShippingAddress(input: $input) {
      _id
      message
    }
  }
`;
const PLACE_ORDER = client_.gql`
  mutation CreateUserOrder($input: CreateUserOrderInput!) {
    createUserOrder(input: $input) {
      orderId
    }
  }
`;

function CheckOut() {
  var _data$getUserShipping, _data$getUserShipping2, _cartData$getCart2, _cartData$getCart3, _cartData$getCart4;

  const arabtoken = localStorage.getItem("arabtoken");
  const defaultOption = countryOptions[0];
  const {
    0: cartList,
    1: setCartList
  } = (0,external_react_.useState)();
  const {
    0: isShipping,
    1: setIsshipping
  } = (0,external_react_.useState)(false);
  const {
    0: isEdit,
    1: setIsedit
  } = (0,external_react_.useState)(false);
  const {
    0: defaultAddressId,
    1: setDefaultAddressId
  } = (0,external_react_.useState)("");
  const {
    0: selectedAddressId,
    1: setSelectedAddressId
  } = (0,external_react_.useState)(null);
  const {
    data,
    loading,
    error,
    refetch
  } = (0,client_.useQuery)(GET_ADDRESSES);
  const [RemoveUserShippingAddress] = (0,client_.useMutation)(REMOVE_ADDRESS);
  const [CreateUserOrder] = (0,client_.useMutation)(PLACE_ORDER);
  const router = (0,router_.useRouter)();
  const customStyles = {
    control: (provided, state) => _objectSpread(_objectSpread({}, provided), {}, {
      borderRight: "none",
      boxShadow: "none",
      borderRadius: "0",
      height: "100%",
      outline: "none",
      boxShadow: state.isFocused ? "none" : provided.boxShadow,
      // Preserve boxShadow when not focused
      "&:selected": {
        border: "none"
      }
    }),
    menu: provided => _objectSpread(_objectSpread({}, provided), {}, {
      width: "150px" // background:"red" // Adjust the width as needed

    }),
    option: (provided, state) => _objectSpread(_objectSpread({}, provided), {}, {
      whiteSpace: "nowrap",
      background: state.isSelected ? "#EFEFEF" : "transparent",
      color: "black",
      background: "transparent" // Prevent text wrapping

    }),
    indicatorSeparator: () => ({
      display: "none"
    }),
    dropdownIndicator: () => ({
      display: "none"
    })
  };
  const overrideDefaultStyles = `
  
  .react-select__control:focus {
    box-shadow: none;
    outline:none;
    borderColor:red;
    border:none
  }
`;
  const {
    0: toggler,
    1: setToggler
  } = (0,external_react_.useState)(false);
  const token = localStorage.getItem("arabtoken");
  const {
    data: cartData,
    loading: cartLoading,
    error: cartError,
    refetch: cartRefetch
  } = (0,client_.useQuery)(GET_CART, {
    skip: !token
  });
  (0,external_react_.useEffect)(() => {
    if (data && data.getUserShippingAddresses && data.getUserShippingAddresses.address.length > 0) {
      const defaultAddress = data.getUserShippingAddresses.address.find(address => address.isDefault);

      if (defaultAddress) {
        setDefaultAddressId(defaultAddress._id);
      }
    }
  }, [data]);
  (0,external_react_.useEffect)(() => {
    if (cartError) {
      console.error("Error fetching cart data:", cartError);
    } else if (cartData) {
      setCartList(cartData.getCart.products || []);
    }

    cartRefetch();
  }, [cartData]);

  const handleCloseShipping = () => {
    setIsshipping(false);
    refetch();
  };

  const handleRemove = async id => {
    const response = await RemoveUserShippingAddress({
      variables: {
        input: {
          _id: id
        }
      }
    });
    refetch();
  };

  const handleAddressSelection = addressId => {
    setDefaultAddressId(addressId);
  };

  const handlePlaceOrder = async () => {
    try {
      var _cartData$getCart, _response$data, _response$data$create;

      const response = await CreateUserOrder({
        variables: {
          input: {
            grandTotal: cartData === null || cartData === void 0 ? void 0 : (_cartData$getCart = cartData.getCart) === null || _cartData$getCart === void 0 ? void 0 : _cartData$getCart.grandTotal,
            paymentMode: "COD",
            shippingAddressId: defaultAddressId
          }
        }
      }); // toast.success(<div style={{padding:"10px"}}>Order Placed</div>)
      // router.push("/pages/success")

      router.push({
        pathname: "/pages/success",
        query: {
          orderId: response === null || response === void 0 ? void 0 : (_response$data = response.data) === null || _response$data === void 0 ? void 0 : (_response$data$create = _response$data.createUserOrder) === null || _response$data$create === void 0 ? void 0 : _response$data$create.orderId
        }
      });
    } catch (error) {
      // toast.error(<div style={{padding:"10px"}}>{error.message}</div>)
      router.push("/pages/failed");
    }
  };

  (0,external_react_.useEffect)(() => {
    if (!arabtoken) {
      router.push("/pages/login");
    }
  }, []);
  return __jsx((external_react_default()).Fragment, null, __jsx(external_react_helmet_.Helmet, null, __jsx("title", null, "Checkout | Arab Deals")), __jsx("ul", {
    className: "checkout-progress-bar d-flex justify-content-center flex-wrap"
  }, __jsx("li", null, __jsx(ALink/* default */.Z, {
    href: "/pages/cart"
  }, "Shopping Cart")), __jsx("li", {
    className: "active"
  }, __jsx(ALink/* default */.Z, {
    href: "/pages/checkout"
  }, "Checkout")), __jsx("li", {
    className: "disabled"
  }, __jsx(ALink/* default */.Z, {
    href: "#"
  }, "Order Complete"))), __jsx("main", {
    className: "main main-test"
  }, isShipping ? __jsx((external_react_default()).Fragment, null, __jsx(Shippingaddress/* default */.ZP, {
    isEdit: isEdit,
    addressId: selectedAddressId,
    onClose: handleCloseShipping,
    isShipping: isShipping,
    onIsShipping: setIsshipping
  })) : __jsx("div", {
    className: "container checkout-container"
  }, (cartList === null || cartList === void 0 ? void 0 : cartList.length) === 0 ? __jsx("div", {
    className: "cart-empty-page text-center"
  }, __jsx("p", {
    className: "noproduct-msg mb-2"
  }, "Checkout is not available while your cart is empty."), __jsx("i", {
    className: "icon-bag-2"
  }), __jsx("p", null, "No products added to the cart"), __jsx(ALink/* default */.Z, {
    href: "/shop",
    className: "btn btn-dark btn-add-cart product-type-simple btn-shop font1"
  }, "return to shop")) : __jsx((external_react_default()).Fragment, null, __jsx("div", {
    className: "row",
    style: {
      marginTop: "62px"
    }
  }, __jsx("div", {
    className: "col-lg-7"
  }, __jsx("div", null, __jsx("h2", {
    className: "step-title"
  }, "Select a shipping address"), __jsx("div", {
    className: "shipingBox" // style={{border:"1px solid #dfdfdf",borderRadius:"4px",padding:"10px"}}

  }, data && (data === null || data === void 0 ? void 0 : (_data$getUserShipping = data.getUserShippingAddresses) === null || _data$getUserShipping === void 0 ? void 0 : _data$getUserShipping.address.length) > 0 ? data === null || data === void 0 ? void 0 : (_data$getUserShipping2 = data.getUserShippingAddresses) === null || _data$getUserShipping2 === void 0 ? void 0 : _data$getUserShipping2.address.map((address, index) => {
    var _data$getUserShipping3;

    return __jsx((external_react_default()).Fragment, null, __jsx("div", {
      key: index,
      style: {
        lineHeight: "19px",
        alignItems: "baseline",
        gap: "20px",
        border: "1px solid #dfdfdf",
        margin: "15px 0",
        padding: "10px",
        borderRadius: "4px"
      }
    }, __jsx("div", null, __jsx("div", {
      className: "custom-control custom-radio d-flex"
    }, __jsx("input", {
      type: "radio",
      className: "custom-control-input",
      id: `shipaddress${index}`,
      value: address._id,
      checked: defaultAddressId === address._id,
      onChange: () => handleAddressSelection(address._id)
    }), __jsx("label", {
      className: "custom-control-label",
      style: {
        paddingLeft: "10px",
        maxWidth: "575px"
      },
      htmlFor: `shipaddress${index}`
    }, address === null || address === void 0 ? void 0 : address.firstname, ", \xA0", address === null || address === void 0 ? void 0 : address.houseNumber, ",", " ", address === null || address === void 0 ? void 0 : address.streetName, ", \xA0", address === null || address === void 0 ? void 0 : address.postCode, ",", address === null || address === void 0 ? void 0 : address.city, ", ", address === null || address === void 0 ? void 0 : address.country))), __jsx("div", {
      style: {
        display: "flex",
        color: "black",
        width: "100%",
        alignItems: "flex-end",
        justifyContent: "flex-end"
      }
    }, __jsx("div", {
      className: " btn-address-edit",
      onClick: () => {
        setIsshipping(true);
        setIsedit(true);
        setSelectedAddressId(address === null || address === void 0 ? void 0 : address._id);
      }
    }, "Edit"), data && (data === null || data === void 0 ? void 0 : (_data$getUserShipping3 = data.getUserShippingAddresses) === null || _data$getUserShipping3 === void 0 ? void 0 : _data$getUserShipping3.address.length) > 1 && __jsx("button", {
      style: {
        cursor: "pointer",
        background: "none",
        border: "none",
        color: "#E30613"
      },
      onClick: () => handleRemove(address === null || address === void 0 ? void 0 : address._id)
    }, "Remove"))));
  }) : "", __jsx("div", {
    style: {
      display: "flex",
      gap: "15px",
      alignItems: "center",
      cursor: "pointer"
    },
    onClick: () => {
      setIsshipping(true);
    }
  }, __jsx(index_esm/* IoAddCircleOutline */.RWZ, {
    style: {
      fontSize: "20px"
    }
  }), __jsx("p", {
    className: "addaddressbtn",
    style: {
      margin: 0
    }
  }, " ", "Add Address", " "))))), __jsx("div", {
    className: "col-lg-5"
  }, __jsx("div", {
    className: "order-box"
  }, __jsx("div", {
    className: "order-summary"
  }, __jsx("h3", null, "YOUR ORDER"), __jsx("table", {
    className: "table table-mini-cart"
  }, __jsx("thead", null, __jsx("tr", null, __jsx("th", {
    colSpan: "2",
    style: {
      fontSize: "1.4rem",
      fontWeight: "600"
    }
  }, "Product"))), __jsx("tbody", null, cartList === null || cartList === void 0 ? void 0 : cartList.map((item, index) => __jsx("tr", {
    key: "checks" + index
  }, __jsx("td", {
    className: "product-col"
  }, __jsx("h2", {
    className: "product-title"
  }, (item === null || item === void 0 ? void 0 : item.name) + " × " + (item === null || item === void 0 ? void 0 : item.quantity))), __jsx("td", {
    className: "price-col"
  }, __jsx("span", null, "OMR ", (item === null || item === void 0 ? void 0 : item.sellingPrice) * (item === null || item === void 0 ? void 0 : item.quantity)))))), __jsx("tfoot", null, __jsx("tr", {
    className: "cart-subtotal"
  }, __jsx("td", null, __jsx("h4", null, "Subtotal")), __jsx("td", {
    className: "price-col"
  }, __jsx("span", null, "OMR ", cartData === null || cartData === void 0 ? void 0 : (_cartData$getCart2 = cartData.getCart) === null || _cartData$getCart2 === void 0 ? void 0 : _cartData$getCart2.subTotal))), __jsx("tr", {
    className: "cart-subtotal"
  }, __jsx("td", null, __jsx("h4", null, "Shipping Charge")), __jsx("td", {
    className: "price-col"
  }, __jsx("span", null, "OMR ", cartData === null || cartData === void 0 ? void 0 : (_cartData$getCart3 = cartData.getCart) === null || _cartData$getCart3 === void 0 ? void 0 : _cartData$getCart3.deliveryCharge))), __jsx("tr", {
    className: "order-total"
  }, __jsx("td", null, __jsx("h4", null, "Total")), __jsx("td", null, __jsx("b", {
    className: "total-price"
  }, __jsx("span", null, "OMR ", cartData === null || cartData === void 0 ? void 0 : (_cartData$getCart4 = cartData.getCart) === null || _cartData$getCart4 === void 0 ? void 0 : _cartData$getCart4.grandTotal)))))), __jsx("div", {
    className: "payment-methods"
  }, __jsx("h4", {
    className: ""
  }, "Payment methods"), __jsx("div", {
    className: "info-box with-icon p-0"
  }, __jsx("div", {
    className: "custom-control custom-radio d-flex"
  }, __jsx("input", {
    type: "radio",
    className: "custom-control-input",
    name: "radio",
    defaultChecked: true
  }), __jsx("label", {
    className: "custom-control-label"
  }, "Cash on Delivery")))), __jsx("button", {
    type: "submit",
    value: "Place Order",
    name: "form-control",
    className: "btn btn-dark btn-place-order hoverbtn",
    onClick: handlePlaceOrder
  }, "Place order")))))))));
}

const mapStateToProps = state => {
  return {
    cartList: state.cartlist.cart ? state.cartlist.cart : []
  };
};

/* harmony default export */ var checkout = ((0,apollo/* default */.Z)({
  ssr: true
})((0,external_react_redux_.connect)(mapStateToProps)(CheckOut)));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 6481:
/***/ (function(module) {

"use strict";
module.exports = require("react-helmet");;

/***/ }),

/***/ 2662:
/***/ (function(module) {

"use strict";
module.exports = require("react-hook-form");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,155,6285,7164,9592], function() { return __webpack_exec__(548); });
module.exports = __webpack_exports__;

})();