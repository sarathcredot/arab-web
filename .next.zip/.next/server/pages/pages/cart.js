(function() {
var exports = {};
exports.id = 9839;
exports.ids = [9839];
exports.modules = {

/***/ 4140:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_common_ALink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8974);
/* harmony import */ var _components_partials_product_qty__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7029);
/* harmony import */ var _store_cart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2806);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2821);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1649);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7164);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6481);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_9__);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










 // import {useQuery} from "@apollo/react-hooks"




const GET_CART = _apollo_client__WEBPACK_IMPORTED_MODULE_6__.gql`
  query GetCart {
    getCart {
      products {
        _id
        productId
        quantity
        name
        shortDescription
        stock
        color
        size
        price
        image
        sellingPrice
        mrp
      }
      grandTotal
      subTotal
      deliveryCharge
    }
  }
`;
const PUT_CART = _apollo_client__WEBPACK_IMPORTED_MODULE_6__.gql`
  mutation UpdateCartQuantity($input: updateCartQuantityInput!) {
    updateCartQuantity(input: $input) {
      message
    }
  }
`;
const REMOVE_CART = _apollo_client__WEBPACK_IMPORTED_MODULE_6__.gql`
  mutation RemoveFromCart($input: removeFromCartInput!) {
    removeFromCart(input: $input) {
      message
    }
  }
`;

function Cart(props) {
  var _cartCharges$subTotal;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    0: cartList,
    1: setCartList
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: cartCharges,
    1: setCartCharges
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
    grandTotal: 0,
    subTotal: 0,
    deliveryCharge: 0
  });
  const [updateCartQuantity] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_6__.useMutation)(PUT_CART);
  const [removeFromCart] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_6__.useMutation)(REMOVE_CART);
  const token = localStorage.getItem("arabtoken");
  const {
    0: localCart,
    1: setLocalCart
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(JSON.parse(localStorage.getItem("cart")) || []);
  const {
    0: isLoading,
    1: setIsLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    data: cartData,
    loading: cartLoading,
    error: cartError,
    refetch: cartRefetch
  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_6__.useQuery)(GET_CART, {
    skip: !token
  }); // For authenticated users

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (token) {
      if (cartError) {
        console.error("Error fetching cart data:", cartError);
      } else if (cartData) {
        const cartProducts = cartData.getCart.products || [];
        setCartList(cartProducts);
        setCartCharges({
          grandTotal: cartData.getCart.grandTotal,
          subTotal: cartData.getCart.subTotal,
          deliveryCharge: cartData.getCart.deliveryCharge
        });
      }

      cartRefetch();
    }
  }, [token, cartData, cartError, cartRefetch]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (!token && localCart.length > 0) {
      setCartList(localCart);
      const subTotal = localCart.reduce((acc, item) => acc + item.sellingPrice * item.quantity, 0);
      setCartCharges(prevCharges => _objectSpread(_objectSpread({}, prevCharges), {}, {
        subTotal: subTotal
      }));
    }
  }, [token, localCart]);

  const removeCart = async id => {
    try {
      if (token) {
        const response = await removeFromCart({
          variables: {
            input: {
              productId: id
            }
          }
        });
        cartRefetch();
        react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.success("Successfully removed product");
      }

      if (!token) {
        const storedCartItems = localStorage.getItem("cart");

        if (storedCartItems !== null) {
          const currentCartItems = JSON.parse(storedCartItems);
          const updatedCartItems = currentCartItems.filter(item => item.productId !== id);
          localStorage.setItem("cart", JSON.stringify(updatedCartItems));
          const subTotal = updatedCartItems.reduce((acc, item) => acc + item.sellingPrice * item.quantity, 0);
          setCartList(updatedCartItems);
          setCartCharges(prevCharges => _objectSpread(_objectSpread({}, prevCharges), {}, {
            subTotal: subTotal
          }));
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  const onChangeQty = async (id, qty) => {
    if (token) {
      try {
        setIsLoading(true);
        const response = await updateCartQuantity({
          variables: {
            input: {
              productId: id,
              quantity: qty
            }
          }
        });

        if (response) {
          cartRefetch();
        }

        setIsLoading(false);
      } catch (error) {
        console.log(error);
        setIsLoading(false);
      }
    } else {
      const storedCartItems = localStorage.getItem("cart");

      if (storedCartItems !== null) {
        const currentCartItems = JSON.parse(storedCartItems);
        const updatedCartItems = currentCartItems.map(item => {
          if (item.productId === id) {
            return _objectSpread(_objectSpread({}, item), {}, {
              quantity: qty
            });
          } else {
            return item;
          }
        });
        localStorage.setItem("cart", JSON.stringify(updatedCartItems));
        const subTotal = updatedCartItems.reduce((acc, item) => acc + item.sellingPrice * item.quantity, 0);
        setCartList(updatedCartItems);
        setCartCharges(prevCharges => _objectSpread(_objectSpread({}, prevCharges), {}, {
          subTotal: subTotal
        }));
      }
    }
  };

  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx(react_helmet__WEBPACK_IMPORTED_MODULE_9__.Helmet, null, __jsx("title", null, "Cart | Arab Deals")), __jsx("main", {
    className: "main"
  }, __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav"
  }, __jsx("div", {
    className: "container"
  }, __jsx("ol", {
    className: "breadcrumb"
  }, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: "/"
  }, __jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_10__/* .IoMdHome */ .QO$, {
    style: {
      fontSize: "16px"
    }
  }))), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    className: "activeitem",
    href: "/pages/cart"
  }, "Shopping cart"))))), __jsx("div", {
    className: " d-flex flex-column align-items-center"
  }, __jsx("ul", {
    className: "checkout-progress-bar d-flex justify-content-center flex-wrap",
    style: {
      backgroundColor: "#F9F9F9",
      width: "100%"
    }
  }, __jsx("li", {
    className: "active"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: "/pages/cart"
  }, "Shopping cart")), __jsx("li", {
    className: ""
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: "/pages/checkout"
  }, "checkout")), __jsx("li", {
    className: ""
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: "/pages/checkout"
  }, "Order Complete")))), __jsx("div", {
    className: "container",
    style: {
      marginTop: "70px"
    }
  }, (cartList === null || cartList === void 0 ? void 0 : cartList.length) === 0 ? __jsx("div", {
    className: "cart-table-container"
  }, __jsx("div", {
    className: "table table-cart"
  }, __jsx("div", {
    className: "cart-empty-page text-center"
  }, __jsx("i", {
    className: "icon-bag-2"
  }), __jsx("p", null, "No products added to the cart"), __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: "/shop",
    className: "btn btn-dark btn-add-cart product-type-simple btn-shop font1"
  }, "return to shop")))) : __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-8"
  }, __jsx("div", {
    className: "cart-table-container"
  }, __jsx("table", {
    className: "table table-cart"
  }, __jsx("thead", null, __jsx("tr", null, __jsx("th", {
    className: "thumbnail-col"
  }, "Product"), __jsx("th", {
    className: "product-col pl-0"
  }), __jsx("th", {
    className: "price-col"
  }, "Price"), __jsx("th", {
    className: "qty-col"
  }, "Quantity"), __jsx("th", {
    className: "text-right"
  }, "Subtotal"))), __jsx("tbody", null, cartList === null || cartList === void 0 ? void 0 : cartList.map((item, index) => __jsx("tr", {
    key: "cart-item" + index,
    className: "product-row",
    style: {
      color: "black"
    }
  }, __jsx("td", {
    className: "pl-0"
  }, __jsx("figure", {
    className: "product-image-container"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: `/product/default/${item.productId}`,
    className: "product-image"
  }, __jsx("img", {
    src: item === null || item === void 0 ? void 0 : item.image,
    alt: "product"
  })), __jsx("div", {
    title: "Remove Product",
    style: {
      width: "20px",
      height: "20px",
      position: "absolute",
      top: "-7px",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      right: "-5px",
      borderRadius: "50%",
      // background: "white",
      filter: "drop-shadow(1px 1px 6px rgba(0, 0, 0, 0.11))"
    },
    className: "hoverinto",
    onClick: e => {
      e.preventDefault();
      removeCart(item.productId, index);
    }
  }, __jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_11__/* .AiOutlineClose */ .oHP, {
    style: {
      fontSize: "10px"
    }
  })))), __jsx("td", {
    className: "product-col"
  }, __jsx("h5", {
    className: "product-title"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    href: `/product/default/${item === null || item === void 0 ? void 0 : item.productId}`
  }, item.name))), __jsx("td", null, "OMR ", item.sellingPrice.toFixed(2)), __jsx("td", null, __jsx(_components_partials_product_qty__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    disabled: isLoading,
    value: item === null || item === void 0 ? void 0 : item.quantity,
    max: (item === null || item === void 0 ? void 0 : item.stock) || 10,
    onChangeQty: qty => onChangeQty(item === null || item === void 0 ? void 0 : item.productId, qty)
  })), __jsx("td", {
    className: "text-right"
  }, __jsx("span", {
    className: "subtotal-price"
  }, "OMR", " ", (parseInt(item.sellingPrice) * parseInt(item.quantity)).toFixed(2)))))), __jsx("tfoot", null)))), __jsx("div", {
    className: "col-lg-4"
  }, __jsx("div", {
    className: "cart-summary"
  }, __jsx("h3", null, "Cart Totals"), __jsx("table", {
    className: "table table-totals"
  }, __jsx("tbody", null, token && __jsx("tr", null, __jsx("td", null, "Shipping Charge"), __jsx("td", {
    style: {
      color: "black"
    }
  }, "OMR ", cartCharges.deliveryCharge)), __jsx("tr", null, __jsx("td", null, "Subtotal"), __jsx("td", {
    style: {
      color: "black"
    }
  }, "OMR ", (_cartCharges$subTotal = cartCharges.subTotal) === null || _cartCharges$subTotal === void 0 ? void 0 : _cartCharges$subTotal.toFixed(2)))), __jsx("tfoot", null, token && __jsx("tr", null, __jsx("td", null, "Total"), __jsx("td", null, "OMR ", cartCharges.grandTotal)))), __jsx("div", {
    className: "checkout-methods"
  }, __jsx("div", {
    href: "checkout",
    className: "btn btn-block btn-dark hoverbtn",
    onClick: () => {
      if (token) {
        router.push("/pages/checkout");
      } else {
        router.push("/pages/login?origin=pages-cart");
      }
    }
  }, "Proceed to Checkout")))))), __jsx("div", {
    className: "mb-6"
  })));
}

const mapStateToProps = state => {
  return {
    cart: state.cartlist.cart ? state.cartlist.cart : []
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)({
  ssr: true
})((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)(mapStateToProps, _objectSpread({}, _store_cart__WEBPACK_IMPORTED_MODULE_5__/* .actions */ .Nw))(Cart)));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 6481:
/***/ (function(module) {

"use strict";
module.exports = require("react-helmet");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,8193,6285,7164,2806,7029], function() { return __webpack_exec__(4140); });
module.exports = __webpack_exports__;

})();