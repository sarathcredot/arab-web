(function() {
var exports = {};
exports.id = 9834;
exports.ids = [9834];
exports.modules = {

/***/ 3847:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _slug_; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: ./components/features/owl-carousel.jsx
var owl_carousel = __webpack_require__(4138);
// EXTERNAL MODULE: ./components/partials/blog/blog-sidebar.jsx + 1 modules
var blog_sidebar = __webpack_require__(1094);
;// CONCATENATED MODULE: ./components/features/blogs/blog-type-three.jsx
var __jsx = (external_react_default()).createElement;
 // import { LazyLoadImage } from 'react-lazy-load-image-component';
// Import Custom Component



function BlogTypeThree(props) {
  const {
    blog
  } = props;
  let date = new Date(blog.date);
  let monthArray = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return __jsx("article", {
    className: "post media-with-lazy"
  }, __jsx("figure", {
    className: "post-media zoom-effect"
  }, blog.picture ? __jsx(ALink/* default */.Z, {
    href: `/pages/blog/${blog.slug}`
  }, __jsx("div", {
    className: "lazy-overlay"
  }), __jsx(LazyLoadImage, {
    alt: "post_image",
    src: process.env.NEXT_PUBLIC_ASSET_URI + blog.picture[0].url,
    threshold: 500,
    width: "100%",
    height: "auto",
    effect: "blur"
  })) : ""), __jsx("div", {
    className: "post-body"
  }, __jsx("div", {
    className: "post-date"
  }, __jsx("span", {
    className: "day"
  }, `${date.getUTCDate() < 10 ? "0" + date.getUTCDate() : date.getUTCDate()}`), __jsx("span", {
    className: "month"
  }, monthArray[date.getUTCMonth()])), __jsx("h2", {
    className: "post-title"
  }, __jsx(ALink/* default */.Z, {
    href: `/pages/blog/${blog.slug}`
  }, blog.title)), __jsx("div", {
    className: "post-content"
  }, __jsx("p", null, blog.content), __jsx(ALink/* default */.Z, {
    href: `/pages/blog/${blog.slug}`,
    className: "read-more d-flex align-items-center"
  }, "Read More ", __jsx("i", {
    className: "fas fa-angle-right"
  })))));
}

/* harmony default export */ var blog_type_three = (BlogTypeThree);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: ./store/modal.js
var modal = __webpack_require__(6723);
;// CONCATENATED MODULE: ./components/features/blogs/blog-single.jsx
var blog_single_jsx = (external_react_default()).createElement;

 // import { LazyLoadImage } from 'react-lazy-load-image-component';
// Import Action

 // Import Custom Component




function BlogSingle(props) {
  const {
    blog,
    loading
  } = props;
  let date = new Date(blog && blog.date);
  let monthArray = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  function openModal(e) {
    e.preventDefault();
    props.showVideo();
  }

  return loading ? blog_single_jsx("div", {
    className: "skel-post"
  }) : blog_single_jsx((external_react_default()).Fragment, null, blog_single_jsx("article", {
    className: "post single"
  }, blog_single_jsx("figure", {
    className: "post-media",
    style: {
      paddingTop: `${100 * blog.picture[0].height / blog.picture[0].width}%`
    }
  }, blog.picture ? blog.picture.length > 1 ? blog_single_jsx(owl_carousel/* default */.Z, {
    adClass: "owl-theme post-slider show-nav-hover",
    options: {
      nav: true,
      dots: false
    }
  }, blog.picture.map((picture, index) => blog_single_jsx(LazyLoadImage, {
    alt: "post_image",
    src: process.env.NEXT_PUBLIC_ASSET_URI + picture.url,
    threshold: 500,
    width: "100%",
    height: "100%",
    effect: "blur",
    key: "blog" + index
  }))) : blog_single_jsx(LazyLoadImage, {
    alt: "post_image",
    src: process.env.NEXT_PUBLIC_ASSET_URI + blog.picture[0].url,
    threshold: 500,
    width: "100%",
    height: "100%",
    effect: "blur"
  }) : "", blog.video && blog_single_jsx("a", {
    className: "btn-play btn-iframe",
    onClick: openModal,
    href: "https://www.youtube.com/watch?v=vBPgmASQ1A0"
  }, blog_single_jsx("i", {
    className: "fas fa-play"
  }))), blog_single_jsx("div", {
    className: "post-body"
  }, blog_single_jsx("div", {
    className: "post-date"
  }, blog_single_jsx("span", {
    className: "day"
  }, `${date.getUTCDate() < 10 ? "0" + date.getUTCDate() : date.getUTCDate()}`), blog_single_jsx("span", {
    className: "month"
  }, monthArray[date.getUTCMonth()])), blog_single_jsx("h2", {
    className: "post-title"
  }, blog_single_jsx(ALink/* default */.Z, {
    href: "#"
  }, blog.title)), blog_single_jsx("div", {
    className: "post-meta"
  }, blog_single_jsx(ALink/* default */.Z, {
    href: "#",
    className: "hash-scroll"
  }, blog_single_jsx("span", null, blog.comments), " Comments")), blog_single_jsx("div", {
    className: "post-content"
  }, blog_single_jsx("p", null, blog.content), blog_single_jsx("h3", null, "\u201C Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model search for evolved over sometimes by accident, sometimes on purpose \u201D"), blog_single_jsx("p", null, "Aenean lorem diam, venenatis nec venenatis id, adipiscing ac massa. Nam vel dui eget justo dictum pretium a rhoncus ipsum. Donec venenatis erat tincidunt nunc suscipit, sit amet bibendum lacus posuere. Sed scelerisque, dolor a pharetra sodales, mi augue consequat sapien, et interdum tellus leo et nunc. Nunc imperdiet eu libero ut imperdiet.")), blog_single_jsx("div", {
    className: "post-share"
  }, blog_single_jsx("h3", {
    className: "d-flex align-items-center"
  }, blog_single_jsx("i", {
    className: "fas fa-share"
  }), "Share this post"), blog_single_jsx("div", {
    className: "social-icons"
  }, blog_single_jsx(ALink/* default */.Z, {
    href: "#",
    className: "social-icon social-facebook",
    title: "Facebook"
  }, blog_single_jsx("i", {
    className: "icon-facebook"
  })), blog_single_jsx(ALink/* default */.Z, {
    href: "#",
    className: "social-icon social-twitter",
    title: "Twitter"
  }, blog_single_jsx("i", {
    className: "icon-twitter"
  })), blog_single_jsx(ALink/* default */.Z, {
    href: "#",
    className: "social-icon social-linkedin",
    title: "Linkedin"
  }, blog_single_jsx("i", {
    className: "fab fa-linkedin-in"
  })), blog_single_jsx(ALink/* default */.Z, {
    href: "#",
    className: "social-icon social-mail",
    title: "Email"
  }, blog_single_jsx("i", {
    className: "icon-mail-alt"
  })))), blog_single_jsx("div", {
    className: "post-author"
  }, blog_single_jsx("h3", null, blog_single_jsx("i", {
    className: "far fa-user"
  }), "Author"), blog_single_jsx("div", {
    className: "media-with-lazy"
  }, blog_single_jsx("figure", {
    className: "mb-0"
  }, blog_single_jsx(ALink/* default */.Z, {
    href: "#"
  }, blog_single_jsx(LazyLoadImage, {
    alt: "author",
    src: "images/blog/author.jpg",
    threshold: 500,
    width: "100%",
    height: 80,
    effect: "blur"
  })))), blog_single_jsx("div", {
    className: "author-content"
  }, blog_single_jsx("h4", null, blog_single_jsx(ALink/* default */.Z, {
    href: "#"
  }, "Jone Doe")), blog_single_jsx("p", null, "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae. Sed dui lorem, adipiscing in adipiscing et, interdum nec metus. Mauris ultricies, justo eu convallis placerat, felis enim ornare nisi, vitae mattis nulla ante id dui."))), blog_single_jsx("div", {
    className: "comment-respond"
  }, blog_single_jsx("h3", null, "Leave a Reply"), blog_single_jsx("form", {
    action: "#"
  }, blog_single_jsx("p", null, "Your email address will not be published. Required fields are marked *"), blog_single_jsx("div", {
    className: "form-group"
  }, blog_single_jsx("label", null, "Comment"), blog_single_jsx("textarea", {
    cols: "30",
    rows: "1",
    className: "form-control",
    required: true
  })), blog_single_jsx("div", {
    className: "form-group"
  }, blog_single_jsx("label", null, "Name"), blog_single_jsx("input", {
    type: "text",
    className: "form-control",
    required: true
  })), blog_single_jsx("div", {
    className: "form-group"
  }, blog_single_jsx("label", null, "Email"), blog_single_jsx("input", {
    type: "email",
    className: "form-control",
    required: true
  })), blog_single_jsx("div", {
    className: "form-group"
  }, blog_single_jsx("label", null, "Website"), blog_single_jsx("input", {
    type: "url",
    className: "form-control"
  })), blog_single_jsx("div", {
    className: "form-group-custom-control mb-2"
  }, blog_single_jsx("div", {
    className: "custom-control custom-checkbox"
  }, blog_single_jsx("input", {
    type: "checkbox",
    className: "custom-control-input",
    id: "save-name"
  }), blog_single_jsx("label", {
    className: "custom-control-label",
    htmlFor: "save-name"
  }, "Save my name, email, and website in this browser for the next time I comment."))), blog_single_jsx("div", {
    className: "form-footer my-0"
  }, blog_single_jsx("button", {
    type: "submit",
    className: "btn btn-sm btn-primary"
  }, "Post Comment")))))));
}

/* harmony default export */ var blog_single = ((0,external_react_redux_.connect)(null, modal/* actions */.Nw)(BlogSingle));
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
// EXTERNAL MODULE: ./utils/data/slider.js
var slider = __webpack_require__(8509);
;// CONCATENATED MODULE: ./pages/pages/blog/[slug].js

var _slug_jsx = (external_react_default()).createElement;

 // Import Apollo Server and Query


 // Import Custom Component






 //Import Settings



function Single() {
  if (!(0,router_.useRouter)().query.slug) return _slug_jsx("div", {
    className: "loading-overlay"
  }, _slug_jsx("div", {
    className: "bounce-loader"
  }, _slug_jsx("div", {
    className: "bounce1"
  }), _slug_jsx("div", {
    className: "bounce2"
  }), _slug_jsx("div", {
    className: "bounce3"
  })));
  const slug = (0,router_.useRouter)().query.slug;
  const {
    data,
    loading,
    error
  } = (0,react_hooks_.useQuery)(queries/* GET_POST */.QI, {
    variables: {
      slug
    }
  });
  const blog = data && data.post.data;
  const related = data && data.post.related; // if ( error ) {
  //     return useRouter().push( '/pages/404' );
  // }

  return _slug_jsx("main", {
    className: "main"
  }, _slug_jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-3"
  }, _slug_jsx("div", {
    className: "container"
  }, _slug_jsx("ol", {
    className: "breadcrumb"
  }, _slug_jsx("li", {
    className: "breadcrumb-item"
  }, _slug_jsx(ALink/* default */.Z, {
    href: "/"
  }, _slug_jsx(index_esm/* IoMdHome */.QO$, {
    style: {
      fontSize: "16px"
    }
  }))), _slug_jsx("li", {
    className: "breadcrumb-item"
  }, _slug_jsx(ALink/* default */.Z, {
    href: "/pages/blog"
  }, "Blog")), _slug_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, blog && blog.title)))), _slug_jsx("div", {
    className: `container skeleton-body skel-shop-products ${loading ? '' : 'loaded'}`
  }, _slug_jsx("div", {
    className: "row"
  }, _slug_jsx("div", {
    className: "col-lg-9"
  }, _slug_jsx(blog_single, {
    blog: blog,
    loading: loading
  }), !loading && !related.length ? '' : _slug_jsx((external_react_default()).Fragment, null, _slug_jsx("hr", {
    className: "mt-2 mb-1"
  }), _slug_jsx("div", {
    className: "related-posts"
  }, _slug_jsx("h4", null, "Related ", _slug_jsx("strong", null, "Posts")), _slug_jsx(owl_carousel/* default */.Z, {
    adClass: "related-posts-carousel",
    options: slider/* blogSlider */.Uw
  }, loading ? new Array(3).fill(1).map((item, index) => _slug_jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "Skeleton:" + index
  })) : related.map((blog, index) => _slug_jsx(blog_type_three, {
    blog: blog,
    key: "BlogTypeThree" + index
  })))))), _slug_jsx(blog_sidebar/* default */.Z, null))));
}

/* harmony default export */ var _slug_ = ((0,apollo/* default */.Z)({
  ssr: true
})(Single));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 9058:
/***/ (function(module) {

"use strict";
module.exports = require("react-sticky-box");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,4138,8509,1094], function() { return __webpack_exec__(3847); });
module.exports = __webpack_exports__;

})();