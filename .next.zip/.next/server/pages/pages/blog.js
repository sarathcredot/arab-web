(function() {
var exports = {};
exports.id = 3916;
exports.ids = [3916];
exports.modules = {

/***/ 417:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ blog; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-helmet"
var external_react_helmet_ = __webpack_require__(6481);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: ./components/features/owl-carousel.jsx
var owl_carousel = __webpack_require__(4138);
// EXTERNAL MODULE: ./utils/data/slider.js
var slider = __webpack_require__(8509);
// EXTERNAL MODULE: ./store/modal.js
var modal = __webpack_require__(6723);
;// CONCATENATED MODULE: ./components/features/blogs/blog-type-one.jsx
var __jsx = (external_react_default()).createElement;

 // import { LazyLoadImage } from 'react-lazy-load-image-component';
// Import Custom Component


 // Import Utils

 // Import Action



function BlogTypeOne(props) {
  const {
    adClass = "",
    blog
  } = props;
  let date = new Date(blog.date);
  let monthArray = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  function openModal(e) {
    e.preventDefault();
    props.showVideo();
  }

  return __jsx("article", {
    className: `post media-with-lazy ${adClass}`
  }, blog.picture && (blog.picture.length > 1 ? __jsx(owl_carousel/* default */.Z, {
    adClass: "owl-theme post-slider mb-0 show-nav-hover",
    options: slider/* postSlider */.jP
  }, blog.picture.map((picture, index) => __jsx("figure", {
    className: "post-media zoom-effect",
    key: `Blog:${index}`
  }, __jsx(ALink/* default */.Z, {
    href: `/pages/blog/${blog.slug}`
  }, __jsx("div", {
    className: "lazy-overlay"
  }), __jsx(LazyLoadImage, {
    alt: "post_image",
    src: process.env.NEXT_PUBLIC_ASSET_URI + picture.url,
    threshold: 500,
    width: "100%",
    height: "auto",
    effect: "blur"
  })), __jsx("div", {
    className: "post-date"
  }, __jsx("span", {
    className: "day"
  }, `${date.getUTCDate() < 10 ? "0" + date.getUTCDate() : date.getUTCDate()}`), __jsx("span", {
    className: "month"
  }, monthArray[date.getUTCMonth()])), blog.video && __jsx("a", {
    className: "btn-play btn-iframe",
    onClick: openModal,
    href: "https://www.youtube.com/watch?v=vBPgmASQ1A0"
  }, __jsx("i", {
    className: "fas fa-play"
  }))))) : __jsx("figure", {
    className: "post-media zoom-effect"
  }, __jsx(ALink/* default */.Z, {
    href: `/pages/blog/${blog.slug}`
  }, __jsx("div", {
    className: "lazy-overlay"
  }), __jsx(LazyLoadImage, {
    alt: "post_image",
    src: process.env.NEXT_PUBLIC_ASSET_URI + blog.picture[0].url,
    threshold: 500,
    width: "100%",
    height: "auto",
    effect: "blur"
  })), blog.video && __jsx("a", {
    className: "btn-play btn-iframe",
    onClick: openModal,
    href: "https://www.youtube.com/watch?v=vBPgmASQ1A0"
  }, __jsx("i", {
    className: "fas fa-play"
  })), __jsx("div", {
    className: "post-date"
  }, __jsx("span", {
    className: "day"
  }, `${date.getUTCDate() < 10 ? "0" + date.getUTCDate() : date.getUTCDate()}`), __jsx("span", {
    className: "month"
  }, monthArray[date.getUTCMonth()])))), __jsx("div", {
    className: "post-body"
  }, __jsx("h2", {
    className: "post-title"
  }, __jsx(ALink/* default */.Z, {
    href: `/pages/blog/${blog.slug}`
  }, blog.title)), __jsx("div", {
    className: "post-content"
  }, __jsx("p", null, blog.content), __jsx(ALink/* default */.Z, {
    href: `/pages/blog/${blog.slug}`,
    className: "post-comment"
  }, __jsx("span", null, blog.comments), " Comments"))));
}

/* harmony default export */ var blog_type_one = ((0,external_react_redux_.connect)(null, modal/* actions */.Nw)(BlogTypeOne));
// EXTERNAL MODULE: ./components/partials/blog/blog-sidebar.jsx + 1 modules
var blog_sidebar = __webpack_require__(1094);
// EXTERNAL MODULE: ./components/features/pagination.jsx
var pagination = __webpack_require__(2078);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/pages/blog/index.js
var blog_jsx = (external_react_default()).createElement;



 // Import Apollo Server and Query


 // Import Custom Component







function Blog() {
  const router = (0,router_.useRouter)();
  const query = router.query;
  const [getBlogs, {
    data,
    loading,
    error
  }] = (0,react_hooks_.useLazyQuery)(queries/* GET_POSTS */.p$);
  const {
    0: perPage,
    1: setPerPage
  } = (0,external_react_.useState)(6);
  const blogs = data && data.posts.data;
  const totalPage = data ? parseInt(data.posts.total / perPage) + (data.posts.total % perPage ? 1 : 0) : 1;
  let page = query.page ? query.page : 1;

  if (error) {
    return blog_jsx("div", null, error.message);
  }

  (0,external_react_.useEffect)(() => {
    let offset = document.querySelector('.main').getBoundingClientRect().top + window.pageYOffset - 68;
    setTimeout(() => {
      window.scrollTo({
        top: offset,
        behavior: 'smooth'
      });
    }, 200);
    getBlogs({
      variables: {
        category: query.category,
        from: perPage * (page - 1),
        to: perPage * page
      }
    });
  }, [query]);
  return blog_jsx((external_react_default()).Fragment, null, blog_jsx(external_react_helmet_.Helmet, null, blog_jsx("title", null, "Porto React Ecommerce - Blog Page ")), blog_jsx("main", {
    className: "main"
  }, blog_jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-3"
  }, blog_jsx("div", {
    className: "container"
  }, blog_jsx("ol", {
    className: "breadcrumb"
  }, blog_jsx("li", {
    className: "breadcrumb-item"
  }, blog_jsx(ALink/* default */.Z, {
    href: "/"
  }, blog_jsx(index_esm/* IoMdHome */.QO$, {
    style: {
      fontSize: "16px"
    }
  }))), blog_jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, "Blog")))), blog_jsx("div", {
    className: "container"
  }, blog_jsx("div", {
    className: "row"
  }, blog_jsx("div", {
    className: "col-lg-9"
  }, blog_jsx("div", {
    className: `blog-section row pt-0 pb-3 skeleton-body skel-shop-products ${loading ? '' : 'loaded'}`
  }, loading ? new Array(parseInt(perPage)).fill(1).map((item, index) => blog_jsx("div", {
    className: "col-md-6 col-lg-4",
    key: "Skeleton:" + index
  }, blog_jsx("div", {
    className: "skel-pro skel-pro-grid"
  }))) : blogs ? blogs.length ? blogs.slice(0, 6).map((blog, index) => blog_jsx("div", {
    className: "col-md-6 col-lg-4",
    key: "BlogTypeOne" + index
  }, blog_jsx(blog_type_one, {
    blog: blog
  }))) : blog_jsx("div", {
    className: "info-box with-icon"
  }, blog_jsx("p", null, "No blogs were found matching your selection.")) : ''), blog_jsx("div", {
    className: "d-flex justify-content-end mb-5"
  }, blog_jsx(pagination/* default */.Z, {
    totalPage: totalPage
  }))), blog_jsx(blog_sidebar/* default */.Z, null)))));
}

/* harmony default export */ var blog = ((0,apollo/* default */.Z)({
  ssr: true
})(Blog));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 6481:
/***/ (function(module) {

"use strict";
module.exports = require("react-helmet");;

/***/ }),

/***/ 7033:
/***/ (function(module) {

"use strict";
module.exports = require("react-owl-carousel2");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 9058:
/***/ (function(module) {

"use strict";
module.exports = require("react-sticky-box");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,4138,8509,2078,1094], function() { return __webpack_exec__(417); });
module.exports = __webpack_exports__;

})();