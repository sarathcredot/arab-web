(function() {
var exports = {};
exports.id = 8617;
exports.ids = [8617];
exports.modules = {

/***/ 1596:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ orders; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: external "react-lazy-load-image-component"
var external_react_lazy_load_image_component_ = __webpack_require__(9290);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(2034);
// EXTERNAL MODULE: ./store/wishlist.js
var wishlist = __webpack_require__(5708);
// EXTERNAL MODULE: ./store/cart.js
var cart = __webpack_require__(2806);
// EXTERNAL MODULE: ./store/modal.js
var modal = __webpack_require__(6723);
// EXTERNAL MODULE: ./node_modules/react-icons/io/index.esm.js
var index_esm = __webpack_require__(1649);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(8074);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
;// CONCATENATED MODULE: external "dayjs"
var external_dayjs_namespaceObject = require("dayjs");;
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_namespaceObject);
// EXTERNAL MODULE: external "react-helmet"
var external_react_helmet_ = __webpack_require__(6481);
;// CONCATENATED MODULE: ./pages/pages/orders.js

var __jsx = (external_react_default()).createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }














const GET_ORDERS = client_.gql`
  query GetUserOrderProducts($input: GetUserOrderProductsInput!) {
    getUserOrderProducts(input: $input) {
      maxRecords
      records {
        _id
        productId
        vendorId
        orderId
        itemId
        productName
        shortDescription
        skuId
        image {
          fileType
          fileURL
          mimeType
          originalName
        }
        returnPeriod
        mrp
        sellingPrice
        shippingCharge
        paymentMode
        paymentStatus
        orderDate
        shippingStatus
        shippedDate
        deliveryDate
        returnStatus
        returnDate
        returnRequestDate
        returnRejectedDate
        returnUserReason
        refundStatus
        refundAmount
        refundDate
        cancelledDate
        cancelUserReason
        courierId
        invoiceNumber
        invoice {
          fileType
          fileURL
          mimeType
          originalName
        }
      }
    }
  }
`;
const CANCEL_ORDER = client_.gql`
  mutation CancelUserOrderProduct($input: CancelUserOrderProductInput!) {
    cancelUserOrderProduct(input: $input) {
      _id
    }
  }
`;
const DOWNLOAD_INVOICE = client_.gql`
  mutation GetUserIvoiceSignedUrl($input: GetUserIvoiceUrlInput!) {
    getUserIvoiceSignedUrl(input: $input) {
      url
    }
  }
`;

function Orders(props) {
  const {
    wishlist,
    addToCart,
    removeFromWishlist,
    showQuickView
  } = props;
  const {
    0: flag,
    1: setFlag
  } = (0,external_react_.useState)(0);
  const {
    0: orders,
    1: setOrders
  } = (0,external_react_.useState)([]);

  const onMoveFromToWishlit = (e, item) => {
    setFlag(2);
    e.preventDefault();
    addToCart(item);
    removeFromWishlist(item);
  };

  const removeProduct = (e, item) => {
    setFlag(1);
    e.preventDefault();
    removeFromWishlist(item);
  };

  const onQuickViewClick = (e, product) => {
    e.preventDefault();
    showQuickView(product.slug);
  };

  const getStatusColor = status => {
    switch (status) {
      case "PENDING":
        return "#FFA500";

      case "IN_PROGRESS":
        return "#FFA500";

      case "COMPLETED":
        return "#44961D";

      default:
        return "#000000";
    }
  };

  const {
    data: orderData,
    loading: orderLoading,
    error: orderError,
    refetch: orderRefetch
  } = (0,client_.useQuery)(GET_ORDERS, {
    variables: {
      input: {
        page: null,
        size: null
      }
    },
    fetchPolicy: "network-only"
  });
  const [cancelUserOrderProduct] = (0,client_.useMutation)(CANCEL_ORDER);
  const [downloadInvoice] = (0,client_.useMutation)(DOWNLOAD_INVOICE);
  const {
    data,
    loading,
    error,
    refetch
  } = (0,client_.useQuery)(GET_ORDERS, {
    variables: {
      input: {
        page: null,
        size: null
      }
    }
  });
  (0,external_react_.useEffect)(() => {
    if (error) {
      console.error("Error fetching orders:", error);
    } else if (data) {
      setOrders(data.getUserOrderProducts.records || []);
    }
  }, [data, error]);

  const orderCancel = async id => {
    try {
      const response = await cancelUserOrderProduct({
        variables: {
          input: {
            _id: id
          }
        }
      });
      refetch();
      external_react_toastify_.toast.success(__jsx("div", {
        style: {
          padding: "10px"
        }
      }, "Your order has been canceled."));
    } catch (error) {
      console.log(error);
    }
  };

  const handleDownload = async _id => {
    try {
      const invoice = await downloadInvoice({
        variables: {
          input: {
            _id
          }
        }
      });
      const url = invoice.data.getUserIvoiceSignedUrl.url; // console.log("invoice", url);
      // const link = document.createElement('a');
      // link.href = url;
      // link.setAttribute('download', 'invoice.pdf');
      // document.body.appendChild(link);
      // link.click();
      // document.body.removeChild(link);

      window.open(url, "_blank");
    } catch (error) {
      external_react_toastify_.toast.error(error.message);
    }
  };

  return __jsx((external_react_default()).Fragment, null, __jsx(external_react_helmet_.Helmet, null, __jsx("title", null, "Orders | Arab Deals")), __jsx("main", {
    className: "main"
  }, __jsx("div", {
    className: "container"
  }, __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav"
  }, __jsx("div", {
    className: "container"
  }, __jsx("ol", {
    className: "breadcrumb"
  }, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(ALink/* default */.Z, {
    href: "/"
  }, __jsx(index_esm/* IoMdHome */.QO$, {
    style: {
      fontSize: "16px"
    }
  }))), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, __jsx(ALink/* default */.Z, {
    href: "/pages/account"
  }, "My account")), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, __jsx(ALink/* default */.Z, {
    className: "activeitem",
    href: "/pages/orders"
  }, "Orders")))))), __jsx("div", {
    className: " d-flex flex-column align-items-center"
  }, __jsx("ul", {
    className: "checkout-progress-bar d-flex justify-content-center flex-wrap",
    style: {
      backgroundColor: "#F9F9F9",
      width: "100%"
    }
  }, __jsx("li", {
    className: ""
  }, __jsx(ALink/* default */.Z, {
    href: "/pages/account"
  }, "My Account")), __jsx("li", {
    className: "active"
  }, __jsx(ALink/* default */.Z, {
    href: "/pages/orders"
  }, "Orders")))), __jsx("div", {
    className: "container",
    style: {
      marginTop: "2rem",
      borderBottom: "1px solid",
      borderColor: "#E2E2E2"
    }
  }, __jsx("h4", null, "Orders")), __jsx("div", {
    className: "container",
    style: {}
  }, __jsx("div", {
    className: "success-alert"
  }, flag === 1 ? __jsx("p", null, "Product successfully removed.") : "", flag === 2 ? __jsx("p", null, "Product added to cart successfully.") : ""), orders.length === 0 ? __jsx("div", {
    className: "wishlist-table-container"
  }, __jsx("div", {
    className: "table table-wishlist mb-0"
  }, __jsx("div", {
    className: "wishlist-empty-page text-center"
  }, __jsx("i", {
    class: "fa fa-shopping-bag",
    "aria-hidden": "true"
  }), __jsx("p", null, "No products Ordered"), __jsx(ALink/* default */.Z, {
    href: "/shop",
    className: "btn btn-dark btn-add-cart product-type-simple btn-shop font1 w-auto"
  }, "go shop", " ")))) : __jsx("div", {
    className: "wishlist-table-container"
  }, __jsx("table", {
    className: "table table-wishlist mb-0"
  }, __jsx("thead", null, __jsx("tr", null, __jsx("th", {
    className: "thumbnail-col"
  }, "Product"), __jsx("th", {
    className: "status-col"
  }), __jsx("th", {
    className: "status-col"
  }, "Order Id"), __jsx("th", {
    className: "status-col"
  }, "Date"), __jsx("th", {
    className: "status-col"
  }, "Status"), __jsx("th", {
    className: "price-col"
  }, "Total Price"), __jsx("th", {
    className: "action-col"
  }, "Actions"))), __jsx("tbody", null, orders.map((item, index) => __jsx("tr", {
    key: "wishlist-item" + index,
    className: "product-row"
  }, __jsx("td", {
    className: "media-with-lazy"
  }, __jsx("figure", {
    className: "product-image-container"
  }, __jsx(ALink/* default */.Z, {
    href: `/product/default/${item.productId}`,
    className: "product-image"
  }, __jsx(external_react_lazy_load_image_component_.LazyLoadImage, {
    alt: "product",
    src: item.image.fileURL,
    threshold: 500,
    width: "80",
    height: "80"
  })))), __jsx("td", null, __jsx("h5", {
    className: "product-title"
  }, __jsx(ALink/* default */.Z, {
    href: `/product/default/${item.productId}`
  }, item.productName))), __jsx("td", {
    style: {
      color: "black"
    }
  }, item.orderId), __jsx("td", {
    style: {
      color: "black"
    }
  }, external_dayjs_default()(item.orderDate).format("YYYY/MM/DD")), __jsx("td", {
    style: {
      color: getStatusColor(item === null || item === void 0 ? void 0 : item.shippingStatus)
    }
  }, item === null || item === void 0 ? void 0 : item.shippingStatus), __jsx("td", {
    style: {
      color: "black"
    }
  }, __jsx("div", {
    className: "price-box"
  }, __jsx((external_react_default()).Fragment, null, __jsx("span", {
    className: "product-price"
  }, "OMR", " ", parseFloat(Number(item.sellingPrice) + Number(item === null || item === void 0 ? void 0 : item.shippingCharge)).toFixed(2))))), (item === null || item === void 0 ? void 0 : item.shippingStatus) !== "DELIVERED" && (item === null || item === void 0 ? void 0 : item.shippingStatus) !== "SHIPPED" && (item === null || item === void 0 ? void 0 : item.shippingStatus) !== "CANCELED" ? __jsx("td", {
    className: "action"
  }, __jsx("button", {
    className: "btn btn-quickview mt-1 mt-md-0",
    title: "Quick View",
    style: {
      border: "1px solid"
    },
    onClick: e => {
      e.preventDefault();
      orderCancel(item._id);
    }
  }, "Cancel")) : __jsx((external_react_default()).Fragment, null, !(item !== null && item !== void 0 && item.invoice) ? __jsx("td", {
    className: "action"
  }, __jsx("button", {
    className: "btn btn-quickview mt-1 mt-md-0",
    title: "Quick View",
    style: {
      border: "1px solid",
      display: "none"
    },
    disabled: true
  }, "Cancel")) : __jsx("td", {
    className: "action"
  }, __jsx("button", {
    className: "btn btn-dark ",
    title: "Quick View",
    style: {
      border: "1px solid"
    },
    onClick: e => {
      e.preventDefault();
      handleDownload(item._id);
    }
  }, __jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    style: {
      marginRight: "5px"
    }
  }, __jsx("path", {
    fill: "white",
    d: "M5 20h14v-2H5zM19 9h-4V3H9v6H5l7 7z"
  })), "Invoice"))) // <>
  //   <td>
  //     <a
  //       href={`/product/default/${item.productId}`}
  //       className="btn btn-quickview mt-1 mt-md-0"
  //       title="Quick View"
  //       style={{ border: "1px solid" }}
  //     >
  //       view
  //     </a>
  //   </td>
  // </>
  ))))))));
}

const mapStateToProps = state => {
  return {
    wishlist: state.wishlist.list ? state.wishlist.list : []
  };
};

/* harmony default export */ var orders = ((0,apollo/* default */.Z)({
  ssr: true
})((0,external_react_redux_.connect)(mapStateToProps, _objectSpread(_objectSpread(_objectSpread({}, wishlist/* actions */.Nw), cart/* actions */.Nw), modal/* actions */.Nw))(Orders)));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 6481:
/***/ (function(module) {

"use strict";
module.exports = require("react-helmet");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,2806,5708], function() { return __webpack_exec__(1596); });
module.exports = __webpack_exports__;

})();