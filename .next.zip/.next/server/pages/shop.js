(function() {
var exports = {};
exports.id = 4800;
exports.ids = [4800];
exports.modules = {

/***/ 6150:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_common_ALink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8974);
/* harmony import */ var _components_partials_shop_shop_banner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5128);
/* harmony import */ var _components_partials_shop_sidebar_shop_sidebar_one__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(101);
/* harmony import */ var _components_features_pagination__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2078);
/* harmony import */ var _components_partials_products_collection_product_grid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9066);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1649);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7164);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }










 // import { GET_PRODUCTS } from "../../server/queries";

 // import { useRouter } from 'next/router'

const GET_PRODUCTS = _apollo_client__WEBPACK_IMPORTED_MODULE_3__.gql`
  query GetProducts($input: ProductFilters) {
    getProducts(input: $input) {
      maxRecords
      records {
        _id
        vendorId
        brandId
        brandName
        productName
        shortDescription
        skuId
        description
        productInfo
        productShortInfo
        images {
          fileType
          fileURL
          mimeType
          originalName
        }
        rating
        sellingPrice
        price
        mrp
        tags
        productCode
        categoryId
        categoryNamePath
        categoryIdPath
        isBlocked
        stock
        status
        offerPrice
        attributes {
          attributeId
          attributeName
          attributeValueId
          attributeValue
          attributeDescription
        }
        productDetailImages {
          fileType
          fileURL
          mimeType
          originalName
        }
        warehouseSkuId
      }
    }
  }
`;

function Shop() {
  var _data$getProducts, _data$getProducts2, _data$getProducts3, _data$getProducts4;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const query = router.query;

  const {
    cat_id,
    page
  } = query,
        rest = _objectWithoutProperties(query, ["cat_id", "page"]);

  const {
    category,
    brands,
    max_price,
    min_price,
    sort_order,
    discount,
    bestSeller,
    search
  } = rest,
        filteredAttributes = _objectWithoutProperties(rest, ["category", "brands", "max_price", "min_price", "sort_order", "discount", "bestSeller", "search"]);

  const categoryValues = category ? category.split(",").map(id => id.trim()) : [];
  const brandValues = brands ? brands.split(",") : [];
  const attributes = Object.entries(filteredAttributes).map(([id, values]) => ({
    id,
    values: values.split(",")
  }));
  const [getProducts, {
    data,
    loading,
    error
  }] = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__.useLazyQuery)(GET_PRODUCTS, {
    fetchPolicy: "network-only"
  });
  const {
    0: perPage,
    1: setPerPage
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(12);
  const {
    0: sortBy,
    1: setSortBy
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(query.sortBy ? query.sortBy : "default");
  const products = data && (data === null || data === void 0 ? void 0 : (_data$getProducts = data.getProducts) === null || _data$getProducts === void 0 ? void 0 : _data$getProducts.records);
  const totalPage = data ? parseInt((data === null || data === void 0 ? void 0 : (_data$getProducts2 = data.getProducts) === null || _data$getProducts2 === void 0 ? void 0 : _data$getProducts2.maxRecords) / perPage) + ((data === null || data === void 0 ? void 0 : (_data$getProducts3 = data.getProducts) === null || _data$getProducts3 === void 0 ? void 0 : _data$getProducts3.maxRecords) % perPage ? 1 : 0) : 0;
  const attributesWithNonEmptyValues = attributes.filter(attribute => attribute.values.some(value => value !== ""));
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    getProducts({
      variables: {
        input: {
          query: search,
          size: perPage,
          page: parseInt(page !== null && page !== void 0 ? page : 0),
          categories: categoryValues ? categoryValues : [],
          brands: brandValues,
          maxPrice: parseInt(query.max_price),
          minPrice: parseInt(query.min_price),
          attributes: attributesWithNonEmptyValues,
          parentCategory: query === null || query === void 0 ? void 0 : query.cat_id,
          discount: parseInt(discount),
          bestSeller: bestSeller === "true" ? true : false,
          priceHighToLow: sort_order && sort_order === "highToLow" ? true : false,
          priceLowToHigh: sort_order && sort_order === "lowToHigh" ? true : false
        }
      }
    });
  }, [query, perPage]);

  function sidebarToggle(e) {
    let body = document.querySelector("body");
    e.preventDefault();

    if (body.classList.contains("sidebar-opened")) {
      body.classList.remove("sidebar-opened");
    } else {
      body.classList.add("sidebar-opened");
    }
  }

  if (error) {
    return __jsx("div", null, "Something went wrong");
  }

  return __jsx("main", {
    className: "main"
  }, __jsx("nav", {
    "aria-label": "breadcrumb",
    className: "breadcrumb-nav mb-3"
  }, __jsx("div", {
    className: "container"
  }, __jsx("ol", {
    className: "breadcrumb"
  }, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    href: "/"
  }, __jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_10__/* .IoMdHome */ .QO$, {
    style: {
      fontSize: "16px"
    }
  }))), query.category ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    href: {
      pathname: router.pathname,
      query: {}
    },
    scroll: false
  }, "shop"))) : query.tag ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("li", {
    className: "breadcrumb-item"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    href: {
      pathname: router.pathname,
      query: {}
    },
    scroll: false
  }, "shop")), __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, `Product Tag - ${query.tag}`)) : __jsx("li", {
    className: "breadcrumb-item active",
    "aria-current": "page"
  }, __jsx(_components_common_ALink__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    className: "activeitem",
    href: "/shop"
  }, "Shop"))))), __jsx("div", {
    className: "container "
  }, __jsx("div", {
    style: {
      width: "228px",
      height: "26px",
      marginTop: "60px",
      marginBottom: "33px"
    }
  }, __jsx("p", {
    style: {
      fontWeight: "400px",
      fontSize: "13px",
      lineHeight: "26px"
    }
  }, data === null || data === void 0 ? void 0 : (_data$getProducts4 = data.getProducts) === null || _data$getProducts4 === void 0 ? void 0 : _data$getProducts4.maxRecords, " Search Results Found")), __jsx("div", {
    className: "row",
    style: {
      border: "1px solid #B9B9B9"
    }
  }, __jsx("div", {
    className: "col-lg-9 main-content",
    style: {
      padding: 0,
      borderLeft: "1px solid #B9B9B9"
    }
  }, __jsx("nav", {
    className: "toolbox sticky-header mobile-sticky",
    style: {
      margin: "0"
    }
  }, __jsx("div", {
    className: "toolbox-left"
  }, __jsx("a", {
    href: "#",
    className: "sidebar-toggle",
    onClick: e => sidebarToggle(e)
  }, __jsx("svg", {
    "data-name": "Layer 3",
    id: "Layer_3",
    viewBox: "0 0 32 32",
    xmlns: "http://www.w3.org/2000/svg"
  }, __jsx("line", {
    x1: "15",
    x2: "26",
    y1: "9",
    y2: "9",
    className: "cls-1"
  }), __jsx("line", {
    x1: "6",
    x2: "9",
    y1: "9",
    y2: "9",
    className: "cls-1"
  }), __jsx("line", {
    x1: "23",
    x2: "26",
    y1: "16",
    y2: "16",
    className: "cls-1"
  }), __jsx("line", {
    x1: "6",
    x2: "17",
    y1: "16",
    y2: "16",
    className: "cls-1"
  }), __jsx("line", {
    x1: "17",
    x2: "26",
    y1: "23",
    y2: "23",
    className: "cls-1"
  }), __jsx("line", {
    x1: "6",
    x2: "11",
    y1: "23",
    y2: "23",
    className: "cls-1"
  }), __jsx("path", {
    d: "M14.5,8.92A2.6,2.6,0,0,1,12,11.5,2.6,2.6,0,0,1,9.5,8.92a2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  }), __jsx("path", {
    d: "M22.5,15.92a2.5,2.5,0,1,1-5,0,2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  }), __jsx("path", {
    d: "M21,16a1,1,0,1,1-2,0,1,1,0,0,1,2,0Z",
    className: "cls-3"
  }), __jsx("path", {
    d: "M16.5,22.92A2.6,2.6,0,0,1,14,25.5a2.6,2.6,0,0,1-2.5-2.58,2.5,2.5,0,0,1,5,0Z",
    className: "cls-2"
  })), __jsx("span", null, "Filter")))), __jsx("div", null, __jsx(_components_partials_products_collection_product_grid__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
    products: products,
    loading: loading,
    perPage: perPage
  }))), __jsx(_components_partials_shop_sidebar_shop_sidebar_one__WEBPACK_IMPORTED_MODULE_6__/* .default */ .ZP, {
    category: category
  }))), loading || products && products.length ? __jsx("div", {
    className: "container"
  }, __jsx("nav", {
    className: "toolbox toolbox-pagination border-0"
  }, __jsx(_components_features_pagination__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
    totalPage: totalPage
  }))) : "", __jsx("div", {
    className: "mb-xl-4 mb-0"
  }));
}

/* harmony default export */ __webpack_exports__["default"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z)({
  ssr: true
})(Shop));

/***/ }),

/***/ 8074:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/client");;

/***/ }),

/***/ 7530:
/***/ (function(module) {

"use strict";
module.exports = require("@apollo/react-hooks");;

/***/ }),

/***/ 9875:
/***/ (function(module) {

"use strict";
module.exports = require("graphql-tag");;

/***/ }),

/***/ 5766:
/***/ (function(module) {

"use strict";
module.exports = require("next-apollo");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 5768:
/***/ (function(module) {

"use strict";
module.exports = require("rc-tree");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 7183:
/***/ (function(module) {

"use strict";
module.exports = require("react-countdown");;

/***/ }),

/***/ 4766:
/***/ (function(module) {

"use strict";
module.exports = require("react-input-range");;

/***/ }),

/***/ 9290:
/***/ (function(module) {

"use strict";
module.exports = require("react-lazy-load-image-component");;

/***/ }),

/***/ 79:
/***/ (function(module) {

"use strict";
module.exports = require("react-redux");;

/***/ }),

/***/ 3920:
/***/ (function(module) {

"use strict";
module.exports = require("react-slide-toggle");;

/***/ }),

/***/ 9058:
/***/ (function(module) {

"use strict";
module.exports = require("react-sticky-box");;

/***/ }),

/***/ 2034:
/***/ (function(module) {

"use strict";
module.exports = require("react-toastify");;

/***/ }),

/***/ 3643:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist");;

/***/ }),

/***/ 584:
/***/ (function(module) {

"use strict";
module.exports = require("redux-persist/lib/storage");;

/***/ }),

/***/ 5060:
/***/ (function(module) {

"use strict";
module.exports = require("redux-saga/effects");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [1664,9127,1649,6285,7164,6723,4733,2806,5708,4229,4011,2078,8816,101,9066], function() { return __webpack_exec__(6150); });
module.exports = __webpack_exports__;

})();