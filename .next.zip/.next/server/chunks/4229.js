exports.id = 4229;
exports.ids = [4229];
exports.modules = {

/***/ 4229:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ ProductCountdown; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_countdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7183);
/* harmony import */ var react_countdown__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_countdown__WEBPACK_IMPORTED_MODULE_1__);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ProductCountdown(props) {
  const {
    date = "2021-08-20",
    type = '',
    adClass = ''
  } = props;

  const renderer = ({
    days,
    hours,
    minutes,
    seconds
  }) => {
    return type === "1" ? __jsx("div", {
      className: "product-countdown-container deal-countdown position-static"
    }, __jsx("span", {
      className: "product-countdown-title"
    }, "offer ends in:"), __jsx("div", {
      className: "product-countdown countdown-compact"
    }, __jsx("span", {
      className: "countdown-section days"
    }, __jsx("span", {
      className: "countdown-amount"
    }, (0,react_countdown__WEBPACK_IMPORTED_MODULE_1__.zeroPad)(days)), __jsx("span", {
      className: "countdown-period"
    }, "DAYS")), __jsx("span", {
      className: "countdown-section hours"
    }, __jsx("span", {
      className: "countdown-amount"
    }, (0,react_countdown__WEBPACK_IMPORTED_MODULE_1__.zeroPad)(hours)), __jsx("span", {
      className: "countdown-period"
    }, "HOURS")), __jsx("span", {
      className: "countdown-section minutes"
    }, __jsx("span", {
      className: "countdown-amount"
    }, (0,react_countdown__WEBPACK_IMPORTED_MODULE_1__.zeroPad)(minutes)), __jsx("span", {
      className: "countdown-period"
    }, "MINUTES")), __jsx("span", {
      className: "countdown-section seconds"
    }, __jsx("span", {
      className: "countdown-amount"
    }, (0,react_countdown__WEBPACK_IMPORTED_MODULE_1__.zeroPad)(seconds)), __jsx("span", {
      className: "countdown-period"
    }, "SECONDS")))) : __jsx("div", {
      className: `product-countdown-container ${adClass}`
    }, __jsx("span", {
      className: "product-countdown-title"
    }, "offer ends in:"), __jsx("div", {
      className: "product-countdown countdown-compact"
    }, __jsx("span", {
      className: "countdown-section days"
    }, __jsx("span", {
      className: "countdown-amount mr-1"
    }, (0,react_countdown__WEBPACK_IMPORTED_MODULE_1__.zeroPad)(days), " "), __jsx("span", {
      className: "countdown-period mr-1"
    }, "DAYs,")), __jsx("span", {
      className: "countdown-section hours"
    }, __jsx("span", {
      className: "countdown-amount"
    }, (0,react_countdown__WEBPACK_IMPORTED_MODULE_1__.zeroPad)(hours), __jsx("span", {
      className: "mr-1 ml-1"
    }, ":"))), __jsx("span", {
      className: "countdown-section minutes"
    }, __jsx("span", {
      className: "countdown-amount"
    }, (0,react_countdown__WEBPACK_IMPORTED_MODULE_1__.zeroPad)(minutes), __jsx("span", {
      className: "mr-1 ml-1"
    }, ":"))), __jsx("span", {
      className: "countdown-section seconds"
    }, __jsx("span", {
      className: "countdown-amount"
    }, (0,react_countdown__WEBPACK_IMPORTED_MODULE_1__.zeroPad)(seconds)))));
  };

  return __jsx((react_countdown__WEBPACK_IMPORTED_MODULE_1___default()), {
    date: new Date(date),
    renderer: renderer
  });
}

/***/ })

};
;