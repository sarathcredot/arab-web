exports.id = 4733;
exports.ids = [4733];
exports.modules = {

/***/ 4733:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "tT": function() { return /* binding */ GET_PRODUCTS; },
/* harmony export */   "yG": function() { return /* binding */ GET_SPECIAL_PRODUCTS; },
/* harmony export */   "N4": function() { return /* binding */ GET_PRODUCT; },
/* harmony export */   "EP": function() { return /* binding */ GET_SHOP_SIDEBAR_DATA; },
/* harmony export */   "p$": function() { return /* binding */ GET_POSTS; },
/* harmony export */   "QI": function() { return /* binding */ GET_POST; },
/* harmony export */   "oG": function() { return /* binding */ GET_POST_SIDEBAR_DATA; }
/* harmony export */ });
/* unused harmony export GET_HOME_DATA */
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9875);
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_tag__WEBPACK_IMPORTED_MODULE_0__);

const DEMO = 36;
const PRODUCT_SIMPLE = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
  fragment ProductSimple on Product {
    name
    slug
    price
    ratings
    reviews
    is_hot
    is_new
    is_out_of_stock
    until
    stock
    pictures {
      url
      width
      height
    }
    small_pictures {
      url
      width
      height
    }
    categories {
      name
      slug
    }
    variants {
      price
      sale_price
    }
  }
`;
const PRODUCT_SMALL = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
  fragment ProductSmall on Product {
    id
    name
    slug
    price
    ratings
    pictures {
      url
      width
      height
    }
    small_pictures {
      url
      width
      height
    }
    variants {
      price
      sale_price
    }
  }
`;
const GET_PRODUCTS = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
    query products($search: String $colors: [String], $sizes: [String], $brands: [String], $min_price: Int, $max_price: Int, $category: String, $tag: String, $sortBy: String, $from: Int, $to: Int, $list: Boolean = false) {
        products(demo: ${DEMO}, search: $search, colors: $colors, sizes: $sizes, brands: $brands, min_price: $min_price, max_price: $max_price, category: $category, tag: $tag, sortBy: $sortBy, from: $from, to: $to ) {
            data {
                short_description @include(if: $list)
                ...ProductSimple
            }
            total
            categoryFamily {
                slug
                name
            }
        }
    }
    ${PRODUCT_SIMPLE}
`;
const GET_SPECIAL_PRODUCTS = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
    query specialProducts($featured: Boolean = false, $bestSelling: Boolean = false, $topRated: Boolean = false, $latest: Boolean = false, $count: Int) {
        specialProducts(demo: ${DEMO}, featured: $featured, bestSelling: $bestSelling, topRated: $topRated, latest: $latest, count: $count) {
            featured @include(if: $featured) {
                ...ProductSmall
            }
            bestSelling @include(if: $bestSelling) {
                ...ProductSmall
            }
            topRated @include(if: $topRated) {
                ...ProductSmall
            }
            latest @include(if: $latest) {
                ...ProductSmall
            }
        }
    }
    ${PRODUCT_SMALL}
`;
const GET_PRODUCT = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
    query product($slug: String!, $onlyData: Boolean = false) {
        product(demo: ${DEMO}, slug: $slug, onlyData: $onlyData) {
            data {
                id
                slug
                name
                price
                short_description
                until
                sku
                stock
                ratings
                reviews
                sale_count
                is_hot
                is_new
                is_sale
                is_out_of_stock
                stock
                pictures {
                    url
                    width
                    height
                }
                small_pictures {
                    url
                    width
                    height
                }
                large_pictures {
                    url
                    width
                    height
                }
                categories {
                    name
                    slug
                }
                tags {
                    name
                    slug
                }
                variants {
                    price
                    sale_price
                    color {
                        name
                        color
                        thumb {
                            url
                            width
                            height
                        }
                    }
                    size {
                        name
                        size
                        thumb {
                            url
                            width
                            height
                        }
                    }
                }
            }
            prev @skip(if: $onlyData) {
                slug
                name
                small_pictures {
                    url
                    width
                    height
                }
            }
            next @skip(if: $onlyData) {
                slug
                name
                small_pictures {
                    url
                    width
                    height
                }
            }
            related @skip(if: $onlyData) {
                ...ProductSimple
            }
        }
    }
    ${PRODUCT_SIMPLE}
`;
const GET_SHOP_SIDEBAR_DATA = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
query GetActiveChildCategories($input: GetActiveChildCategoriesInput!) {
  getActiveChildCategories(input: $input) {
    records {
      _id
      categoryName
    }
  }
}
`; // export const GET_SHOP_SIDEBAR_DATA = gql`
//     query shopSidebarData($featured: Boolean = false) {
//         shopSidebarData(demo: ${DEMO}, featured: $featured) {
//             categories {
//                 name
//                 slug
//                 parent
//                 count
//             }
//             featured @include(if: $featured) {
//                 slug
//                 name
//                 price
//                 ratings
//                 small_pictures {
//                     url
//                     width
//                     height
//                 }
//                 variants {
//                     price
//                 }
//             }
//         }
//     }
// `;

const GET_POSTS = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
    query posts($category: String, $from: Int, $to: Int) {
        posts(demo: ${DEMO}, category: $category, from: $from, to: $to ) {
            data {
                title
                slug
                date
                comments
                content
                picture {
                    url
                    width
                    height
                }
                video
            }
            total
        }
    }
`;
const GET_POST = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
    query post($slug: String!) {
        post(demo: ${DEMO}, slug: $slug) {
            data {
                title
                slug
                author
                date
                comments
                content
                type
                picture {
                    url
                    width
                    height
                }
                video
                categories {
                    name
                    slug
                }
            }
            related {
                title
                slug
                date
                comments
                content
                picture {
                    url
                    width
                    height
                }
                video
            }
        }
    }
`;
const GET_POST_SIDEBAR_DATA = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
    query postSidbarData {
        postSidebarData(demo: ${DEMO}) {
            categories {
                name
                slug
            }
            recent {
                title
                slug
                date
                picture {
                    url
                    width
                    height
                }
            }
        }
    }
`;
const GET_HOME_DATA = (graphql_tag__WEBPACK_IMPORTED_MODULE_0___default())`
    query indexData($productsCount: Int) {
        electronic: products(demo: ${DEMO}, category: "electronics", from: 0, to: $productsCount ) {
            data {
                ...ProductSimple
            }
        }
        giftAndGadgets: products(demo: ${DEMO}, category: "gifts-and-gadgets", from: 0, to: $productsCount ) {
            data {
                ...ProductSimple
            }
        }
        homeAndGarden: products(demo: ${DEMO}, category: "home-and-garden", from: 0, to: $productsCount ) {
            data {
                ...ProductSimple
            }
        }
        specialProducts(demo: ${DEMO}, featured: true, bestSelling: true, topRated: true, onSale: true, latest: true, count: $productsCount) {
             featured {
                ...ProductSimple
            }
            bestSelling {
                ...ProductSimple
            }
            topRated {
                ...ProductSimple
            }
            onSale {
                ...ProductSimple
            }
            latest {
                ...ProductSimple
            }
        }
        dealProducts(demo: ${DEMO}, count: 2) {
            ...ProductSimple
        }
    }
    ${PRODUCT_SIMPLE}
`;

/***/ })

};
;