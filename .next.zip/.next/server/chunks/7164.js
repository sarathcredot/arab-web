exports.id = 7164;
exports.ids = [7164];
exports.modules = {

/***/ 7164:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ apollo; }
});

// EXTERNAL MODULE: external "next-apollo"
var external_next_apollo_ = __webpack_require__(5766);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(8074);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
;// CONCATENATED MODULE: ./server/interceptor.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// Interceptors.ts

 // Request Interceptor

const requestInterceptor = new client_.ApolloLink((operation, forward) => {
  // Modify the operation before it is sent
  operation.setContext({
    headers: {
      Authorization: `Bearer ${localStorage.getItem('arabtoken')}`
    }
  }); // Call the next link in the chain

  return forward(operation);
}); // Response Interceptor

const responseInterceptor = new client_.ApolloLink((operation, forward) => {
  return new client_.Observable(observer => {
    const handleNext = result => {
      if (result.errors && result.errors.some(error => {
        var _error$extensions;

        return ((_error$extensions = error.extensions) === null || _error$extensions === void 0 ? void 0 : _error$extensions.code) === "UNAUTHORIZED";
      })) {
        console.log("Redirecting to login page", result); // localStorage.removeItem("arabtoken");
        // window.location.href="/pages/login";
      } else {
        observer.next(result);
      }
    };

    const handleComplete = () => {
      observer.complete();
    };

    const handleError = error => {
      console.error('GraphQL Error:', error);
      observer.error(error);
    }; // Check if forward is a function before calling it


    if (typeof forward === 'function') {
      const subscription = forward(operation).subscribe({
        next: handleNext,
        error: handleError,
        complete: handleComplete
      });
      return () => {
        subscription.unsubscribe();
      };
    } else {
      // If forward is not a function, just complete the observer
      handleComplete();
    }
  });
}); // export const responseInterceptor = new ApolloLink(
//   (operation, forward) => {
//     return new Observable((observer) => {
//       const subscription = forward(operation).subscribe({
//         next: (result) => {
//           console.log('GraphQL Result:', result?.errors);
//           // Check if there are errors in the result
//           if (result.errors && result.errors.some((error) => error.extensions?.code === "UNAUTHORIZED")) {
//             console.log("Redirecting to login page");
//             localStorage.removeItem("arabtoken");
//             window.location.href="/login";
//           } else {
//             observer.next(result);
//           }
//         },
//         error: (error) => {
//           // Handle errors globally
//           console.error('GraphQL Error:', error);
//           observer.error(error);
//         },
//         complete: () => {
//           observer.complete();
//         },
//       });
//       return () => {
//         subscription.unsubscribe();
//       };
//     });
//   }
// );

const getAuthToken = () => {
  const historyUrl = window.location.href; // localStorage.setItem("historyUrl",historyUrl );

  return localStorage.getItem("arabtoken") || null;
};

const authLink = new client_.ApolloLink((operation, forward) => {
  const token = getAuthToken();
  operation.setContext(({
    headers
  }) => ({
    headers: _objectSpread(_objectSpread({}, headers), {}, {
      Authorization: token ? `Bearer ${token}` : ""
    })
  }));
  return forward(operation);
});
;// CONCATENATED MODULE: ./server/apollo.js
 // import ApolloClient, { InMemoryCache } from 'apollo-boost';



const API_URI = "https://adserver.credot.dev/graphql";
const httpLink = new client_.HttpLink({
  uri: API_URI
});
const apolloClient = new client_.ApolloClient({
  // uri:API_URI,
  link: client_.ApolloLink.from([authLink, responseInterceptor, httpLink]),
  cache: new client_.InMemoryCache()
});
/* harmony default export */ var apollo = ((0,external_next_apollo_.withApollo)(apolloClient));

/***/ })

};
;