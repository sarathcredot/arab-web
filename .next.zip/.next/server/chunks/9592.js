exports.id = 9592;
exports.ids = [9592];
exports.modules = {

/***/ 9592:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony exports SHIPPING_ADDRESS, GET_ADDRESSES, UPDATE_SHIPPING */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7164);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8974);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1649);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









const SHIPPING_ADDRESS = _apollo_client__WEBPACK_IMPORTED_MODULE_3__.gql`mutation CreateUserShippingAddress($input: UserCreateShippingAddressInput!) {
    createUserShippingAddress(input: $input) {
      _id
    }
  }`;
const GET_ADDRESSES = _apollo_client__WEBPACK_IMPORTED_MODULE_3__.gql`query GetUserShippingAddress($input: GetUserShippingAddressInput!) {
    getUserShippingAddress(input: $input) {
      _id
      apartment
      city
      
      country
      email
      firstname
      houseNumber
      mobile
      postCode
      streetName
      suite
      unit
     
    }
  }`;
const UPDATE_SHIPPING = _apollo_client__WEBPACK_IMPORTED_MODULE_3__.gql`mutation EditUserShippingAddress($input: UserEditShippingAddressInput!) {
    editUserShippingAddress(input: $input) {
      _id
    }
  }`;

function Addresses({
  isEdit,
  addressId,
  onClose,
  isShipping,
  onIsShipping
}) {
  var _errors$firstname, _errors$houseNumber, _errors$streetName, _errors$city, _errors$postCode, _errors$city2;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
  const {
    data: getAddress,
    loading: getAddressLoading,
    error: getAddressError
  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_3__.useQuery)(GET_ADDRESSES, {
    variables: {
      input: {
        _id: addressId
      }
    }
  });
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: {
      errors
    },
    control
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useForm)({
    defaultValues: {
      firstname: "",
      country: "",
      streetName: "",
      houseNumber: "",
      city: "",
      postCode: "",
      apartment: "",
      email: "",
      mobile: ""
    }
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (isEdit) {
      var _getAddress$getUserSh, _getAddress$getUserSh2, _getAddress$getUserSh3, _getAddress$getUserSh4, _getAddress$getUserSh5, _getAddress$getUserSh6, _getAddress$getUserSh7, _getAddress$getUserSh8, _getAddress$getUserSh9;

      setValue("firstname", getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh === void 0 ? void 0 : _getAddress$getUserSh.firstname);
      setValue("country", getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh2 = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh2 === void 0 ? void 0 : _getAddress$getUserSh2.country);
      setValue("houseNumber", getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh3 = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh3 === void 0 ? void 0 : _getAddress$getUserSh3.houseNumber);
      setValue("streetName", getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh4 = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh4 === void 0 ? void 0 : _getAddress$getUserSh4.streetName);
      setValue("city", getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh5 = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh5 === void 0 ? void 0 : _getAddress$getUserSh5.city);
      setValue("postCode", getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh6 = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh6 === void 0 ? void 0 : _getAddress$getUserSh6.postCode);
      setValue("mobile", getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh7 = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh7 === void 0 ? void 0 : _getAddress$getUserSh7.mobile);
      setValue("email", getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh8 = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh8 === void 0 ? void 0 : _getAddress$getUserSh8.email);
      setValue("apartment", getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh9 = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh9 === void 0 ? void 0 : _getAddress$getUserSh9.apartment);
    }
  }, [isEdit, getAddress]);
  const [CreateUserShippingAddress] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_3__.useMutation)(SHIPPING_ADDRESS);
  const [EditUserShippingAddress] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_3__.useMutation)(UPDATE_SHIPPING);

  const onSubmit = async values => {
    event.preventDefault();

    try {
      if (isEdit) {
        var _getAddress$getUserSh10;

        const response = await EditUserShippingAddress({
          variables: {
            input: _objectSpread({
              _id: getAddress === null || getAddress === void 0 ? void 0 : (_getAddress$getUserSh10 = getAddress.getUserShippingAddress) === null || _getAddress$getUserSh10 === void 0 ? void 0 : _getAddress$getUserSh10._id
            }, values)
          }
        });

        if (response) {
          react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success(__jsx("div", {
            style: {
              padding: "10px"
            }
          }, "Shipping address updated"));
          onClose();
        }
      } else {
        const response = await CreateUserShippingAddress({
          variables: {
            input: _objectSpread({}, values)
          }
        });

        if (response) {
          var _localStorage, _response$data, _response$data$create;

          (_localStorage = localStorage) === null || _localStorage === void 0 ? void 0 : _localStorage.setItem("shippingId", response === null || response === void 0 ? void 0 : (_response$data = response.data) === null || _response$data === void 0 ? void 0 : (_response$data$create = _response$data.createUserShippingAddress) === null || _response$data$create === void 0 ? void 0 : _response$data$create._id);
          (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)(__jsx("div", {
            style: {
              padding: "10px"
            }
          }, "Shipping address added"));
          onClose();
          reset();
        }
      }
    } catch (error) {
      (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)(__jsx("div", {
        style: {
          padding: "10px"
        }
      }, error.message));
    }
  };

  const fieldRules = {
    city: {
      required: "City is required"
    },
    firstname: {
      required: "First Name is required"
    },
    houseNumber: {
      required: "HouseNumber is required"
    },
    mobile: {
      required: "Mobile is required"
    },
    postCode: {
      required: "postCode is required"
    },
    streetName: {
      required: "Street Name is required"
    },
    email: {
      pattern: {
        value: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        message: "Invalid email address"
      }
    }
  };
  return __jsx("div", null, __jsx("div", {
    className: "container checkout-container"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-12"
  }, __jsx("ul", {
    className: "checkout-steps"
  }, __jsx("li", null, __jsx("div", {
    className: "container custom-formspace" // style={{
    //     marginTop: "6rem",
    //     padding: "2px"
    // }}

  }, __jsx("h4", {
    className: "step-title",
    style: {
      display: "flex",
      alignItems: "center",
      gap: "10px"
    }
  }, __jsx("div", {
    onClick: () => onIsShipping(!isShipping),
    className: {
      "width": "40px",
      "height": "40px",
      "backgroundColor": "rgba(232, 232, 232, 0.29)",
      "borderRadius": "50%",
      "display": "flex",
      "justifyContent": "center",
      "alignItems": "center"
    }
  }, __jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_7__/* .IoMdArrowBack */ .UkU, {
    style: {
      fontSize: "20px"
    }
  })), "Shipping address")), __jsx("form", {
    onSubmit: handleSubmit(onSubmit),
    id: "checkout-form",
    style: {
      marginTop: "40px"
    }
  }, __jsx("div", {
    className: "form-group"
  }, __jsx("label", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      lineHeight: "20px"
    }
  }, "First name", " ", __jsx("ab", {
    className: "required",
    title: "required"
  }, "*")), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_1__.Controller, {
    control: control,
    name: "firstname",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    }),
    rules: fieldRules.firstname
  }), errors !== null && errors !== void 0 && errors.firstname ? __jsx("div", {
    style: {
      color: "red",
      fontWeight: "300"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$firstname = errors.firstname) === null || _errors$firstname === void 0 ? void 0 : _errors$firstname.message) : null), __jsx("div", {
    className: "form-group"
  }, __jsx("label", {
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      lineHeight: "20px"
    }
  }, "Country / Region ", " "), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_1__.Controller, {
    control: control,
    name: "country",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    })
  })), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Street address ", __jsx("span", {
    className: "required"
  }, "*")), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_1__.Controller, {
    control: control,
    name: "houseNumber",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      placeholder: "House number and street name",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    }),
    rules: fieldRules.houseNumber
  }), errors !== null && errors !== void 0 && errors.houseNumber ? __jsx("div", {
    style: {
      color: "red",
      fontWeight: "300"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$houseNumber = errors.houseNumber) === null || _errors$houseNumber === void 0 ? void 0 : _errors$houseNumber.message) : null, __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_1__.Controller, {
    control: control,
    name: "streetName",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      placeholder: "Apartment, suite, unit, etc. (optional)",
      value: value,
      onChange: onChange
    }),
    rules: fieldRules.streetName
  }), errors !== null && errors !== void 0 && errors.streetName ? __jsx("div", {
    style: {
      color: "red",
      fontWeight: "300"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$streetName = errors.streetName) === null || _errors$streetName === void 0 ? void 0 : _errors$streetName.message) : null), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Twon/City ", __jsx("span", {
    className: "required"
  }, "*")), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_1__.Controller, {
    control: control,
    name: "city",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      placeholder: "Abu Dhabi",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    }),
    rules: fieldRules.city
  }), errors !== null && errors !== void 0 && errors.city ? __jsx("div", {
    style: {
      color: "red",
      fontWeight: "300"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$city = errors.city) === null || _errors$city === void 0 ? void 0 : _errors$city.message) : null), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Pincode/Zip ", __jsx("span", {
    className: "required"
  }, "*")), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_1__.Controller, {
    control: control,
    name: "postCode",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "number",
      className: "form-control",
      placeholder: "6730016",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    }),
    rules: fieldRules.postCode
  }), errors !== null && errors !== void 0 && errors.postCode ? __jsx("div", {
    style: {
      color: "red",
      fontWeight: "300"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$postCode = errors.postCode) === null || _errors$postCode === void 0 ? void 0 : _errors$postCode.message) : null), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Phone", __jsx("span", {
    className: "required"
  }, "*")), __jsx("div", {
    className: "input-group",
    style: {
      marginTop: "10px"
    }
  }, __jsx("div", {
    className: "input-group-prepend"
  }, __jsx("span", {
    className: "input-group-text",
    style: {
      padding: "10px"
    }
  }, __jsx("img", {
    src: "images\\brands\\flag1.svg",
    alt: "Flag",
    width: "24",
    height: "16"
  }), "+971")), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_1__.Controller, {
    control: control,
    name: "mobile",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "tel",
      className: "form-control",
      placeholder: "Enter your phone number",
      value: value,
      onChange: onChange
    }),
    rules: fieldRules.mobile
  })), errors !== null && errors !== void 0 && errors.mobile ? __jsx("div", {
    style: {
      color: "red",
      fontWeight: "300"
    }
  }, errors === null || errors === void 0 ? void 0 : (_errors$city2 = errors.city) === null || _errors$city2 === void 0 ? void 0 : _errors$city2.mobile) : null), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Email"), __jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_1__.Controller, {
    control: control,
    name: "email",
    render: ({
      field: {
        onChange,
        value
      }
    }) => __jsx("input", {
      type: "text",
      className: "form-control",
      value: value,
      onChange: onChange,
      style: {
        marginTop: "10px"
      }
    })
  })), __jsx("div", {
    className: "container",
    style: {
      display: "flex",
      justifyContent: "flex-end"
    }
  }, __jsx("div", {
    className: "mt-3"
  }, __jsx("button", {
    type: "submit",
    className: "btn btn-dark mr-0"
  }, "Save changes"))))))))));
}

/* harmony default export */ __webpack_exports__["ZP"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)({
  ssr: true
})(Addresses));

/***/ })

};
;