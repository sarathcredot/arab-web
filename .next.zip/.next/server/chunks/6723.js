exports.id = 6723;
exports.ids = [6723];
exports.modules = {

/***/ 6723:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nw": function() { return /* binding */ actions; }
/* harmony export */ });
/* unused harmony export actionTypes */
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3643);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(584);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1__);


const actionTypes = {
  ShowQuick: "SHOW_QUICKVIEW",
  HideQuick: "HIDE_QUICKVIEW",
  ShowVideo: "SHOW_VIDEO",
  HideVideo: "HIDE_VIDEO",
  RefreshStore: "REFRESH_STORE"
};
const initialState = {
  single: null,
  quickShow: false,
  videoShow: false
};

const modalReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.ShowQuick:
      return {
        single: action.payload.slug,
        quickShow: true
      };

    case actionTypes.HideQuick:
      return {
        quickShow: false,
        single: null
      };

    case actionTypes.ShowVideo:
      return {
        videoShow: true
      };

    case actionTypes.HideVideo:
      return {
        videoShow: false
      };

    case actionTypes.RefreshStore:
      return initialState;

    default:
      return state;
  }
};

const actions = {
  showQuickView: slug => ({
    type: actionTypes.ShowQuick,
    payload: {
      slug
    }
  }),
  hideQuickView: () => ({
    type: actionTypes.HideQuick
  }),
  showVideo: () => ({
    type: actionTypes.ShowVideo
  }),
  hideVideo: () => ({
    type: actionTypes.HideVideo
  })
};
const persistConfig = {
  keyPrefix: "porto-",
  key: "modal",
  storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1___default())
};
/* harmony default export */ __webpack_exports__["ZP"] = ((0,redux_persist__WEBPACK_IMPORTED_MODULE_0__.persistReducer)(persistConfig, modalReducer));

/***/ })

};
;