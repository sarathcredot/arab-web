exports.id = 980;
exports.ids = [980];
exports.modules = {

/***/ 980:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony exports LEVEL_CATEGORY, GET_CHILD_CATEGORIES, BRAND_LISTING, VARIENT */
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7164);
/* harmony import */ var _server_queries__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4733);
/* harmony import */ var _ALink__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8974);
/* harmony import */ var _features_product_countdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4229);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4138);
/* harmony import */ var _features_products_product_three__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9915);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2821);
/* harmony import */ var _utils_data_menu__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9955);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_11__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // Import Apollo Server


 // Import Custom Component





 // Import Utils




const LEVEL_CATEGORY = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`
  query Query {
    getActiveCategoryTree {
      records {
        _id
        categoryName
        categoryImage {
          fileType
          fileURL
          originalName
        }
        isLeaf
      } 
    }
  }
`;
const GET_CHILD_CATEGORIES = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`
  query GetActiveChildCategories($input: GetActiveChildCategoriesInput!) {
    getActiveChildCategories(input: $input) {
      records {
        _id
        categoryName
        isLeaf
      }
    }
  }
`;
const BRAND_LISTING = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`query GetBrandDetailsWithCategory($input: BrandsDetailsWithCategoryIdInput!) {
  getBrandDetailsWithCategory(input: $input) {
    message
    records {
      _id
      brandName
      logo {
        fileType
        originalName
        fileURL
      }
      isPopular
      priority
    }
  }
}`;
const VARIENT = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`query GetVariants($input: VariantsInput!) {
  getVariants(input: $input) {
    variants {
      _id
      attributeDescription
      attributeId
      attributeName
      attributeValue
      attributeValueId
      colorCode
    }
  }
}`;

function MainMenu({
  router
}) {
  var _data$getActiveCatego, _level2Data$getActive, _level3Data$getActive, _level4Data$getActive, _level5Data$getActive, _level6Data$getActive, _level7Data$getActive;

  const {
    data,
    loading,
    error
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_3__.useQuery)(LEVEL_CATEGORY); // console.log(data);

  const {
    data: varientData
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_3__.useQuery)(VARIENT, {
    variables: {
      input: {
        _id: "65b76b1448ffd4fbf7782e19"
      }
    }
  }); // console.log(varientData);

  const {
    0: parentcategory,
    1: setParentcategory
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
    cat1: "",
    cat2: "",
    cat3: "",
    cat4: "",
    cat5: "",
    cat6: "",
    cat7: ""
  });
  const {
    0: isLeaf,
    1: setIsLeaf
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: brands,
    1: setBrands
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: brandFetchToggle,
    1: setBrandFetchToggle
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: selectedcategory,
    1: setSelectedCategory
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: selectedBrand,
    1: setSelectedBrand
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const pathname = router.pathname; // const router = useRouter();
  // const { data, loading, error } = useQuery(GET_HOME_DATA, {
  //   variables: { productsCount: 10, postsCount: 6 },
  // });
  // const featured = data && data.specialProducts.featured;
  // if (error) {
  //   return <div>{error.message}</div>;
  // }

  function isOtherPage() {
    return _utils_data_menu__WEBPACK_IMPORTED_MODULE_10__/* .mainMenu.other.find */ .c.other.find(variation => variation.url === pathname);
  }

  function activeHandler(e) {
    e.preventDefault();
    document.querySelector("body").classList.toggle("mmenu-depart-active");
    e.currentTarget.querySelector(".menu-depart").classList.toggle("opened");
  }

  const movebackward = () => {
    const array = Object.entries(parentcategory); // console.log(array);

    let index = array === null || array === void 0 ? void 0 : array.findIndex(item => item[1] === "");

    if (index === -1) {
      index = array.length;
    }

    const element = array[index - 1][0]; // console.log(element);

    setParentcategory(e => _objectSpread(_objectSpread({}, e), {}, {
      [element]: ""
    }));
  };

  const {
    0: lev2catid,
    1: setLev2id
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const [catLevel2, {
    loading: level2loading,
    error: level2error,
    data: level2Data
  }] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useLazyQuery)(GET_CHILD_CATEGORIES, {
    fetchPolicy: "network-only"
  });
  const [catLevel3, {
    loading: level3loading,
    error: level3error,
    data: level3Data
  }] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useLazyQuery)(GET_CHILD_CATEGORIES, {
    fetchPolicy: "network-only"
  });
  const [catLevel4, {
    loading: level4loading,
    error: level4error,
    data: level4Data
  }] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useLazyQuery)(GET_CHILD_CATEGORIES, {
    fetchPolicy: "network-only"
  });
  const [catLevel5, {
    loading: level5loading,
    error: level5error,
    data: level5Data
  }] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useLazyQuery)(GET_CHILD_CATEGORIES, {
    fetchPolicy: "network-only"
  });
  const [catLevel6, {
    loading: level6loading,
    error: level6error,
    data: level6Data
  }] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useLazyQuery)(GET_CHILD_CATEGORIES, {
    fetchPolicy: "network-only"
  });
  const [catLevel7, {
    loading: level7loading,
    error: level7error,
    data: level7Data
  }] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useLazyQuery)(GET_CHILD_CATEGORIES, {
    fetchPolicy: "network-only"
  });
  const [brandlist, {
    loading: brandloading,
    error: branderror,
    data: brandData
  }] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useLazyQuery)(BRAND_LISTING, {
    fetchPolicy: "network-only"
  });

  const handleLevel2category = async id => {
    // console.log(id);
    try {
      catLevel2({
        variables: {
          input: {
            parent: id
          }
        }
      }); // console.log(level2Data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleLevel3category = async id => {
    try {
      catLevel3({
        variables: {
          input: {
            parent: id
          }
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleLevel4category = async id => {
    try {
      catLevel4({
        variables: {
          input: {
            parent: id
          }
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleLevel5category = async id => {
    try {
      catLevel5({
        variables: {
          input: {
            parent: id
          }
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleLevel6category = async id => {
    try {
      catLevel6({
        variables: {
          input: {
            parent: id
          }
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleLevel7category = async id => {
    try {
      catLevel7({
        variables: {
          input: {
            parent: id
          }
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleBrandList = async id => {
    try {
      await brandlist({
        variables: {
          input: {
            categoryId: id
          }
        }
      });
      setBrandFetchToggle(!brandFetchToggle);
    } catch (error) {
      console.error(error);
    }
  };

  const mainNav = (data === null || data === void 0 ? void 0 : (_data$getActiveCatego = data.getActiveCategoryTree) === null || _data$getActiveCatego === void 0 ? void 0 : _data$getActiveCatego.records) || [];
  const child1 = level2Data === null || level2Data === void 0 ? void 0 : (_level2Data$getActive = level2Data.getActiveChildCategories) === null || _level2Data$getActive === void 0 ? void 0 : _level2Data$getActive.records;
  const child2 = level3Data === null || level3Data === void 0 ? void 0 : (_level3Data$getActive = level3Data.getActiveChildCategories) === null || _level3Data$getActive === void 0 ? void 0 : _level3Data$getActive.records;
  const child3 = level4Data === null || level4Data === void 0 ? void 0 : (_level4Data$getActive = level4Data.getActiveChildCategories) === null || _level4Data$getActive === void 0 ? void 0 : _level4Data$getActive.records;
  const child4 = level5Data === null || level5Data === void 0 ? void 0 : (_level5Data$getActive = level5Data.getActiveChildCategories) === null || _level5Data$getActive === void 0 ? void 0 : _level5Data$getActive.records;
  const child5 = level6Data === null || level6Data === void 0 ? void 0 : (_level6Data$getActive = level6Data.getActiveChildCategories) === null || _level6Data$getActive === void 0 ? void 0 : _level6Data$getActive.records;
  const child6 = level7Data === null || level7Data === void 0 ? void 0 : (_level7Data$getActive = level7Data.getActiveChildCategories) === null || _level7Data$getActive === void 0 ? void 0 : _level7Data$getActive.records; // console.log(child1, 'child1');
  // console.log(child2, 'child2');
  // console.log(child2?.length, 'child2 length');

  const varient = [{
    key: "ddr1",
    label: "DDR 1"
  }, {
    key: "ddr2",
    label: "DDR 2"
  }, {
    key: "ddr3",
    label: "DDR 3"
  }, {
    key: "ddr4",
    label: "DDR 4"
  }];
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (brandData) {
      var _brandData$getBrandDe;

      setBrands(brandData === null || brandData === void 0 ? void 0 : (_brandData$getBrandDe = brandData.getBrandDetailsWithCategory) === null || _brandData$getBrandDe === void 0 ? void 0 : _brandData$getBrandDe.records);
    }
  }, [brandFetchToggle]);
  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("nav", {
    className: `w-100 skeleton-body skel-shop-products ${// !loading ? "loaded" : ""
     false ? 0 : ""}`
  }, __jsx("ul", {
    className: "custom__menu w-100"
  }, mainNav === null || mainNav === void 0 ? void 0 : mainNav.map(item => {
    var _item$categoryImage;

    return __jsx("li", {
      key: item._id,
      className: `custom__menu__item px-2 ${item._id === parentcategory.cat1 ? "activate" : ""}`,
      onClick: () => {
        setSelectedCategory(item === null || item === void 0 ? void 0 : item._id);
        setParentcategory(e => ({
          cat1: item._id,
          cat2: "",
          cat3: "",
          cat4: "",
          cat5: ""
        }));
        setIsLeaf(item.isLeaf ? item === null || item === void 0 ? void 0 : item._id : "");

        if (item.isLeaf) {
          handleBrandList(item === null || item === void 0 ? void 0 : item._id);
        } else {
          handleLevel2category(item === null || item === void 0 ? void 0 : item._id);
          setBrands([]);
        }
      }
    }, __jsx("div", {
      className: "custom__menu__item-image"
    }, __jsx("img", {
      src: (_item$categoryImage = item.categoryImage) === null || _item$categoryImage === void 0 ? void 0 : _item$categoryImage.fileURL,
      alt: item.categoryName
    })), __jsx("p", {
      className: "custom__menu__item-label"
    }, item.categoryName.charAt(0).toUpperCase() + item.categoryName.slice(1)));
  })), __jsx("ul", {
    className: "custom__mobilemenu w-100"
  }, mainNav === null || mainNav === void 0 ? void 0 : mainNav.map(item => {
    var _item$categoryImage2;

    return __jsx("li", {
      className: `custom__mobile__item px-2 ${item._id === parentcategory.cat1 ? "activate" : ""}`,
      onClick: () => {
        setIsLeaf(item.isLeaf ? item === null || item === void 0 ? void 0 : item._id : "");
        setSelectedCategory(item === null || item === void 0 ? void 0 : item._id);
        setParentcategory(e => ({
          cat1: item._id,
          cat2: "",
          cat3: "",
          cat4: "",
          cat5: ""
        }));

        if (item.isLeaf) {
          handleBrandList(item === null || item === void 0 ? void 0 : item._id);
        } else {
          handleLevel2category(item === null || item === void 0 ? void 0 : item._id);
          setBrands([]);
        }
      }
    }, __jsx("div", {
      className: "custom__mobilemenu__item-circle"
    }, __jsx("span", {
      className: "custom__mobilemenu__item-image"
    }, __jsx("img", {
      src: (_item$categoryImage2 = item.categoryImage) === null || _item$categoryImage2 === void 0 ? void 0 : _item$categoryImage2.fileURL,
      alt: item.categoryName,
      style: {
        width: "30px",
        height: "30px"
      }
    }))), __jsx("p", {
      style: {
        textAlign: "center"
      }
    }, item.categoryName.charAt(0).toUpperCase() + item.categoryName.slice(1)));
  })), parentcategory !== null && parentcategory !== void 0 && parentcategory.cat2 ? __jsx(BackArrow, {
    movebackward: movebackward
  }) : null, parentcategory !== null && parentcategory !== void 0 && parentcategory.cat1 && (parentcategory === null || parentcategory === void 0 ? void 0 : parentcategory.cat1) !== isLeaf ? __jsx("ul", {
    className: `custom__menufirstchild w-100 ${parentcategory.cat2 ? "active_container_hidden" : ""}`
  }, child1 === null || child1 === void 0 ? void 0 : child1.map(item => __jsx("li", {
    key: item._id,
    className: `custom__menufirstchild__item px-2 ${item._id === parentcategory.cat2 || (item === null || item === void 0 ? void 0 : item._id) === selectedcategory ? "customactive" : ""}`,
    onClick: () => {
      setIsLeaf(item.isLeaf ? item === null || item === void 0 ? void 0 : item._id : "");
      setSelectedCategory(item === null || item === void 0 ? void 0 : item._id);
      setParentcategory(e => _objectSpread(_objectSpread({}, e), {}, {
        cat2: item._id,
        cat3: "",
        cat4: "",
        cat5: "",
        cat6: "",
        cat7: ""
      }));

      if (item.isLeaf) {
        handleBrandList(item === null || item === void 0 ? void 0 : item._id);
      } else {
        setBrands([]);
        handleLevel3category(item === null || item === void 0 ? void 0 : item._id);
      }
    }
  }, __jsx("p", {
    className: "custom__menufirstchild__item-label"
  }, item.categoryName.charAt(0).toUpperCase() + item.categoryName.slice(1)))), !!!(child1 !== null && child1 !== void 0 && child1.length) && __jsx("p", {
    className: "custom__menufirstchild__item px-2"
  }, "No Sub Category")) : null, parentcategory !== null && parentcategory !== void 0 && parentcategory.cat2 && (parentcategory === null || parentcategory === void 0 ? void 0 : parentcategory.cat2) !== isLeaf ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("p", {
    className: `customheading ${parentcategory.cat3 ? "active_container_hidden" : ""}`
  }, "SELECT SUB CATEGORY"), __jsx("ul", {
    className: `custom__menusecondchild w-100 ${parentcategory !== null && parentcategory !== void 0 && parentcategory.cat3 ? "active_container_hidden" : ""}`
  }, child2 === null || child2 === void 0 ? void 0 : child2.map(item => __jsx("li", {
    key: item._id,
    className: `custom__menusecondchild__item px-4 ${item._id === parentcategory.cat3 ? "customactive" : ""}`,
    onClick: () => {
      setSelectedCategory(item === null || item === void 0 ? void 0 : item._id);
      setIsLeaf(item.isLeaf ? item === null || item === void 0 ? void 0 : item._id : "");
      console.log(item.isLeaf, 'isLeaf');
      setParentcategory(e => _objectSpread(_objectSpread({}, e), {}, {
        cat3: item._id,
        cat4: "",
        cat5: "",
        cat6: "",
        cat7: ""
      }));

      if (item.isLeaf) {
        handleBrandList(item === null || item === void 0 ? void 0 : item._id);
      } else {
        setBrands([]);
        handleLevel4category(item === null || item === void 0 ? void 0 : item._id);
      }
    }
  }, __jsx("p", {
    className: "custom__menusecondchild__item-label"
  }, (item === null || item === void 0 ? void 0 : item.categoryName.charAt(0).toUpperCase()) + item.categoryName.slice(1)))), !!!(child2 !== null && child2 !== void 0 && child2.length) && __jsx("p", {
    className: "custom__menufirstchild__item px-2"
  }, "No Sub Category"))) : null, parentcategory !== null && parentcategory !== void 0 && parentcategory.cat3 && (parentcategory === null || parentcategory === void 0 ? void 0 : parentcategory.cat3) !== isLeaf ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("p", {
    className: `customheading ${parentcategory.cat4 ? "active_container_hidden" : ""}`
  }, "SELECT SUB CATEGORY"), __jsx("ul", {
    className: `custom__menusecondchild w-100 ${parentcategory !== null && parentcategory !== void 0 && parentcategory.cat4 ? "active_container_hidden" : ""}`
  }, child3 === null || child3 === void 0 ? void 0 : child3.map(item => __jsx("li", {
    key: item._id,
    className: `custom__menusecondchild__item px-4 ${item._id === parentcategory.cat4 || (item === null || item === void 0 ? void 0 : item._id) === selectedcategory ? "customactive" : ""}`,
    onClick: () => {
      setSelectedCategory(item === null || item === void 0 ? void 0 : item._id);
      setIsLeaf(item.isLeaf ? item === null || item === void 0 ? void 0 : item._id : "");
      setParentcategory(e => _objectSpread(_objectSpread({}, e), {}, {
        cat4: item._id,
        cat5: "",
        cat6: "",
        cat7: ""
      }));

      if (item.isLeaf) {
        handleBrandList(item === null || item === void 0 ? void 0 : item._id);
      } else {
        setBrands([]);
        handleLevel5category(item === null || item === void 0 ? void 0 : item._id);
      }
    }
  }, __jsx("p", {
    className: "custom__menusecondchild__item-label"
  }, (item === null || item === void 0 ? void 0 : item.categoryName.charAt(0).toUpperCase()) + item.categoryName.slice(1)))), !!!(child3 !== null && child3 !== void 0 && child3.length) && __jsx("p", {
    className: "custom__menufirstchild__item px-2"
  }, "No Sub Category"))) : null, parentcategory !== null && parentcategory !== void 0 && parentcategory.cat4 && (parentcategory === null || parentcategory === void 0 ? void 0 : parentcategory.cat4) !== isLeaf ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("p", {
    className: `customheading ${parentcategory.cat5 ? "active_container_hidden" : ""}`
  }, "SELECT SUB CATEGORY"), __jsx("ul", {
    className: `custom__menusecondchild w-100 ${parentcategory !== null && parentcategory !== void 0 && parentcategory.cat5 ? "active_container_hidden" : ""}`
  }, child4 === null || child4 === void 0 ? void 0 : child4.map(item => __jsx("li", {
    key: item._id,
    className: `custom__menusecondchild__item px-4 ${item._id === parentcategory.cat5 || (item === null || item === void 0 ? void 0 : item._id) === selectedcategory ? "customactive" : ""}`,
    onClick: () => {
      setSelectedCategory(item === null || item === void 0 ? void 0 : item._id);
      setIsLeaf(item.isLeaf ? item === null || item === void 0 ? void 0 : item._id : "");
      setParentcategory(e => _objectSpread(_objectSpread({}, e), {}, {
        cat5: item._id,
        cat6: "",
        cat7: ""
      }));

      if (item.isLeaf) {
        handleBrandList(item === null || item === void 0 ? void 0 : item._id);
      } else {
        setBrands([]);
        handleLevel6category(item === null || item === void 0 ? void 0 : item._id);
      }
    }
  }, __jsx("p", {
    className: "custom__menusecondchild__item-label"
  }, (item === null || item === void 0 ? void 0 : item.categoryName.charAt(0).toUpperCase()) + item.categoryName.slice(1)))), !!!(child4 !== null && child4 !== void 0 && child4.length) && __jsx("p", {
    className: "custom__menufirstchild__item px-2"
  }, "No Sub Category"))) : null, parentcategory !== null && parentcategory !== void 0 && parentcategory.cat5 && (parentcategory === null || parentcategory === void 0 ? void 0 : parentcategory.cat5) !== isLeaf ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("p", {
    className: `customheading ${parentcategory.cat6 ? "active_container_hidden" : ""}`
  }, "SELECT SUB CATEGORY"), __jsx("ul", {
    className: `custom__menusecondchild w-100 ${parentcategory !== null && parentcategory !== void 0 && parentcategory.cat6 ? "active_container_hidden" : ""}`
  }, child5 === null || child5 === void 0 ? void 0 : child5.map(item => __jsx("li", {
    key: item._id,
    className: `custom__menusecondchild__item px-4 ${item._id === parentcategory.cat6 || (item === null || item === void 0 ? void 0 : item._id) === selectedcategory ? "customactive" : ""}`,
    onClick: () => {
      setSelectedCategory(item === null || item === void 0 ? void 0 : item._id);
      setParentcategory(e => _objectSpread(_objectSpread({}, e), {}, {
        cat6: item._id,
        cat7: ""
      }));
      setIsLeaf(item.isLeaf ? item === null || item === void 0 ? void 0 : item._id : "");

      if (item.isLeaf) {
        handleBrandList(item === null || item === void 0 ? void 0 : item._id);
      } else {
        setBrands([]);
        handleLevel7category(item === null || item === void 0 ? void 0 : item._id);
      }
    }
  }, __jsx("p", {
    className: "custom__menusecondchild__item-label"
  }, (item === null || item === void 0 ? void 0 : item.categoryName.charAt(0).toUpperCase()) + item.categoryName.slice(1)))), !!!(child5 !== null && child5 !== void 0 && child5.length) && __jsx("p", {
    className: "custom__menufirstchild__item px-2"
  }, "No Sub Category"))) : null, parentcategory !== null && parentcategory !== void 0 && parentcategory.cat6 && (parentcategory === null || parentcategory === void 0 ? void 0 : parentcategory.cat6) !== isLeaf ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("p", {
    className: `customheading ${parentcategory.cat7 ? "active_container_hidden" : ""}`
  }, "SELECT SUB CATEGORY"), __jsx("ul", {
    className: `custom__menusecondchild w-100 ${parentcategory !== null && parentcategory !== void 0 && parentcategory.cat7 ? "active_container_hidden" : ""}`
  }, child6 === null || child6 === void 0 ? void 0 : child6.map(item => __jsx("li", {
    key: item._id,
    className: `custom__menusecondchild__item px-4 ${item._id === parentcategory.cat7 || (item === null || item === void 0 ? void 0 : item._id) === selectedcategory ? "customactive" : ""}`,
    onClick: () => {
      setSelectedCategory(item === null || item === void 0 ? void 0 : item._id);
      setIsLeaf(item.isLeaf ? item === null || item === void 0 ? void 0 : item._id : "");
      setParentcategory(e => _objectSpread(_objectSpread({}, e), {}, {
        cat7: item._id
      }));

      if (item.isLeaf) {
        handleBrandList(item === null || item === void 0 ? void 0 : item._id);
      } else {
        setBrands([]);
      }
    }
  }, __jsx("p", {
    className: "custom__menusecondchild__item-label"
  }, (item === null || item === void 0 ? void 0 : item.categoryName.charAt(0).toUpperCase()) + item.categoryName.slice(1)))), !!!(child6 !== null && child6 !== void 0 && child6.length) && __jsx("p", {
    className: "custom__menufirstchild__item px-2"
  }, "No Sub Category"))) : null, isLeaf ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("p", {
    className: "pb-4 customheading"
  }, "SELECT BRAND"), __jsx("ul", {
    className: "custom__menulastchild w-100"
  }, brands === null || brands === void 0 ? void 0 : brands.map(item => {
    var _item$logo;

    return __jsx("li", {
      key: item._id,
      className: `custom__menulastchild__item px-4 ${item._id === selectedBrand ? "customactive" : ""}`,
      onClick: () => {
        setSelectedBrand(item === null || item === void 0 ? void 0 : item._id);
        router.push(`/shop?cat_id=${selectedcategory}&brands=${item === null || item === void 0 ? void 0 : item._id}`);
      }
    }, __jsx("span", {
      className: "custom__menulastchild__item-image"
    }, __jsx("img", {
      src: item === null || item === void 0 ? void 0 : (_item$logo = item.logo) === null || _item$logo === void 0 ? void 0 : _item$logo.fileURL,
      alt: item === null || item === void 0 ? void 0 : item.brandName
    })), __jsx("p", {
      className: "custom__menulastchild__item-label"
    }, item === null || item === void 0 ? void 0 : item.brandName));
  }), !!!(brands !== null && brands !== void 0 && brands.length) && __jsx("p", {
    className: "custom__menufirstchild__item px-2"
  }, "No Brand Available"))) : null));
}

const BackArrow = ({
  movebackward
}) => {
  return __jsx("div", {
    className: "mobile_backward",
    onClick: movebackward
  }, __jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_12__/* .AiOutlineArrowLeft */ .kyg, null));
};

/* harmony default export */ __webpack_exports__["ZP"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)({
  ssr: true
})((0,next_router__WEBPACK_IMPORTED_MODULE_1__.withRouter)(MainMenu)));

/***/ }),

/***/ 9955:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": function() { return /* binding */ mainMenu; }
/* harmony export */ });
const mainMenu = {
  "shop": {
    "variation1": [{
      "title": "Fullwidth Banner",
      "url": "/shop"
    }, {
      "title": "Boxed Slider Banner",
      "url": "/shop/boxed-slider"
    }, {
      "title": "Boxed Image Banner",
      "url": "/shop/boxed-image"
    }, {
      "title": "Left Sidebar",
      "url": "/shop"
    }, {
      "title": "Right Sidebar",
      "url": "/shop/right-sidebar",
      "hot": true
    }, {
      "title": "Off-Canvas Filter",
      "url": "/shop/off-canvas"
    }, {
      "title": "Horizontal Filter1",
      "url": "/shop/horizontal-filter-1"
    }, {
      "title": "Horizontal Filter2",
      "url": "/shop/horizontal-filter-2"
    }],
    "variation2": [{
      "title": "List Types",
      "url": "/shop/list"
    }, {
      "title": "Ajax Infinite Scroll",
      "url": "/shop/infinite-scroll"
    }, {
      "title": "3 Columns Products",
      "url": "/shop/3cols",
      "new": true
    }, {
      "title": "4 Columns Products",
      "url": "/shop/4cols"
    }, {
      "title": "5 Columns Products",
      "url": "/shop/5cols"
    }, {
      "title": "6 Columns Products",
      "url": "/shop/6cols"
    }, {
      "title": "7 Columns Products",
      "url": "/shop/7cols"
    }, {
      "title": "8 Columns Products",
      "url": "/shop/8cols"
    }]
  },
  "product": {
    "pages": [{
      "title": "Simple Product",
      "url": "/product/default/beats-solo-hd-drenched-one"
    }, {
      "title": "Variable Product",
      "url": "/product/default/brown-arm-chair"
    }, {
      "title": "Sale Product",
      "url": "/product/default/drone-pro-one"
    }, {
      "title": "Feature & On Sale",
      "url": "/product/default/pt-speaker"
    }, {
      "title": "With Custom Tab",
      "url": "/product/custom-tab/brown-arm-chair"
    }, {
      "title": "With Left Sidebar",
      "url": "/product/left-sidebar/brown-arm-chair"
    }, {
      "title": "With Right Sidebar",
      "url": "/product/right-sidebar/brown-arm-chair"
    }, {
      "title": "Add Cart Sticky",
      "url": "/product/sticky-cart/beats-solo-hd-drenched-one",
      "hot": true
    }],
    "layout": [{
      "title": "Extended Layout",
      "url": "/product/extended/brown-arm-chair",
      "new": true
    }, {
      "title": "Grid Image",
      "url": "/product/grid/brown-arm-chair"
    }, {
      "title": "Full Width Layout",
      "url": "/product/full-width/brown-arm-chair"
    }, {
      "title": "Sticky Info",
      "url": "/product/sticky-info/brown-arm-chair"
    }, {
      "title": "Left & Right Sticky",
      "url": "/product/sticky-both/brown-arm-chair"
    }, {
      "title": "Transparent Image",
      "url": "/product/transparent/brown-arm-chair"
    }, {
      "title": "Center Vertical",
      "url": "/product/center/brown-arm-chair"
    }]
  },
  "other": [{
    "title": "Wishlist",
    "url": "/pages/wishlist"
  }, {
    "title": "Shopping Cart",
    "url": "/pages/cart"
  }, {
    "title": "Checkout",
    "url": "/pages/checkout"
  }, {
    "title": "Dashboard",
    "url": "/pages/account"
  }, {
    "title": "Blog",
    "url": "/pages/blog"
  }, {
    "title": "About Us",
    "url": "/pages/about-us"
  }, {
    "title": "Contact Us",
    "url": "/pages/contact-us"
  }, {
    "title": "Login",
    "url": "/pages/login"
  }, {
    "title": "Forgot Password",
    "url": "/pages/forgot-password"
  }]
};

/***/ })

};
;