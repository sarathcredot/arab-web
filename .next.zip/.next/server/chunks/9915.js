exports.id = 9915;
exports.ids = [9915];
exports.modules = {

/***/ 9915:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ ProductThree; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8974);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

 // Import Custom Component


function ProductThree(props) {
  const {
    adClass = "",
    link = "default",
    product
  } = props;
  return __jsx("div", {
    className: `product-default media-with-lazy left-details product-widget ${adClass}`
  }, __jsx("figure", null, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: `/product/${link}/${product.slug}`
  }, __jsx("div", {
    className: "lazy-overlay"
  }), __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__.LazyLoadImage, {
    alt: "product",
    src: process.env.NEXT_PUBLIC_ASSET_URI + product.small_pictures[0].url,
    threshold: 500,
    effect: "black and white",
    width: "100%"
  }), product.small_pictures.length >= 2 ? __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__.LazyLoadImage, {
    alt: "product",
    src: process.env.NEXT_PUBLIC_ASSET_URI + product.small_pictures[1].url,
    threshold: 500,
    effect: "black and white",
    wrapperClassName: "product-image-hover"
  }) : "")), __jsx("div", {
    className: "product-details"
  }, __jsx("h3", {
    className: "product-title"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: `/product/default/${product.slug}`
  }, product.name)), __jsx("div", {
    className: "ratings-container"
  }, __jsx("div", {
    className: "product-ratings"
  }, __jsx("span", {
    className: "ratings",
    style: {
      width: 20 * product.ratings + '%'
    }
  }), __jsx("span", {
    className: "tooltiptext tooltip-top"
  }, product.ratings.toFixed(2)))), __jsx("div", {
    className: "price-box"
  }, product.price[0] == product.price[1] ? __jsx("span", {
    className: "product-price"
  }, '$' + product.price[0].toFixed(2)) : product.variants.length > 0 ? __jsx("span", {
    className: "product-price"
  }, '$' + product.price[0].toFixed(2), " \u2013 ", '$' + product.price[1].toFixed(2)) : __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("span", {
    className: "old-price"
  }, '$' + product.price[1].toFixed(2)), __jsx("span", {
    className: "product-price"
  }, '$' + product.price[0].toFixed(2))))));
}

/***/ })

};
;