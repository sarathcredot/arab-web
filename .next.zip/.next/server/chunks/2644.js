exports.id = 2644;
exports.ids = [2644];
exports.modules = {

/***/ 2644:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ SingleTabFive; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7659);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_tabs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8974);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);



function SingleTabFive(props) {
  const {
    adClass = "",
    product,
    isCustom = true
  } = props;

  function activeHandler(e) {
    e.preventDefault();
    document.querySelector('.add-product-review .active') && document.querySelector('.add-product-review .active').classList.remove('active');
    e.currentTarget.classList.add('active');
  }

  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
    className: "skel-pro-tabs"
  }), product && __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.Tabs, {
    className: `product-single-tabs ${adClass}`,
    selectedTabClassName: "active",
    selectedTabPanelClassName: "show"
  }, __jsx("div", {
    className: "container"
  }, __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.TabList, {
    className: "nav nav-tabs"
  }, __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.Tab, {
    className: "nav-item"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "#",
    className: "nav-link"
  }, "Description")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.Tab, {
    className: "nav-item"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "#",
    className: "nav-link"
  }, "Size Guide")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.Tab, {
    className: "nav-item"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "#",
    className: "nav-link"
  }, "Reviews (", product.reviews, ")")), isCustom ? __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.Tab, {
    className: "nav-item"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "#",
    className: "nav-link"
  }, "Custom Tab")) : ''), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.TabPanel, {
    className: "tab-pane fade"
  }, __jsx("div", {
    className: "product-desc-content"
  }, __jsx("p", null, product.short_description), __jsx("ul", null, __jsx("li", null, "Any Product types that You want - Simple, Configurable"), __jsx("li", null, "Downloadable/Digital Products, Virtual Products"), __jsx("li", null, "Inventory Management with Backordered items")), __jsx("p", null, "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "))), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.TabPanel, {
    className: "tab-pane fade"
  }, __jsx("div", {
    className: "product-size-content"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-md-4"
  }, __jsx("img", {
    src: "images/products/single/body-shape.png",
    alt: "body shape"
  })), __jsx("div", {
    className: "col-md-8"
  }, __jsx("table", {
    className: "table table-size"
  }, __jsx("thead", null, __jsx("tr", null, __jsx("th", null, "SIZE"), __jsx("th", null, "CHEST (in.)"), __jsx("th", null, "WAIST (in.)"), __jsx("th", null, "HIPS (in.)"))), __jsx("tbody", null, __jsx("tr", null, __jsx("td", null, "XS"), __jsx("td", null, "34-36"), __jsx("td", null, "27-29"), __jsx("td", null, "34.5-36.5")), __jsx("tr", null, __jsx("td", null, "S"), __jsx("td", null, "36-38"), __jsx("td", null, "29-31"), __jsx("td", null, "36.5-38.5")), __jsx("tr", null, __jsx("td", null, "M"), __jsx("td", null, "38-40"), __jsx("td", null, "31-33"), __jsx("td", null, "38.5-40.5")), __jsx("tr", null, __jsx("td", null, "L"), __jsx("td", null, "40-42"), __jsx("td", null, "33-36"), __jsx("td", null, "40.5-43.5")), __jsx("tr", null, __jsx("td", null, "XL"), __jsx("td", null, "42-45"), __jsx("td", null, "36-40"), __jsx("td", null, "43.5-47.5")), __jsx("tr", null, __jsx("td", null, "XLL"), __jsx("td", null, "45-48"), __jsx("td", null, "40-44"), __jsx("td", null, "47.5-51.5")))))))), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.TabPanel, {
    className: "tab-pane fade"
  }, __jsx("div", {
    className: "product-reviews-content"
  }, product.reviews !== 0 ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("h3", {
    className: "reviews-title"
  }, "1 review for Men Black Sports Shoes"), __jsx("div", {
    className: "comment-list"
  }, __jsx("div", {
    className: "comments"
  }, __jsx("figure", {
    className: "img-thumbnail"
  }, __jsx("img", {
    src: "images/blog/author.jpg",
    alt: "author",
    width: "80",
    className: "80"
  })), __jsx("div", {
    className: "comment-block"
  }, __jsx("div", {
    className: "comment-header"
  }, __jsx("div", {
    className: "comment-arrow"
  }), __jsx("div", {
    className: "ratings-container float-sm-right"
  }, __jsx("div", {
    className: "product-ratings"
  }, __jsx("span", {
    className: "ratings",
    style: {
      width: `${20 * product.ratings}%`
    }
  }), __jsx("span", {
    className: "tooltiptext tooltip-top"
  }, product.ratings.toFixed(2)))), __jsx("span", {
    className: "comment-by"
  }, __jsx("strong", null, "Joe Doe"), " \u2013 April 12, 2018")), __jsx("div", {
    className: "comment-content"
  }, __jsx("p", null, "Excellent.")))))) : __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("h3", {
    className: "reviews-title"
  }, "Review"), __jsx("p", null, "There are no reviews yet.")), __jsx("div", {
    className: "divider"
  }), __jsx("div", {
    className: "add-product-review"
  }, __jsx("div", {
    className: "add-product-review"
  }, __jsx("h3", {
    className: "review-title"
  }, "Add a review"), __jsx("form", {
    action: "#",
    className: "comment-form m-0"
  }, __jsx("div", {
    className: "rating-form"
  }, __jsx("label", {
    htmlFor: "rating"
  }, "Your rating ", __jsx("span", {
    className: "required"
  }, "*")), __jsx("span", {
    className: "rating-stars"
  }, __jsx("a", {
    className: "star-1",
    href: "#",
    onClick: activeHandler
  }, "1"), __jsx("a", {
    className: "star-2",
    href: "#",
    onClick: activeHandler
  }, "2"), __jsx("a", {
    className: "star-3",
    href: "#",
    onClick: activeHandler
  }, "3"), __jsx("a", {
    className: "star-4",
    href: "#",
    onClick: activeHandler
  }, "4"), __jsx("a", {
    className: "star-5",
    href: "#",
    onClick: activeHandler
  }, "5"))), __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Your review ", __jsx("span", {
    className: "required"
  }, "*")), __jsx("textarea", {
    cols: "5",
    rows: "6",
    className: "form-control form-control-sm"
  })), __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-md-6 col-xl-12"
  }, __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Name ", __jsx("span", {
    className: "required"
  }, "*")), __jsx("input", {
    type: "text",
    className: "form-control form-control-sm",
    required: true
  }))), __jsx("div", {
    className: "col-md-6 col-xl-12"
  }, __jsx("div", {
    className: "form-group"
  }, __jsx("label", null, "Email ", __jsx("span", {
    className: "required"
  }, "*")), __jsx("input", {
    type: "text",
    className: "form-control form-control-sm",
    required: true
  }))), __jsx("div", {
    className: "col-md-12"
  }, __jsx("div", {
    className: "custom-control custom-checkbox"
  }, __jsx("input", {
    type: "checkbox",
    className: "custom-control-input",
    id: "save-name"
  }), __jsx("label", {
    className: "custom-control-label mb-0",
    htmlFor: "save-name"
  }, "Save my name, email, and website in this browser for the next time I comment.")))), __jsx("input", {
    type: "submit",
    className: "btn btn-primary",
    value: "Submit"
  })))))), isCustom && __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_1__.TabPanel, {
    className: "tab-pane fade"
  }, __jsx("div", {
    className: "mb-2 pb-2"
  }, "Custom Tab Content")))));
}

/***/ })

};
;