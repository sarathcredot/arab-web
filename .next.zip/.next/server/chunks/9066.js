exports.id = 9066;
exports.ids = [9066];
exports.modules = {

/***/ 9066:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ ProductsGrid; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _features_products_product_one__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4011);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);
// Import Custom Component

function ProductsGrid(props) {
  const {
    products = [],
    gridClass = "col-6 col-sm-4 col-lg-3 custom-shopproduct",
    loading,
    perPage,
    addClass = ''
  } = props;
  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
    className: "custom-divide-line"
  }, __jsx("div", {
    className: `row row-joined  products-group skeleton-body skel-shop-products ${addClass} ${!loading ? 'loaded' : ''}`,
    style: {
      marginRight: "-1px",
      marginLeft: "-1px"
    }
  }, loading ? new Array(parseInt(perPage)).fill(1).map((item, index) => __jsx("div", {
    className: `skel-pro skel-pro-grid pr-3 pl-3 ${gridClass}`,
    key: "ProductGrid:" + index
  })) : products.map((item, index) => __jsx("div", {
    className: gridClass,
    key: `product-${index}`,
    style: {
      border: "1px solid #B9B9B9",
      borderTop: "transparent",
      borderRight: "transparent"
    }
  }, __jsx(_features_products_product_one__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    adClass: "inner-quickview inner-icon",
    product: item
  }))))), !loading && products.length === 0 ? __jsx("div", {
    className: "info-box with-icon"
  }, __jsx("p", null, "No products were found matching your selection.")) : '');
}

/***/ })

};
;