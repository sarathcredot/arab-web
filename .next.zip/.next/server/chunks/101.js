exports.id = 101;
exports.ids = [101];
exports.modules = {

/***/ 101:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony exports BRAND_LISTING, MAX_PRICE */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_slide_toggle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3920);
/* harmony import */ var react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_slide_toggle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_input_range__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4766);
/* harmony import */ var react_input_range__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_input_range__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_sticky_box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9058);
/* harmony import */ var react_sticky_box__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_sticky_box__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rc_tree__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5768);
/* harmony import */ var rc_tree__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rc_tree__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7164);
/* harmony import */ var _server_queries__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4733);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8974);
/* harmony import */ var _utils_data_shop__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(129);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







 // Import Apollo Server and Query


 // Import Custom Component

 // Import Utils


const GET_ATTRIBUTE = _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6__.gql`
  query GetAttributesDetailsByCategory($input: AttributesDetailsWithCategoryIdInput!) {
    getAttributesDetailsByCategory(input: $input) {
      message
      record {
        _id
        categoryName
        attributes {
          _id
          attributeType
          name
          description
          attributeValues {
            _id
            value
            colorCode
            priority
            isBlocked
          }
          isBlocked
        }
      }
    }
  }
`;
const BRAND_LISTING = _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6__.gql`
  query GetBrandDetailsWithCategory($input: BrandsDetailsWithCategoryIdInput!) {
    getBrandDetailsWithCategory(input: $input) {
      message
      records {
        _id
        brandName
        logo {
          fileType
          originalName
          fileURL
        }
        isPopular
        priority
      }
    }
  }
`;
const MAX_PRICE = _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6__.gql`
  query GetProductsMaxPrice($input: categoriesInput!) {
    getProductsMaxPrice(input: $input) {
      maxPrice
      message
    }
  }
`;

const TreeNode = props => {
  return __jsx(React.Fragment, null, props.name, __jsx("span", {
    className: "products-count"
  }, "(", props.count, ")"));
};

function ShopSidebarOne(props) {
  var _maxPriceData$getProd, _maxPriceData$getProd2, _brandData$getBrandDe3;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
  const query = router.query; // const queryString = query?.cat_id;
  // const parts = queryString ? queryString.split("?") : [];

  const catId = query === null || query === void 0 ? void 0 : query.cat_id;
  const brand = query === null || query === void 0 ? void 0 : query.brand;
  const {
    0: selectedBrands,
    1: setSelectedBrands
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: sortOrder,
    1: setSortOrder
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((query === null || query === void 0 ? void 0 : query.sort_order) || "none");
  const {
    0: selectedAttributeValues,
    1: setSelectedAttributeValues
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: attributes,
    1: setAttributes
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    data,
    loading,
    error
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6__.useQuery)(_server_queries__WEBPACK_IMPORTED_MODULE_8__/* .GET_SHOP_SIDEBAR_DATA */ .EP, {
    variables: {
      input: {
        parent: catId
      }
    }
  }); //maxprice value getting

  const {
    data: maxPriceData,
    loading: priceLoading,
    priceError
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6__.useQuery)(MAX_PRICE, {
    variables: {
      input: {
        categories: catId ? [catId] : []
      }
    }
  });
  const maxpricevalue = maxPriceData !== null && maxPriceData !== void 0 && (_maxPriceData$getProd = maxPriceData.getProductsMaxPrice) !== null && _maxPriceData$getProd !== void 0 && _maxPriceData$getProd.maxPrice ? maxPriceData === null || maxPriceData === void 0 ? void 0 : (_maxPriceData$getProd2 = maxPriceData.getProductsMaxPrice) === null || _maxPriceData$getProd2 === void 0 ? void 0 : _maxPriceData$getProd2.maxPrice : 1000;
  const {
    data: attributeData,
    loading: attributeLoading,
    error: attributeError
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6__.useQuery)(GET_ATTRIBUTE, {
    variables: {
      input: {
        categoryId: catId
      }
    }
  });
  const {
    data: brandData,
    loading: brandloading,
    error: branderror
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_6__.useQuery)(BRAND_LISTING, {
    variables: {
      input: {
        categoryId: catId
      }
    }
  });
  const {
    0: priceRange,
    1: setRange
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
    min: 0,
    max: 1000
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    return () => {
      closeSidebar();
    };
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (query.min_price && query.max_price) {
      setRange({
        min: parseInt(query.min_price),
        max: parseInt(query.max_price)
      });
    } else {
      setRange({
        min: 0,
        max: maxpricevalue
      });
    }
  }, [query, maxpricevalue]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    var _brandData$getBrandDe;

    // Extract brand ID from the URL
    const brandId = props.brand; // Check the brand corresponding to the brand ID in the URL

    if (brandId && brandData !== null && brandData !== void 0 && (_brandData$getBrandDe = brandData.getBrandDetailsWithCategory) !== null && _brandData$getBrandDe !== void 0 && _brandData$getBrandDe.records) {
      var _brandData$getBrandDe2;

      const brandName = (_brandData$getBrandDe2 = brandData.getBrandDetailsWithCategory.records.find(item => item._id === brandId)) === null || _brandData$getBrandDe2 === void 0 ? void 0 : _brandData$getBrandDe2.brandName;

      if (brandName) {
        setSelectedBrands([brandName]);
      }
    }
  }, [brandData]);

  const handleBrandCheckboxChange = brandName => {
    // Toggle the selected state of the brand
    if (selectedBrands.includes(brandName)) {
      setSelectedBrands(selectedBrands.filter(brand => brand !== brandName));
    } else {
      setSelectedBrands([...selectedBrands, brandName]);
    }
  };

  function filterByCategory(selected) {
    router.push(router.pathname.replace("[grid]", query.grid) + "?category=" + (selected.length ? selected[0] : ""));
  }

  function onChangePriceRange(value) {
    setRange(value);
  }

  function containsAttrInUrl(type, value) {
    const currentQueries = query[type] ? query[type].split(",") : [];
    return currentQueries && currentQueries.includes(value);
  }

  function getUrlForAttrs(type, value) {
    let currentQueries = query[type] ? query[type].split(",") : [];
    currentQueries = containsAttrInUrl(type, value) ? currentQueries.filter(item => item !== value) : [...currentQueries, value];
    return currentQueries.join(",");
  }

  function filterByPrice(e) {
    e.preventDefault();
    const searchParams = router.query;

    const newSearchparams = _objectSpread(_objectSpread({}, searchParams), {}, {
      max_price: priceRange.max,
      min_price: priceRange.min
    });

    router.replace({
      pathname: router.pathname,
      query: newSearchparams
    });
  }

  function handleSortOrderChange(e) {
    const selectedSortOrder = e.target.value;
    setSortOrder(selectedSortOrder);

    const searchParams = _objectSpread(_objectSpread({}, router.query), {}, {
      page: 0
    });

    const newSearchParams = _objectSpread(_objectSpread({}, searchParams), {}, {
      sort_order: selectedSortOrder
    });

    router.replace({
      pathname: router.pathname,
      query: newSearchParams
    });
  }

  function filterByDiscount(selectedDiscount) {
    console.log("selectedDiscount", selectedDiscount);

    if (query.discount === selectedDiscount) {
      const query = router.query;
      delete query.discount;
      router.push({
        pathname: router.pathname,
        query: _objectSpread(_objectSpread({}, query), {}, {
          page: 0 // Reset page to 0 when applying filters

        })
      });
    } else {
      const query = router.query;
      router.push({
        pathname: router.pathname,
        query: _objectSpread(_objectSpread({}, query), {}, {
          discount: selectedDiscount,
          page: 0 // Reset page to 0 when applying filters

        })
      });
    }
  }

  function closeSidebar() {
    document.querySelector("body").classList.contains("sidebar-opened") && document.querySelector("body").classList.remove("sidebar-opened");
  }

  if (error) {
    return __jsx("div", null, error.message);
  }

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    var _attributeData$getAtt;

    if (catId && (attributeData === null || attributeData === void 0 ? void 0 : (_attributeData$getAtt = attributeData.getAttributesDetailsByCategory) === null || _attributeData$getAtt === void 0 ? void 0 : _attributeData$getAtt.record.attributes.length) > 0) {
      var _attributeData$getAtt2;

      setAttributes(catId && (attributeData === null || attributeData === void 0 ? void 0 : (_attributeData$getAtt2 = attributeData.getAttributesDetailsByCategory) === null || _attributeData$getAtt2 === void 0 ? void 0 : _attributeData$getAtt2.record.attributes));
    }
  }, [catId, attributeData]);
  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
    className: "sidebar-overlay",
    onClick: closeSidebar
  }), __jsx("aside", {
    className: `sidebar-shop col-lg-3 pb-lg-3 mobile-sidebar skeleton-body skel-shop-products ${!loading ? "loaded" : ""} ${props.display === "none" ? "d-lg-none" : ""} ${props.right ? "" : "order-lg-first"}`,
    style: {
      maxHeight: "976px",
      overflow: "scroll"
    }
  }, __jsx((react_sticky_box__WEBPACK_IMPORTED_MODULE_3___default()), {
    className: "sidebar-wrapper",
    offsetTop: 0
  }, !catId && __jsx("div", {
    className: "widget-brand",
    style: {
      padding: "0"
    }
  }, loading ? __jsx("div", {
    className: "skel-widget"
  }) : __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), null, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => {
    var _data$getActiveChildC, _data$getActiveChildC2, _data$getActiveChildC3;

    return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("h3", {
      className: "widget-title",
      style: {
        borderBottom: "1px solid",
        borderColor: "#DDDDDD",
        marginLeft: "0px",
        paddingBottom: "20px"
      }
    }, __jsx("a", {
      href: "#",
      onClick: e => {
        e.preventDefault(), onToggle();
      },
      className: toggleState === "COLLAPSED" ? "collapsed" : "",
      style: {
        marginLeft: "20px",
        marginTop: "20px"
      }
    }, "Categories")), __jsx("div", {
      className: "overflow-hidden widget",
      ref: setCollapsibleElement
    }, __jsx("div", {
      className: "widget-body pb-0"
    }, __jsx("ul", {
      className: "cat-list"
    }, data && (data === null || data === void 0 ? void 0 : (_data$getActiveChildC = data.getActiveChildCategories) === null || _data$getActiveChildC === void 0 ? void 0 : _data$getActiveChildC.records.length) > 0 ? data === null || data === void 0 ? void 0 : (_data$getActiveChildC2 = data.getActiveChildCategories) === null || _data$getActiveChildC2 === void 0 ? void 0 : (_data$getActiveChildC3 = _data$getActiveChildC2.records) === null || _data$getActiveChildC3 === void 0 ? void 0 : _data$getActiveChildC3.map((category, index) => __jsx("li", {
      key: `category-${index}`
    }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
      className: "custom-categorylabels",
      href: {
        query: _objectSpread(_objectSpread({}, query), {}, {
          page: 0,
          category: getUrlForAttrs("category", category._id)
        })
      },
      scroll: false,
      style: containsAttrInUrl("category", category === null || category === void 0 ? void 0 : category._id) ? {
        color: "red"
      } : {}
    }, category === null || category === void 0 ? void 0 : category.categoryName))) : __jsx("li", null, "No categories")))));
  })), query.category || query.page || query.sizes || query.colors || query.min_price || query.max_price || query.discount ? __jsx("div", {
    className: "widget",
    style: {
      padding: "2rem"
    }
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
    href: {
      query: {
        cat_id: query.cat_id
      }
    } //  href={{ query: { grid: query.grid } }}
    ,
    scroll: false,
    className: "btn btn-primary reset-filter"
  }, "Reset All Filters")) : "", brandData && catId && (brandData === null || brandData === void 0 ? void 0 : (_brandData$getBrandDe3 = brandData.getBrandDetailsWithCategory) === null || _brandData$getBrandDe3 === void 0 ? void 0 : _brandData$getBrandDe3.records.length) > 0 && __jsx("div", {
    className: " widget-brand"
  }, loading ? __jsx("div", {
    className: "skel-widget"
  }) : __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), null, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => {
    var _brandData$getBrandDe4, _brandData$getBrandDe5, _brandData$getBrandDe6;

    return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, brandData && (brandData === null || brandData === void 0 ? void 0 : (_brandData$getBrandDe4 = brandData.getBrandDetailsWithCategory) === null || _brandData$getBrandDe4 === void 0 ? void 0 : _brandData$getBrandDe4.records.length) > 0 ? __jsx("div", {
      style: {
        borderBottom: "1px solid #B9B9B9",
        borderTop: "1px solid #B9B9B9",
        padding: "2rem"
      }
    }, __jsx("h3", {
      className: "widget-title"
    }, __jsx("a", {
      className: toggleState === "COLLAPSED" ? "collapsed" : "",
      href: "#",
      onClick: e => {
        e.preventDefault(), onToggle();
      }
    }, "Brand"))) : "", __jsx("div", {
      className: "overflow-hidden widget",
      ref: setCollapsibleElement
    }, __jsx("div", {
      className: "widget-body pb-0"
    }, __jsx("ul", {
      className: "cat-list"
    }, brandData === null || brandData === void 0 ? void 0 : (_brandData$getBrandDe5 = brandData.getBrandDetailsWithCategory) === null || _brandData$getBrandDe5 === void 0 ? void 0 : (_brandData$getBrandDe6 = _brandData$getBrandDe5.records) === null || _brandData$getBrandDe6 === void 0 ? void 0 : _brandData$getBrandDe6.map((item, index) => {
      var _query$brands;

      return __jsx("li", null, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
        href: {
          query: _objectSpread(_objectSpread({}, query), {}, {
            page: 0,
            brands: getUrlForAttrs("brands", item._id)
          })
        },
        key: `brands-${index}`,
        scroll: false
      }, __jsx("label", {
        htmlFor: item.brandName,
        style: containsAttrInUrl("brands", item._id) ? {
          color: "red",
          fontWeight: "500"
        } : {
          color: "inherit",
          fontWeight: "500"
        }
      }, __jsx("input", {
        id: item.brandName,
        type: "checkbox",
        checked: query === null || query === void 0 ? void 0 : (_query$brands = query.brands) === null || _query$brands === void 0 ? void 0 : _query$brands.includes(item._id),
        onChange: () => handleBrandCheckboxChange(item.brandName),
        style: {
          marginRight: "5px"
        }
      }), item.brandName)));
    })))));
  })), __jsx("div", {
    className: " widget-brand"
  }, loading ? __jsx("div", {
    className: "skel-widget"
  }) : __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), null, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
    style: {
      borderBottom: "1px solid #B9B9B9",
      borderTop: "1px solid #B9B9B9",
      padding: "2rem"
    }
  }, __jsx("h3", {
    className: "widget-title"
  }, __jsx("a", {
    className: toggleState === "COLLAPSED" ? "collapsed" : "",
    href: "#",
    onClick: e => {
      e.preventDefault(), onToggle();
    }
  }, "Sort"))), __jsx("div", {
    className: "overflow-hidden widget",
    ref: setCollapsibleElement,
    style: {
      padding: "2rem"
    }
  }, __jsx("div", {
    className: "widget-body pb-0"
  }, __jsx("ul", {
    className: "cat-list"
  }, __jsx("li", null, __jsx("input", {
    type: "radio",
    id: "none",
    name: "fav_language",
    value: "none",
    checked: sortOrder === "none",
    onChange: handleSortOrderChange
  }), __jsx("label", {
    for: "none",
    style: {
      color: sortOrder === "none" ? "red" : "inherit",
      fontWeight: "500"
    }
  }, " ", "\xA0None")), __jsx("li", null, __jsx("input", {
    type: "radio",
    id: "lowToHigh",
    name: "fav_language",
    value: "lowToHigh",
    checked: sortOrder === "lowToHigh",
    onChange: handleSortOrderChange
  }), __jsx("label", {
    for: "lowToHigh",
    style: {
      color: sortOrder === "lowToHigh" ? "red" : "inherit",
      fontWeight: "500"
    }
  }, " ", "\xA0Price Low- High")), __jsx("li", null, __jsx("input", {
    type: "radio",
    id: "highToLow",
    name: "fav_language",
    value: "highToLow",
    checked: sortOrder === "highToLow",
    onChange: handleSortOrderChange
  }), __jsx("label", {
    for: "highToLow",
    style: {
      color: sortOrder === "highToLow" ? "red" : "inherit",
      fontWeight: "500"
    }
  }, " ", "\xA0Price High-Low")))))))), __jsx("div", {
    className: " widget-brand"
  }, loading ? __jsx("div", {
    className: "skel-widget"
  }) : __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), null, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
    style: {
      borderBottom: "1px solid #B9B9B9",
      borderTop: "1px solid #B9B9B9",
      padding: "2rem"
    }
  }, __jsx("h3", {
    className: "widget-title "
  }, __jsx("a", {
    className: toggleState === "COLLAPSED" ? "collapsed" : "",
    href: "#",
    onClick: e => {
      e.preventDefault(), onToggle();
    }
  }, "Discount"))), __jsx("div", {
    className: "overflow-hidden widget",
    ref: setCollapsibleElement,
    style: {
      padding: "2rem"
    }
  }, __jsx("div", {
    className: "widget-body pb-0"
  }, __jsx("ul", {
    className: "cat-list"
  }, __jsx("li", null, __jsx("label", {
    onClick: () => filterByDiscount("10"),
    style: {
      color: query.discount === "10" ? "red" : "inherit",
      // Apply red color if selected, otherwise use default color
      fontWeight: "500"
    }
  }, "10% off or more")), __jsx("li", null, __jsx("label", {
    onClick: () => filterByDiscount("25"),
    style: {
      color: query.discount === "25" ? "red" : "inherit",
      fontWeight: "500"
    }
  }, "25% off or more")), __jsx("li", null, __jsx("label", {
    onClick: () => filterByDiscount("50"),
    style: {
      color: query.discount === "50" ? "red" : "inherit",
      fontWeight: "500"
    }
  }, " ", "50% off or more")), __jsx("li", null, __jsx("label", {
    onClick: () => filterByDiscount("75"),
    style: {
      color: query.discount === "75" ? "red" : "inherit",
      fontWeight: "500"
    }
  }, "75% off or more")))))))), __jsx("div", {
    className: " widget-price overflow-hidden",
    style: {
      padding: "0"
    }
  }, loading ? __jsx("div", {
    className: "skel-widget"
  }) : __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), null, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
    style: {
      borderBottom: "1px solid #B9B9B9",
      borderTop: "1px solid #B9B9B9",
      padding: "2rem"
    }
  }, __jsx("h3", {
    className: "widget-title",
    style: {
      // borderBottom: "1px solid",
      // borderColor: "#DDDDDD",
      width: "298px",
      marginLeft: "0px" // paddingBottom: "20px",

    }
  }, __jsx("a", {
    className: toggleState === "COLLAPSED" ? "collapsed" : "",
    href: "#",
    role: "button",
    onClick: e => {
      e.preventDefault(), onToggle();
    } // style={{ marginLeft: "20px", marginTop: "20px" }}

  }, "Price"))), __jsx("div", {
    className: "overflow-hidden",
    ref: setCollapsibleElement
  }, __jsx("div", {
    className: "widget-body pb-2",
    style: {
      padding: "20px"
    }
  }, __jsx("form", {
    action: "#"
  }, __jsx("div", {
    className: "price-slider-wrapper"
  }, __jsx((react_input_range__WEBPACK_IMPORTED_MODULE_2___default()), {
    maxValue: maxpricevalue,
    minValue: 0,
    step: 50,
    value: priceRange,
    onChange: onChangePriceRange
  })), __jsx("div", {
    className: "filter-price-action d-flex align-items-center justify-content-between flex-wrap"
  }, __jsx("div", {
    className: "filter-price-text",
    style: {
      fontFamily: "Poppins",
      fontWeight: "500px",
      fontSize: "12px"
    }
  }, "Price:", " ", __jsx("span", {
    id: "filter-price-range"
  }, "OMR ", priceRange.min, " \u2014 ", priceRange.max)), __jsx("button", {
    type: "button",
    className: "btn ",
    style: {
      backgroundColor: "black",
      color: "white"
    },
    onClick: e => filterByPrice(e)
  }, "Filter")))))))), attributes.length > 0 && (attributes === null || attributes === void 0 ? void 0 : attributes.map((attri, index) => {
    let attributeComponent;

    if (attri.attributeType === "COLOR") {
      attributeComponent = __jsx("div", {
        className: " widget-color",
        style: {
          padding: "0"
        }
      }, loading ? __jsx("div", {
        className: "skel-widget"
      }) : __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), null, ({
        onToggle,
        setCollapsibleElement,
        toggleState
      }) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
        style: {
          borderBottom: "1px solid #B9B9B9",
          borderTop: "1px solid #B9B9B9",
          padding: "2rem"
        }
      }, __jsx("h3", {
        className: "widget-title",
        style: {
          // borderBottom: "1px solid",
          // borderColor: "#DDDDDD",
          width: "298px",
          marginLeft: "0px" // paddingBottom: "20px",

        }
      }, __jsx("a", {
        className: toggleState === "COLLAPSED" ? "collapsed" : "",
        href: "#",
        onClick: e => {
          e.preventDefault();
          onToggle();
        } // style={{
        //   marginLeft: "20px",
        //   marginTop: "20px",
        // }}

      }, attri === null || attri === void 0 ? void 0 : attri.description))), __jsx("div", {
        className: "overflow-hidden widget",
        ref: setCollapsibleElement
      }, __jsx("div", {
        style: {
          padding: "10px"
        }
      }, __jsx("ul", {
        className: "config-swatch-list",
        style: {
          gap: "2px"
        }
      }, attri === null || attri === void 0 ? void 0 : attri.attributeValues.map((item, index) => __jsx("li", {
        className: containsAttrInUrl([attri === null || attri === void 0 ? void 0 : attri._id], item === null || item === void 0 ? void 0 : item._id) ? "active" : "",
        key: `${attri === null || attri === void 0 ? void 0 : attri._id}-${index}`,
        style: {
          width: "38px",
          height: "38px"
        }
      }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
        href: {
          query: _objectSpread(_objectSpread({}, query), {}, {
            page: 0,
            [attri === null || attri === void 0 ? void 0 : attri._id]: getUrlForAttrs(attri === null || attri === void 0 ? void 0 : attri._id, item._id)
          })
        },
        style: {
          backgroundColor: item === null || item === void 0 ? void 0 : item.colorCode,
          borderRadius: "50%",
          border: "1px solid black"
        },
        scroll: false
      })))))))));
    } else {
      attributeComponent = __jsx("div", {
        className: " widget-normal",
        style: {
          padding: "0"
        }
      }, loading ? __jsx("div", {
        className: "skel-widget"
      }) : __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), null, ({
        onToggle,
        setCollapsibleElement,
        toggleState
      }) => {
        var _attri$attributeValue;

        return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
          style: {
            borderBottom: "1px solid #B9B9B9",
            borderTop: "1px solid #B9B9B9",
            padding: "2rem"
          }
        }, __jsx("h3", {
          className: "widget-title",
          style: {
            // borderBottom: "1px solid",
            // borderColor: "#DDDDDD",
            // width: "298px",
            marginLeft: "0px" // paddingBottom: "20px",

          }
        }, __jsx("a", {
          className: toggleState === "COLLAPSED" ? "collapsed" : "",
          href: "#",
          onClick: e => {
            e.preventDefault();
            onToggle();
          } // style={{
          //   marginLeft: "20px",
          //   marginTop: "20px",
          // }}

        }, attri === null || attri === void 0 ? void 0 : attri.description))), __jsx("div", {
          className: "overflow-hidden widget",
          ref: setCollapsibleElement
        }, __jsx("div", {
          style: {
            padding: "10px"
          }
        }, __jsx("div", {
          style: {
            display: "flex",
            flexWrap: "wrap",
            maxWidth: "286px"
          }
        }, (attri === null || attri === void 0 ? void 0 : attri.attributeValues.length) > 0 && (attri === null || attri === void 0 ? void 0 : (_attri$attributeValue = attri.attributeValues) === null || _attri$attributeValue === void 0 ? void 0 : _attri$attributeValue.map((attriValues, index) => {
          var _query$attriId;

          const attriId = attri === null || attri === void 0 ? void 0 : attri._id;
          const selectedIds = ((_query$attriId = query[attriId]) === null || _query$attriId === void 0 ? void 0 : _query$attriId.split(",")) || [];
          const isActive = selectedIds.includes(attriValues._id);
          return __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
            className: "custom-categorylabels",
            href: {
              query: _objectSpread(_objectSpread({}, query), {}, {
                page: 0,
                [attri === null || attri === void 0 ? void 0 : attri._id]: getUrlForAttrs(attri === null || attri === void 0 ? void 0 : attri._id, attriValues._id)
              })
            },
            key: `${attri === null || attri === void 0 ? void 0 : attri._id}-${index}`,
            scroll: false,
            style: containsAttrInUrl(attri === null || attri === void 0 ? void 0 : attri._id, attriValues._id) ? {
              color: "red"
            } : {}
          }, __jsx("div", {
            style: {
              border: "1px solid rgb(220, 220, 220)",
              padding: "10px"
            }
          }, attriValues.value));
        }))))));
      }));
    }

    return __jsx("div", {
      key: index
    }, attributeComponent);
  })))));
}

/* harmony default export */ __webpack_exports__["ZP"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)({
  ssr: true
})(ShopSidebarOne));

/***/ })

};
;