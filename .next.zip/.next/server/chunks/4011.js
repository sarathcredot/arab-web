exports.id = 4011;
exports.ids = [4011];
exports.modules = {

/***/ 4011:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_wishlist__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5708);
/* harmony import */ var _store_cart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2806);
/* harmony import */ var _store_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6723);
/* harmony import */ var _modals_add_to_cart_popup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4922);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8974);
/* harmony import */ var _product_countdown__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4229);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_11__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







 // Import Actions




 // Import Custom Component




const POST_CART = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`
  mutation AddToCart($input: addToCartInput!) {
    addToCart(input: $input) {
      message
    }
  }
`;

function ProductOne(props) {
  var _product$images$, _product$mrp;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    adClass = "",
    link = "default",
    product
  } = props;
  const [addToCart] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useMutation)(POST_CART);

  function isSale() {
    var _product$variants;

    return product.price[0] !== product.price[1] && product.variants.length === 0 ? "-" + (100 * (product.price[1] - product.price[0]) / product.price[1]).toFixed(0) + "%" : product !== null && product !== void 0 && (_product$variants = product.variants) !== null && _product$variants !== void 0 && _product$variants.find(variant => variant === null || variant === void 0 ? void 0 : variant.sale_price) ? "Sale" : false;
  }

  function isInWishlist() {
    return product && props.wishlist.findIndex(item => item.slug === product.slug) > -1;
  }

  function isInCart() {
    return product && props.cart.findIndex(item => item.slug === _store_cart__WEBPACK_IMPORTED_MODULE_6__/* .default.slug */ .ZP.slug) > -1;
  }

  function onWishlistClick(e) {
    e.preventDefault();

    if (!isInWishlist()) {
      let target = e.currentTarget;
      target.classList.add("load-more-overlay");
      target.classList.add("loading");
      setTimeout(() => {
        target.classList.remove("load-more-overlay");
        target.classList.remove("loading");
        props.addToWishList(product);
      }, 1000);
    } else {
      router.push("/pages/wishlist");
    }
  } // function onAddCartClick(e) {
  //   e.preventDefault();
  //   props.addToCart(product);
  // }


  function onAddCartClick(e) {
    e.preventDefault();

    if (localStorage.getItem("arabtoken")) {
      try {
        if (product.stock > 0 && !e.currentTarget.classList.contains("disabled")) {
          const response = addToCart({
            variables: {
              input: {
                productId: product._id,
                quantity: 1
              }
            }
          });

          if (response) {
            cartRefetch();
            return (0,react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast)(__jsx(_modals_add_to_cart_popup__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
              product: {
                product
              }
            }));
          }
        }
      } catch (error) {
        console.log(error);
      }
    } else {
      const localCart = JSON.parse(localStorage.getItem("cart"));

      if (localCart) {
        const productIndex = localCart.findIndex(item => item.productId === product._id);

        if (productIndex > -1) {
          localCart[productIndex].quantity += 1;
        } else {
          localCart.push({
            productId: product._id,
            quantity: 1,
            name: product.productName,
            shortDescription: product.shortDescription,
            stock: product.stock,
            color: product.color,
            size: product.size,
            price: product.price,
            image: product.images[0] && product.images[0].fileURL,
            sellingPrice: product.sellingPrice,
            mrp: product.mrp
          });
        }

        localStorage.setItem("cart", JSON.stringify(localCart));
      } else {
        localStorage.setItem("cart", JSON.stringify([{
          productId: product._id,
          quantity: 1,
          name: product.productName,
          shortDescription: product.shortDescription,
          stock: product.stock,
          color: product.color,
          size: product.size,
          price: product.price,
          image: product.images[0] && product.images[0].fileURL,
          sellingPrice: product.sellingPrice,
          mrp: product.mrp
        }]));
      }
    }

    return (0,react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast)(__jsx(_modals_add_to_cart_popup__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
      product: {
        product
      }
    }));
  }

  function onQuickViewClick(e) {
    e.preventDefault();
    props.showQuickView(product.slug);
  }

  return __jsx("div", {
    className: `product-default media-with-lazy ${adClass}`
  }, __jsx("figure", {
    style: props.customStyle && {
      paddingTop: props.customStyle
    }
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
    href: `/product/default/${product === null || product === void 0 ? void 0 : product._id}`
  }, __jsx("div", {
    className: "lazy-overlay"
  }), __jsx("span", {
    style: {
      display: "flex",
      justifyContent: "center" // width: "130px",
      // height: "180px",

    }
  }, __jsx("img", {
    src: product === null || product === void 0 ? void 0 : (_product$images$ = product.images[0]) === null || _product$images$ === void 0 ? void 0 : _product$images$.fileURL // "images/iphone.svg"
    ,
    style: {
      width: "130px",
      objectFit: "contain",
      marginTop: "30px"
    }
  }))), __jsx("div", {
    className: "label-group"
  }, product.is_hot ? __jsx("div", {
    className: "product-label label-hot"
  }, "HOT") : "", isSale() ? __jsx("div", {
    className: "product-label label-sale"
  }, isSale()) : "")), __jsx("div", {
    className: "product-details",
    style: _objectSpread({
      alignItems: "left",
      justifyContent: "left"
    }, props.customdetailStyle && {
      marginTop: props.customdetailStyle
    })
  }, __jsx("div", {
    className: "category-wrap",
    style: {
      display: "flex",
      marginTop: "0",
      alignItems: "end",
      justifyContent: "center"
    }
  }, __jsx("div", {
    className: "category-list",
    style: {
      width: "50%",
      fontWeight: 600
    }
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
    href: "#" // href={{
    //   pathname: "/shop",
    //   query: { category: item.slug },
    // }}
    ,
    style: {
      color: "rgba(227, 6, 19, 1)",
      fontWeight: 600
    }
  }, product === null || product === void 0 ? void 0 : product.categoryNamePath)), __jsx("div", {
    style: {
      width: "50%",
      display: "flex",
      justifyContent: "end"
    }
  }, (product === null || product === void 0 ? void 0 : product.stock) > 0 && __jsx("div", {
    className: "custom-addcart",
    onClick: e => {
      if (product.stock > 0) {
        onAddCartClick(e, product);
      }
    },
    style: {
      cursor: "pointer"
    }
  }, __jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "25",
    height: "24",
    viewBox: "0 0 25 24",
    fill: "black",
    stroke: "black",
    className: "plusbtn"
  }, __jsx("path", {
    d: "M6.51025 12.0156H18.2022",
    "stroke-width": "1.8",
    "stroke-linecap": "round",
    "stroke-linejoin": "round"
  }), __jsx("path", {
    d: "M12.356 17.8421V6.19043",
    "stroke-width": "1.8",
    "stroke-linecap": "round",
    "stroke-linejoin": "round"
  }))))), __jsx("h3", {
    className: "product-title"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
    href: `/product/default/${product._id}`,
    style: {
      fontWeight: "500px",
      fontSize: "14px"
    }
  }, product.productName)), __jsx("div", {
    className: "price-box"
  }, __jsx("span", {
    className: "omr",
    style: {
      fontFamily: "Plus Jakarta Sans"
    }
  }, "OMR"), __jsx("span", {
    className: "product-price",
    style: {
      fontFamily: "Plus Jakarta Sans",
      fontWeight: "800px",
      fontSize: "16px",
      lineHeight: "15px",
      marginLeft: "10px"
    }
  }, product === null || product === void 0 ? void 0 : product.sellingPrice.toFixed(2)), __jsx("span", {
    className: "old-price",
    style: {
      marginLeft: "10px",
      color: "#777777"
    }
  }, product === null || product === void 0 ? void 0 : (_product$mrp = product.mrp) === null || _product$mrp === void 0 ? void 0 : _product$mrp.toFixed(2)))));
}

const mapStateToProps = state => {
  return {
    wishlist: state.wishlist.list ? state.wishlist.list : []
  };
};

/* harmony default export */ __webpack_exports__["Z"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)(mapStateToProps, _objectSpread(_objectSpread(_objectSpread({}, _store_wishlist__WEBPACK_IMPORTED_MODULE_5__/* .actions */ .Nw), _store_cart__WEBPACK_IMPORTED_MODULE_6__/* .actions */ .Nw), _store_modal__WEBPACK_IMPORTED_MODULE_7__/* .actions */ .Nw))(ProductOne));

/***/ })

};
;