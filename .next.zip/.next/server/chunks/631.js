exports.id = 631;
exports.ids = [631];
exports.modules = {

/***/ 631:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6302);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_image_lightbox__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7773);
/* harmony import */ var react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);




function ProductMediaFive(props) {
  const {
    0: openLB,
    1: setOpenLB
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: photoIndex,
    1: setPhotoIndex
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    adClass = '',
    subClass = '',
    product
  } = props;

  function isSale() {
    return product.price[0] !== product.price[1] && product.variants.length === 0 ? '-' + (100 * (product.price[1] - product.price[0]) / product.price[1]).toFixed(0) + '%' : product.variants.find(variant => variant.sale_price) ? "Sale" : false;
  }

  function openLightBox(index) {
    setOpenLB(true);
    setPhotoIndex(index);
  }

  function closeLightBox() {
    setOpenLB(false);
  }

  function moveNextPhoto() {
    setPhotoIndex((photoIndex + 1) % product.large_pictures.length);
  }

  function movePrevPhoto() {
    setPhotoIndex((photoIndex + product.large_pictures.length - 1) % product.large_pictures.length);
  }

  return __jsx("div", {
    className: `product-single-gallery ${adClass}`
  }, __jsx("div", {
    className: "skel-pro skel-magnifier-both"
  }), product && __jsx("div", {
    className: "product-info-gallery position-relative"
  }, __jsx("div", {
    className: "label-group"
  }, product.is_hot ? __jsx("div", {
    className: "product-label label-hot"
  }, "HOT") : '', isSale() ? __jsx("div", {
    className: "product-label label-sale"
  }, isSale()) : ''), __jsx("div", {
    className: "row"
  }, product ? product.large_pictures.map((item, index) => __jsx("div", {
    className: `product-item col-sm-6 ${subClass}`,
    key: "product-item" + index
  }, __jsx("div", {
    className: "inner"
  }, __jsx(react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2__.Magnifier, {
    style: {
      paddingTop: "100%",
      position: "relative"
    },
    imageSrc: process.env.NEXT_PUBLIC_ASSET_URI + item.url,
    imageAlt: "product",
    mouseActivation: "hover",
    cursorStyleActive: "crosshair",
    dragToMove: false,
    className: "product-single-image"
  }), __jsx("span", {
    className: "prod-full-screen",
    onClick: () => openLightBox(index)
  }, __jsx("i", {
    className: "icon-plus"
  }))))) : "")), openLB && __jsx((react_image_lightbox__WEBPACK_IMPORTED_MODULE_1___default()), {
    mainSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[photoIndex].url,
    prevSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[(photoIndex + product.large_pictures.length - 1) % product.large_pictures.length].url,
    nextSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[(photoIndex + 1) % product.large_pictures.length].url,
    onCloseRequest: closeLightBox,
    onMoveNextRequest: moveNextPhoto,
    onMovePrevRequest: movePrevPhoto
  }));
}

/* harmony default export */ __webpack_exports__["Z"] = (ProductMediaFive);

/***/ })

};
;