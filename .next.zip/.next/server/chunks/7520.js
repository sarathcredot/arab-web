exports.id = 7520;
exports.ids = [7520];
exports.modules = {

/***/ 7520:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ single_tab_three; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-slide-toggle"
var external_react_slide_toggle_ = __webpack_require__(3920);
var external_react_slide_toggle_default = /*#__PURE__*/__webpack_require__.n(external_react_slide_toggle_);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
;// CONCATENATED MODULE: ./components/features/accordion/accordion.jsx
var __jsx = (external_react_default()).createElement;


function Accordion(props) {
  const {
    adClass
  } = props;
  (0,external_react_.useEffect)(() => {// document.querySelector('.card-header').classList.add('expanded');
  }, []);

  function onHandleClick(e) {
    if (e.target.classList.contains("toggle-button") || e.target.querySelector(".toggle-button")) {
      if (e.target.classList.contains("collapsed") || e.target.querySelector(".toggle-button") && e.target.querySelector(".toggle-button").classList.contains("collapsed") || e.target.classList.contains("collapsing") || e.target.querySelector(".toggle-button") && e.target.querySelector(".toggle-button").classList.contains("collapsing")) {
        if (e.currentTarget.querySelector(".toggle-button.expanded")) {
          e.currentTarget.querySelector(".toggle-button.expanded").click();
        }

        if (e.currentTarget.querySelector(".toggle-button.expanding")) {
          e.currentTarget.querySelector(".toggle-button.expanding").click();
        }
      }
    }
  }

  return __jsx("div", {
    className: `accordion ${adClass}`,
    onClick: onHandleClick
  }, props.children);
}

/* harmony default export */ var accordion = (/*#__PURE__*/external_react_default().memo(Accordion));
;// CONCATENATED MODULE: ./components/partials/product/tabs/single-tab-three.jsx
var single_tab_three_jsx = (external_react_default()).createElement;

 // Import Custom Component




function SingleTabThree(props) {
  const {
    product,
    adClass = ''
  } = props;

  function activeHandler(e) {
    e.preventDefault();
    document.querySelector('.add-product-review .active') && document.querySelector('.add-product-review .active').classList.remove('active');
    e.currentTarget.classList.add('active');
  }

  return single_tab_three_jsx((external_react_default()).Fragment, null, single_tab_three_jsx("div", {
    className: "skel-pro-tabs"
  }), product && single_tab_three_jsx(accordion, {
    adClass: `product-single-collapse ${adClass}`
  }, single_tab_three_jsx((external_react_slide_toggle_default()), {
    collapsed: false
  }, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => single_tab_three_jsx("div", {
    className: "product-collapse-panel"
  }, single_tab_three_jsx("h3", {
    className: "product-collapse-title",
    onClick: onToggle
  }, single_tab_three_jsx(ALink/* default */.Z, {
    href: "#",
    className: `toggle-button ${toggleState.toLowerCase()}`
  }, "Description")), single_tab_three_jsx("div", {
    className: "product-collapse-body",
    ref: setCollapsibleElement
  }, single_tab_three_jsx("div", {
    className: "collapse-body-wrapper pl-0"
  }, single_tab_three_jsx("div", {
    className: "product-desc-content"
  }, single_tab_three_jsx("p", null, product && product.short_description), single_tab_three_jsx("ul", null, single_tab_three_jsx("li", null, "Any Product types that You want - Simple, Configurable"), single_tab_three_jsx("li", null, "Downloadable/Digital Products, Virtual Products"), single_tab_three_jsx("li", null, "Inventory Management with Backordered items")), single_tab_three_jsx("p", null, "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ")))))), single_tab_three_jsx((external_react_slide_toggle_default()), {
    collapsed: true
  }, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => single_tab_three_jsx("div", {
    className: "product-collapse-panel"
  }, single_tab_three_jsx("h3", {
    className: "product-collapse-title",
    onClick: onToggle
  }, single_tab_three_jsx(ALink/* default */.Z, {
    className: `toggle-button ${toggleState.toLowerCase()}`,
    href: "#"
  }, "Size Guid")), single_tab_three_jsx("div", {
    className: "product-collapse-body",
    ref: setCollapsibleElement
  }, single_tab_three_jsx("div", {
    className: "collapse-body-wrapper pl-0"
  }, single_tab_three_jsx("div", {
    className: "product-size-content"
  }, single_tab_three_jsx("div", {
    className: "row"
  }, single_tab_three_jsx("div", {
    className: "col-md-4"
  }, single_tab_three_jsx("img", {
    src: "images/products/single/body-shape.png",
    alt: "body shape"
  })), single_tab_three_jsx("div", {
    className: "col-md-8"
  }, single_tab_three_jsx("table", {
    className: "table table-size"
  }, single_tab_three_jsx("thead", null, single_tab_three_jsx("tr", null, single_tab_three_jsx("th", null, "SIZE"), single_tab_three_jsx("th", null, "CHEST (in.)"), single_tab_three_jsx("th", null, "WAIST (in.)"), single_tab_three_jsx("th", null, "HIPS (in.)"))), single_tab_three_jsx("tbody", null, single_tab_three_jsx("tr", null, single_tab_three_jsx("td", null, "XS"), single_tab_three_jsx("td", null, "34-36"), single_tab_three_jsx("td", null, "27-29"), single_tab_three_jsx("td", null, "34.5-36.5")), single_tab_three_jsx("tr", null, single_tab_three_jsx("td", null, "S"), single_tab_three_jsx("td", null, "36-38"), single_tab_three_jsx("td", null, "29-31"), single_tab_three_jsx("td", null, "36.5-38.5")), single_tab_three_jsx("tr", null, single_tab_three_jsx("td", null, "M"), single_tab_three_jsx("td", null, "38-40"), single_tab_three_jsx("td", null, "31-33"), single_tab_three_jsx("td", null, "38.5-40.5")), single_tab_three_jsx("tr", null, single_tab_three_jsx("td", null, "L"), single_tab_three_jsx("td", null, "40-42"), single_tab_three_jsx("td", null, "33-36"), single_tab_three_jsx("td", null, "40.5-43.5")), single_tab_three_jsx("tr", null, single_tab_three_jsx("td", null, "XL"), single_tab_three_jsx("td", null, "42-45"), single_tab_three_jsx("td", null, "36-40"), single_tab_three_jsx("td", null, "43.5-47.5")), single_tab_three_jsx("tr", null, single_tab_three_jsx("td", null, "XLL"), single_tab_three_jsx("td", null, "45-48"), single_tab_three_jsx("td", null, "40-44"), single_tab_three_jsx("td", null, "47.5-51.5"))))))))))), single_tab_three_jsx((external_react_slide_toggle_default()), {
    collapsed: true
  }, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => single_tab_three_jsx("div", {
    className: "product-collapse-panel"
  }, single_tab_three_jsx("h3", {
    className: "product-collapse-title",
    onClick: onToggle
  }, single_tab_three_jsx(ALink/* default */.Z, {
    className: `toggle-button ${toggleState.toLowerCase()}`,
    href: "#"
  }, "Reviews (", product.reviews, ")")), single_tab_three_jsx("div", {
    className: "product-collapse-body",
    ref: setCollapsibleElement
  }, single_tab_three_jsx("div", {
    className: "collapse-body-wrapper pl-0"
  }, single_tab_three_jsx("div", {
    className: "product-reviews-content"
  }, product.reviews !== 0 ? single_tab_three_jsx((external_react_default()).Fragment, null, single_tab_three_jsx("h3", {
    className: "reviews-title"
  }, "1 review for Men Black Sports Shoes"), single_tab_three_jsx("div", {
    className: "comment-list"
  }, single_tab_three_jsx("div", {
    className: "comments"
  }, single_tab_three_jsx("figure", {
    className: "img-thumbnail"
  }, single_tab_three_jsx("img", {
    src: "images/blog/author.jpg",
    alt: "author",
    width: "80",
    className: "80"
  })), single_tab_three_jsx("div", {
    className: "comment-block"
  }, single_tab_three_jsx("div", {
    className: "comment-header"
  }, single_tab_three_jsx("div", {
    className: "comment-arrow"
  }), single_tab_three_jsx("div", {
    className: "ratings-container float-sm-right"
  }, single_tab_three_jsx("div", {
    className: "product-ratings"
  }, single_tab_three_jsx("span", {
    className: "ratings",
    style: {
      width: `${20 * product.ratings}%`
    }
  }), single_tab_three_jsx("span", {
    className: "tooltiptext tooltip-top"
  }, product.ratings.toFixed(2)))), single_tab_three_jsx("span", {
    className: "comment-by"
  }, single_tab_three_jsx("strong", null, "Joe Doe"), " \u2013 April 12, 2018")), single_tab_three_jsx("div", {
    className: "comment-content"
  }, single_tab_three_jsx("p", null, "Excellent.")))))) : single_tab_three_jsx((external_react_default()).Fragment, null, single_tab_three_jsx("h3", {
    className: "reviews-title"
  }, "Review"), single_tab_three_jsx("p", null, "There are no reviews yet.")), single_tab_three_jsx("div", {
    className: "divider"
  }), single_tab_three_jsx("div", {
    className: "add-product-review"
  }, single_tab_three_jsx("div", {
    className: "add-product-review"
  }, single_tab_three_jsx("h3", {
    className: "review-title"
  }, "Add a review"), single_tab_three_jsx("form", {
    action: "#",
    className: "comment-form m-0"
  }, single_tab_three_jsx("div", {
    className: "rating-form"
  }, single_tab_three_jsx("label", {
    htmlFor: "rating"
  }, "Your rating ", single_tab_three_jsx("span", {
    className: "required"
  }, "*")), single_tab_three_jsx("span", {
    className: "rating-stars"
  }, single_tab_three_jsx("a", {
    className: "star-1",
    href: "#",
    onClick: activeHandler
  }, "1"), single_tab_three_jsx("a", {
    className: "star-2",
    href: "#",
    onClick: activeHandler
  }, "2"), single_tab_three_jsx("a", {
    className: "star-3",
    href: "#",
    onClick: activeHandler
  }, "3"), single_tab_three_jsx("a", {
    className: "star-4",
    href: "#",
    onClick: activeHandler
  }, "4"), single_tab_three_jsx("a", {
    className: "star-5",
    href: "#",
    onClick: activeHandler
  }, "5"))), single_tab_three_jsx("div", {
    className: "form-group"
  }, single_tab_three_jsx("label", null, "Your review ", single_tab_three_jsx("span", {
    className: "required"
  }, "*")), single_tab_three_jsx("textarea", {
    cols: "5",
    rows: "6",
    className: "form-control form-control-sm"
  })), single_tab_three_jsx("div", {
    className: "row"
  }, single_tab_three_jsx("div", {
    className: "col-md-6 col-xl-12"
  }, single_tab_three_jsx("div", {
    className: "form-group"
  }, single_tab_three_jsx("label", null, "Name ", single_tab_three_jsx("span", {
    className: "required"
  }, "*")), single_tab_three_jsx("input", {
    type: "text",
    className: "form-control form-control-sm",
    required: true
  }))), single_tab_three_jsx("div", {
    className: "col-md-6 col-xl-12"
  }, single_tab_three_jsx("div", {
    className: "form-group"
  }, single_tab_three_jsx("label", null, "Email ", single_tab_three_jsx("span", {
    className: "required"
  }, "*")), single_tab_three_jsx("input", {
    type: "text",
    className: "form-control form-control-sm",
    required: true
  }))), single_tab_three_jsx("div", {
    className: "col-md-12"
  }, single_tab_three_jsx("div", {
    className: "custom-control custom-checkbox"
  }, single_tab_three_jsx("input", {
    type: "checkbox",
    className: "custom-control-input",
    id: "save-name"
  }), single_tab_three_jsx("label", {
    className: "custom-control-label mb-0",
    htmlFor: "save-name"
  }, "Save my name, email, and website in this browser for the next time I comment.")))), single_tab_three_jsx("input", {
    type: "submit",
    className: "btn btn-primary",
    value: "Submit"
  })))))))))));
}

/* harmony default export */ var single_tab_three = (SingleTabThree);

/***/ })

};
;