exports.id = 2806;
exports.ids = [2806];
exports.modules = {

/***/ 4922:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8974);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

 // Import Custom Component




function CartPopup(props) {
  var _product$product, _product$product2, _product$product2$ima, _product$product3, _product$product4, _product$product5;

  const {
    product
  } = props;
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  return __jsx("div", {
    className: "minipopup-area"
  }, __jsx("div", {
    className: "minipopup-box",
    style: {
      top: "0"
    }
  }, __jsx("div", {
    className: "product media-with-lazy"
  }, __jsx("figure", {
    className: "product-media w-100"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: `/product/default/${product._id}`
  }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__.LazyLoadImage, {
    alt: "product",
    src: product !== null && product !== void 0 && (_product$product = product.product) !== null && _product$product !== void 0 && _product$product.images ? `${product === null || product === void 0 ? void 0 : (_product$product2 = product.product) === null || _product$product2 === void 0 ? void 0 : (_product$product2$ima = _product$product2.images[0]) === null || _product$product2$ima === void 0 ? void 0 : _product$product2$ima.fileURL}` : "",
    threshold: 500,
    effect: "black and white",
    width: "100%",
    height: "auto"
  }))), __jsx("div", {
    className: "product-detail"
  }, product.index > -1 ? !product.variants[product.index].color ? __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    className: "product-name",
    href: `/product/default/${product === null || product === void 0 ? void 0 : (_product$product3 = product.product) === null || _product$product3 === void 0 ? void 0 : _product$product3._id}`
  }, product.name + " - " + product.variants[product.index].size.name) : !product.variants[product.index].size ? __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    className: "product-name",
    href: `/product/default/${product.slug}`
  }, product.name + " - " + product.variants[product.index].color.name) : __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    className: "product-name",
    href: `/product/default/${product.slug}`
  }, product.name + " - " + product.variants[product.index].color.name + ", " + product.variants[product.index].size.name) : __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    className: "product-name",
    href: `/product/default/${product === null || product === void 0 ? void 0 : (_product$product4 = product.product) === null || _product$product4 === void 0 ? void 0 : _product$product4._id}`
  }, product === null || product === void 0 ? void 0 : (_product$product5 = product.product) === null || _product$product5 === void 0 ? void 0 : _product$product5.productName), __jsx("p", null, "has been added to your cart."))), __jsx("div", {
    className: "product-action"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "/pages/cart",
    className: "btn viewcart"
  }, "View Cart"), localStorage.getItem("arabtoken") && __jsx("div", {
    href: "/pages/checkout",
    className: "btn btn-dark checkout",
    onClick: () => router.push("/pages/checkout")
  }, "Checkout")), __jsx("button", {
    className: "mfp-close"
  })));
}

/* harmony default export */ __webpack_exports__["Z"] = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().memo(CartPopup));

/***/ }),

/***/ 2806:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nw": function() { return /* binding */ actions; },
/* harmony export */   "xT": function() { return /* binding */ cartSaga; }
/* harmony export */ });
/* unused harmony export actionTypes */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3643);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(584);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5060);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_features_modals_add_to_cart_popup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4922);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // Import Custom Component


const actionTypes = {
  AddToCart: "ADD_TO_CART",
  RemoveFromCart: "REMOVE_FROM_CART",
  RefreshStore: "REFRESH_STORE",
  UpdateCart: "UPDATE_CART"
};
const initialState = {
  cart: []
};

const cartReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.AddToCart:
      const productSlug = action.payload.product._id;

      if (state.cart.findIndex(product => product._id === productSlug && product.index === action.index) !== -1) {
        const cart = state.cart.reduce((cartAcc, product) => {
          if (product._id === productSlug && product.index === action.index) {
            cartAcc.push(_objectSpread(_objectSpread({}, product), {}, {
              qty: parseInt(product.qty) + parseInt(action.qty),
              sum: (product.sale_price ? product.sale_price : product.price) * (parseInt(product.qty) + parseInt(action.qty))
            })); // Increment qty
          } else {
            cartAcc.push(product);
          }

          return cartAcc;
        }, []);
        return _objectSpread(_objectSpread({}, state), {}, {
          cart
        });
      }

      return _objectSpread(_objectSpread({}, state), {}, {
        cart: [...state.cart, _objectSpread(_objectSpread({}, action.payload.product), {}, {
          qty: action.qty,
          price: action.payload.product.price,
          index: action.index
        })]
      });

    case actionTypes.UpdateCart:
      return _objectSpread(_objectSpread({}, state), {}, {
        cart: action.payload.products
      });

    case actionTypes.RemoveFromCart:
      let cart = state.cart.reduce((cartAcc, product) => {
        if (product.slug !== action.payload.product.slug || product.index !== action.payload.product.index) {
          cartAcc.push(product);
        }

        return cartAcc;
      }, []);
      return _objectSpread(_objectSpread({}, state), {}, {
        cart
      });

    case actionTypes.RefreshStore:
      return initialState;

    default:
      return state;
  }
};

const actions = {
  addToCart: (product, qty = 1, index = -1) => ({
    type: actionTypes.AddToCart,
    payload: {
      product
    },
    qty,
    index
  }),
  removeFromCart: product => ({
    type: actionTypes.RemoveFromCart,
    payload: {
      product
    }
  }),
  updateCart: products => ({
    type: actionTypes.UpdateCart,
    payload: {
      products
    }
  })
};
function* cartSaga() {
  yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_3__.takeEvery)(actionTypes.AddToCart, function* saga(e) {
    (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)(__jsx(_components_features_modals_add_to_cart_popup__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
      product: _objectSpread(_objectSpread({}, e.payload.product), {}, {
        index: e.index
      })
    }));
  });
}
const persistConfig = {
  keyPrefix: "porto-",
  key: "cart",
  storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2___default())
};
/* harmony default export */ __webpack_exports__["ZP"] = ((0,redux_persist__WEBPACK_IMPORTED_MODULE_1__.persistReducer)(persistConfig, cartReducer));

/***/ })

};
;