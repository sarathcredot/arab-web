exports.id = 7029;
exports.ids = [7029];
exports.modules = {

/***/ 7029:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);


function Qty({
  max = Infinity,
  onChangeQty,
  value = 1,
  disabled = false
}) {
  const {
    0: count,
    1: setCount
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value); // useEffect( () => {
  //     value !== count && setCount( value );
  // }, [ value ] )
  // useEffect( () => {
  //     onChangeQty && onChangeQty( count );
  // }, [ count ] )
  // function increase () {
  //     setCount(prevCount => Math.min(max, prevCount + 1));
  // }
  // function decrease () {
  //     setCount(prevCount => Math.max(1, prevCount - 1));
  // }
  // function changeCount ( e ) {
  //     let value = e.target.value ? parseInt( e.target.value ) : 0;
  //     setCount( Math.min( value, max ) );
  // }

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    value !== count && setCount(value);
  }, [value]);

  function increase() {
    if (disabled) return;
    const newCount = Math.min(max, count + 1);
    setCount(newCount);
    onChangeQty(newCount);
  }

  function decrease() {
    if (disabled) return;
    const newCount = Math.max(1, count - 1);
    setCount(newCount);
    onChangeQty(newCount);
  }

  return __jsx("div", {
    className: "product-single-qty"
  }, __jsx("div", {
    className: "input-group bootstrap-touchspin bootstrap-touchspin-injected"
  }, __jsx("span", {
    className: "input-group-btn input-group-prepend"
  }, __jsx("button", {
    className: "btn btn-outline btn-down-icon bootstrap-touchspin-down",
    onClick: decrease,
    type: "button",
    disabled: count === 1
  })), __jsx("input", {
    className: "horizontal-quantity form-control",
    type: "number",
    min: "1",
    max: max,
    value: count,
    style: {
      fontFamily: "Jakarta sans-serif;",
      fontWeight: "600"
    }
  }), __jsx("span", {
    className: "input-group-btn input-group-append"
  }, __jsx("button", {
    className: "btn btn-outline btn-up-icon bootstrap-touchspin-up",
    onClick: increase,
    type: "button",
    disabled: count === max
  }))));
}

/* harmony default export */ __webpack_exports__["Z"] = (Qty);

/***/ })

};
;