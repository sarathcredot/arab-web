exports.id = 2915;
exports.ids = [2915];
exports.modules = {

/***/ 2915:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_slide_toggle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3920);
/* harmony import */ var react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_slide_toggle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_wishlist__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5708);
/* harmony import */ var _store_cart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2806);
/* harmony import */ var _product_nav__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7684);
/* harmony import */ var _qty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7029);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8974);
/* harmony import */ var _features_product_countdown__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4229);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _features_modals_add_to_cart_popup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4922);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _server_apollo_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7164);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





 // Import Actions


 // Import Custom Component




 // import{useLazyQuery, useQuery}from"@apollo/client"




 // import eventEmmitter from "../../../../server/eventEmmitter";



function ProductDetailOne(props) {
  var _product$rating, _product$sellingPrice, _product$mrp, _product$rating2, _product$variantData;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const {
    product,
    adClass = "col-lg-7 col-md-6",
    prev,
    next,
    isNav = true,
    parent = ".product-single-default",
    isSticky = false
  } = props;
  const {
    0: attrs,
    1: setAttrs
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const {
    0: variant,
    1: setVariant
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const {
    0: size,
    1: setSize
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const {
    0: color,
    1: setColor
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const {
    0: qty,
    1: setQty
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
  const {
    0: selectedcolor,
    1: setSelectedColor
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: selectedAttributes,
    1: setSelectedAttributes
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const {
    0: variantData,
    1: setVariantData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const token = localStorage.getItem("arabtoken");
  const {
    0: wishlistDatas,
    1: setWishlistDatas
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(Boolean);
  const {
    0: colorVariants,
    1: setColorVariants
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const GET_VARIANT = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`
    query Query($input: VariantsInput!) {
      getVariants(input: $input) {
        variants {
          productId
          attributeId
          attributeType
          attributeName
          attributeValueId
          attributeValue
          attributeDescription
          colorCode
        }
      }
    }
  `;
  const POST_CART = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`
    mutation AddToCart($input: addToCartInput!) {
      addToCart(input: $input) {
        message
      }
    }
  `;
  const GET_CART = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`
    query GetCart {
      getCart {
        products {
          _id
          productId
          quantity
          name
          shortDescription
          stock
          color
          size
          price
          image
          sellingPrice
          mrp
        }
        grandTotal
        subTotal
        deliveryCharge
      }
    }
  `;
  const POST_WISHLIST = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`mutation AddToWishList($input: AddToWishListInput!) {
  addToWishList(input: $input) {
    message
  }
}`;
  const GET_WISH_LIST = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`query Products {
  getWishListProducts {
    products {
      image
      productId
      productName
      sellingPrice
      shortDescription
    }
  }
}`;
  const GET_WISHLIST_PRODUCT_STATUS = _apollo_client__WEBPACK_IMPORTED_MODULE_11__.gql`query GetWishListProductStatus($input: GetWishListProductStatusInput!) {
  getWishListProductStatus(input: $input) {
    isExist
  }
}`;
  const [addToCart] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useMutation)(POST_CART);
  const [addToWishList] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_11__.useMutation)(POST_WISHLIST);
  const {
    data: variData,
    loading: variantLoading,
    error: variantError
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_12__.useQuery)(GET_VARIANT, {
    variables: {
      input: {
        _id: product === null || product === void 0 ? void 0 : product._id
      }
    }
  });
  const {
    refetch: wishListRefetch
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_12__.useQuery)(GET_WISH_LIST, {
    skip: !token
  }); // console.log("dfgfff",variData);

  const getUniqueVariants = data => {
    const uniqueVariants = [];
    const variantSet = new Set();

    if (data !== null && data !== void 0 && data.length) {
      data.forEach(variant => {
        const key = `${variant.attributeName}_${variant.attributeValue}`;

        if (!variantSet.has(key)) {
          variantSet.add(key);
          uniqueVariants.push(variant);
        }
      });
    }

    return uniqueVariants;
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (variantError) {
      console.error("Error fetching variant data:", variantError);
    } else {
      var _variData$getVariants;

      //   if product.attributes having same attributeId and attributeValueId  in variData?.getVariants.variants , then add a create a new array with all the elements  of variData?.getVariants.variants  with a flag isAvailable
      const attributes = product === null || product === void 0 ? void 0 : product.attributes;
      const variants = variData === null || variData === void 0 ? void 0 : (_variData$getVariants = variData.getVariants) === null || _variData$getVariants === void 0 ? void 0 : _variData$getVariants.variants;

      if (attributes && variants) {
        const updatedVariants = variants.map(variant => {
          const matchingVariant = attributes.find(attribute => attribute.attributeId === variant.attributeId && attribute.attributeValueId === variant.attributeValueId);
          return _objectSpread(_objectSpread({}, variant), {}, {
            isAvailable: !!matchingVariant
          });
        });
        const filteredColorVariants = updatedVariants.filter(variant => variant.attributeType === "COLOR");

        if ((filteredColorVariants === null || filteredColorVariants === void 0 ? void 0 : filteredColorVariants.length) > 0) {
          const uniqueColorVariants = getUniqueVariants(filteredColorVariants);
          setColorVariants(uniqueColorVariants);
        }

        const uniqueVariants = getUniqueVariants(updatedVariants || []);
        setVariantData(uniqueVariants);
      }
    }
  }, [variData, product]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (product && variantData) {
      let attributes = variantData.reduce((acc, cur) => {
        const attributeType = cur === null || cur === void 0 ? void 0 : cur.attributeName.toLowerCase();
        const attributeName = cur === null || cur === void 0 ? void 0 : cur.attributeName;
        const attributeValue = cur === null || cur === void 0 ? void 0 : cur.attributeValue;

        if (!acc[attributeType]) {
          acc[attributeType] = [];
        }

        if (attributeValue && !acc[attributeType].find(attr => attr.value === attributeValue)) {
          acc[attributeType].push({
            name: attributeName,
            value: attributeValue
          });
        }

        return acc;
      }, {} // Initialize an empty object
      );
      setAttrs(attributes);
      initState();
    }
  }, [variantData]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (product && attrs) {
      let priceToggle = document.querySelector(`${parent} .price-toggle`);
      let variationToggle = document.querySelector(`${parent} .variation-toggle`); // Check if there are any attributes

      const hasAttributes = Object.keys(attrs).length > 0; // Check if any attribute is not selected

      const hasUnselectedAttribute = Object.values(attrs).some(attr => !attr);

      if (hasAttributes && hasUnselectedAttribute) {
        document.querySelector(`${parent} .shopping-cart`) && document.querySelector(`${parent} .shopping-cart`).classList.add("disabled");
        document.querySelector(`${parent} .sticky-cart .add-cart`) && document.querySelector(`${parent} .sticky-cart .add-cart`).classList.add("disabled");
        priceToggle && priceToggle.classList.contains("expanded") && priceToggle.click();
      } else {
        var _product$variants;

        document.querySelector(`${parent} .shopping-cart`) && document.querySelector(`${parent} .shopping-cart`).classList.remove("disabled");
        document.querySelector(`${parent} .sticky-cart .add-cart`) && document.querySelector(`${parent} .sticky-cart .add-cart`).classList.remove("disabled");
        let index = product === null || product === void 0 ? void 0 : (_product$variants = product.variants) === null || _product$variants === void 0 ? void 0 : _product$variants.findIndex(item => {
          const hasAttributeMatches = Object.keys(attrs).every(key => {
            const attributeValue = attrs[key];
            return !item[key] || item[key] && item[key].name === attributeValue;
          });
          return hasAttributeMatches;
        }); // TODO: when adding remove commented

        setVariant(_objectSpread(_objectSpread({}, product === null || product === void 0 ? void 0 : product.attributes[index]), {}, {
          id: index
        }));
      }

      if (Object.values(attrs).some(attr => attr !== null)) {
        variationToggle && variationToggle.classList.contains("collapsed") && variationToggle.click();
      } else {
        variationToggle && variationToggle.classList.contains("expanded") && variationToggle.click();
      }
    }
  }, [product]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (variant && variant.id >= 0) {
      let priceToggle = document.querySelector(`${parent} .price-toggle`);
      priceToggle && priceToggle.classList.contains("collapsed") && priceToggle.cccccc();
    }
  }, [product]);
  const {
    loading,
    error,
    data,
    refetch
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_12__.useQuery)(GET_WISHLIST_PRODUCT_STATUS, {
    variables: {
      input: {
        productId: product && product._id
      }
    },
    skip: !token
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (error) {
      console.log(wishListError.message);
    } else if (data) {
      setWishlistDatas(data === null || data === void 0 ? void 0 : data.getWishListProductStatus.isExist);
    }

    refetch();
  }, [data]);

  function isInWishlist() {
    return wishlistDatas;
  }

  function onWishlistClick(e) {
    if (!token) {
      router.push("/pages/login");
    }

    e.preventDefault();

    if (!isInWishlist()) {
      let target = e.currentTarget;
      target.classList.add("load-more-overlay");
      target.classList.add("loading");
      setTimeout(() => {
        target.classList.remove("load-more-overlay");
        target.classList.remove("loading"); // props.addToWishList(product);

        addToWishList({
          variables: {
            input: {
              productId: product._id
            }
          }
        }).then(res => {
          refetch(), wishListRefetch();
        }).catch(err => {
          console.log(err, "err");
        });
      }, 1000);
    } else {
      router.push("/pages/wishlist");
    }
  }

  const {
    data: cartData,
    loading: cartLoading,
    error: cartError,
    refetch: cartRefetch
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_12__.useQuery)(GET_CART, {
    skip: !token
  });

  const onAddCartClick = async e => {
    e.preventDefault();

    if (localStorage.getItem("arabtoken")) {
      try {
        if (product.stock > 0 && !e.currentTarget.classList.contains("disabled")) {
          const response = await addToCart({
            variables: {
              input: {
                productId: product._id,
                quantity: parseInt(qty)
              }
            }
          });

          if (response) {
            // eventEmmitter.emit("productAdded")
            cartRefetch();
            return (0,react_toastify__WEBPACK_IMPORTED_MODULE_14__.toast)(__jsx(_features_modals_add_to_cart_popup__WEBPACK_IMPORTED_MODULE_13__/* .default */ .Z, {
              product: {
                product
              }
            }));
          }
        }
      } catch (error) {
        console.log(error);
      }
    } else {
      const localCart = JSON.parse(localStorage.getItem("cart"));

      if (localCart) {
        const productIndex = localCart.findIndex(item => item.productId === product._id);

        if (productIndex > -1) {
          localCart[productIndex].quantity += qty;
        } else {
          localCart.push({
            productId: product._id,
            quantity: qty,
            name: product.productName,
            shortDescription: product.shortDescription,
            stock: product.stock,
            color: selectedAttributes.color,
            size: selectedAttributes.size,
            price: product.price,
            image: product.images[0] && product.images[0].fileURL,
            sellingPrice: product.sellingPrice,
            mrp: product.mrp
          });
        }

        localStorage.setItem("cart", JSON.stringify(localCart));
      } else {
        localStorage.setItem("cart", JSON.stringify([{
          productId: product._id,
          quantity: qty,
          name: product.productName,
          shortDescription: product.shortDescription,
          stock: product.stock,
          color: selectedAttributes.color,
          size: selectedAttributes.size,
          price: product.price,
          image: product.images[0] && product.images[0].fileURL,
          sellingPrice: product.sellingPrice,
          mrp: product.mrp
        }]));
      }
    }

    return (0,react_toastify__WEBPACK_IMPORTED_MODULE_14__.toast)(__jsx(_features_modals_add_to_cart_popup__WEBPACK_IMPORTED_MODULE_13__/* .default */ .Z, {
      product: {
        product
      }
    }));
  };

  function changeQty(value) {
    setQty(value);
  }

  function initState() {
    const defaultValues = {};
    product.attributes.forEach(variant => {
      const attributeType = variant.attributeName.toLowerCase();
      const defaultValue = variant.attributeValue;

      if (!defaultValues[attributeType]) {
        defaultValues[attributeType] = defaultValue;
      }
    });
    const defaultAttributes = {};
    Object.keys(defaultValues).forEach(attributeType => {
      defaultAttributes[attributeType] = defaultValues[attributeType];
    });
    setSelectedAttributes(defaultAttributes);
  } // ... other code


  function selectAttribute(attributeType, e) {
    e.preventDefault(); // setAttrs({})

    setSelectedAttributes({});
    const productId = attributeType; // Replace with your dynamic value

    router.push({
      pathname: "/product/default/[...slug]",
      query: {
        slug: [productId]
      }
    });
  } // ...


  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (product && variantData) {
      initState(); // ... (rest of the useEffect logic)
    }
  }, [product, variData]);

  function clearVariation(e) {
    e.preventDefault();
    initState();
  }

  function isDisabled(passvalue) {
    var _product$attributes;

    // const value = "red";
    const attrbutsvalue = product === null || product === void 0 ? void 0 : (_product$attributes = product.attributes) === null || _product$attributes === void 0 ? void 0 : _product$attributes.map(attribute => attribute.attributeValue); // Assuming `attrbutsvalue` is the property you want to compare

    const matchedElements = attrbutsvalue === null || attrbutsvalue === void 0 ? void 0 : attrbutsvalue.some(element => element === passvalue);
    return matchedElements;
  } // isDisabled()


  function updateSelectedAttributes(attributeType, value) {
    setSelectedAttributes(prev => _objectSpread(_objectSpread({}, prev), {}, {
      [attributeType]: value
    }));
  }

  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
    className: `skel-pro  skel-detail ${adClass}`
  }), product && __jsx("div", {
    className: `product-single-details ${adClass}`
  }, __jsx("p", {
    style: {
      color: "#E30613",
      fontWeight: "500",
      fontSize: "12px",
      lineHeight: "26px",
      textTransform: "uppercase",
      marginBottom: "0px"
    }
  }, product.categoryNamePath ? product.categoryNamePath.split(' ').pop() : ""), __jsx("h1", {
    className: "product-title",
    style: {
      fontWeight: "500",
      fontSize: "28px",
      lineHeight: "33.43px"
    }
  }, product === null || product === void 0 ? void 0 : product.productName), isNav ? __jsx(_product_nav__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
    prev: prev,
    next: next
  }) : "", __jsx("div", {
    className: "ratings-container"
  }, __jsx("div", {
    className: "product-ratings"
  }, __jsx("span", {
    className: "ratings",
    style: {
      width: `${20 * product.rating}%`
    }
  }), __jsx("span", {
    className: "tooltiptext tooltip-top"
  }, product === null || product === void 0 ? void 0 : (_product$rating = product.rating) === null || _product$rating === void 0 ? void 0 : _product$rating.toFixed(2))), __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
    href: "#",
    className: "rating-link",
    style: {
      fontSize: "1.1rem"
    }
  }, "(", " ", product.reviews > 0 ? `${product.reviews} Reviews` : "There are no reviews yet.", " ", ")")), __jsx("div", {
    className: "price-box"
  }, (product === null || product === void 0 ? void 0 : product.price) == product.price ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("span", {
    style: {
      fontFamily: "Plus Jakarta Sans",
      fontWeight: "600px",
      fontSize: "12px",
      lineHeight: "15px",
      marginTop: "10px",
      marginRight: "8px",
      color: "#606060"
    }
  }, "OMR"), __jsx("span", {
    className: "product-price",
    style: {
      fontWeight: "600px",
      fontSize: "18px",
      lineHeight: "15px",
      letterSpacing: "-0.1px",
      color: "black"
    }
  }, " ", product === null || product === void 0 ? void 0 : (_product$sellingPrice = product.sellingPrice) === null || _product$sellingPrice === void 0 ? void 0 : _product$sellingPrice.toFixed(2)), __jsx("span", {
    className: "old-price",
    style: {
      fontWeight: "600px",
      fontSize: "16px",
      lineHeight: "15px",
      letterSpacing: "-0.1px",
      marginLeft: "10px",
      marginBottom: "3px"
    }
  }, " ", product === null || product === void 0 ? void 0 : (_product$mrp = product.mrp) === null || _product$mrp === void 0 ? void 0 : _product$mrp.toFixed(2))) : (product === null || product === void 0 ? void 0 : product.variants.length) > 0 ? __jsx("span", {
    className: "product-price",
    style: {
      fontSize: "12px",
      fontFamily: "Plus Jakarta Sans",
      color: "#606060",
      fontWeight: "600"
    }
  }, "OMR \xA0\xA0\xA0", __jsx("span", {
    style: {
      fontSize: "18px",
      fontWeight: "700",
      color: "black"
    }
  }, product.price[0].toFixed(2), __jsx("span", {
    style: {
      fontSize: "16px",
      fontFamily: "Plus Jakarta Sans",
      color: "#606060",
      fontWeight: "600"
    }
  }, "\xA0\xA0\xA0", __jsx("strike", null, product !== null && product !== void 0 && product.mrp ? product === null || product === void 0 ? void 0 : product.mrp : product === null || product === void 0 ? void 0 : product.price)))) : __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("span", {
    className: "old-price",
    style: {
      fontSize: "12px",
      fontFamily: "Plus Jakarta Sans",
      color: "#606060",
      fontWeight: "600"
    }
  }, "OMR \xA0\xA0\xA0", __jsx("span", {
    style: {
      fontSize: "18px",
      fontWeight: "700",
      color: "black"
    }
  }, product.price.toFixed(2))), __jsx("span", {
    className: "new-price"
  }, "OMR" + product.price.toFixed(2)))), (product === null || product === void 0 ? void 0 : product.until) && (product === null || product === void 0 ? void 0 : product.until) !== null && __jsx(_features_product_countdown__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z, {
    type: "1"
  }), __jsx("div", {
    className: "product-desc",
    style: {
      fontFamily: "Poppins",
      fontWeight: "400px",
      fontSize: "14px",
      lineHeight: "26px"
    }
  }, __jsx("p", {
    style: {
      fontWeight: "400"
    }
  }, product === null || product === void 0 ? void 0 : product.shortDescription)), (variantData === null || variantData === void 0 ? void 0 : variantData.length) > 0 ? __jsx("div", {
    className: "product-filters-container"
  }, (colorVariants === null || colorVariants === void 0 ? void 0 : colorVariants.length) > 0 ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("label", null, "COLOR:\xA0", "", __jsx("span", {
    style: {
      fontWeight: "500"
    }
  }, selectedAttributes && ( // selectedAttributes.charAt(0).toUpperCase() +
  selectedAttributes === null || selectedAttributes === void 0 ? void 0 : selectedAttributes.color)))) : null, __jsx("div", {
    className: "product-single-filter  d-flex",
    style: {
      gap: "20px"
    }
  }, colorVariants.map((item, index) => {
    var _item$thumb, _item$thumb2, _item$thumb3;

    return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("ul", {
      className: "config-size-list config-color-list config-filter-list",
      style: {
        gap: "20px"
      }
    }, __jsx("li", {
      key: `filter-color-${index}`,
      className: ` ${item !== null && item !== void 0 && item.isAvailable ? "tag-remove" : ""}`
    }, item !== null && item !== void 0 && item.thumb ? __jsx("a", {
      className: "filter-thumb p-0"
    }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__.LazyLoadImage, {
      src: process.env.NEXT_PUBLIC_ASSET_URI + (item === null || item === void 0 ? void 0 : (_item$thumb = item.thumb) === null || _item$thumb === void 0 ? void 0 : _item$thumb.url),
      alt: "product thumb",
      width: item === null || item === void 0 ? void 0 : (_item$thumb2 = item.thumb) === null || _item$thumb2 === void 0 ? void 0 : _item$thumb2.width,
      height: item === null || item === void 0 ? void 0 : (_item$thumb3 = item.thumb) === null || _item$thumb3 === void 0 ? void 0 : _item$thumb3.height
    })) : __jsx("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        width: "63px",
        height: "63px",
        backgroundColor: (item === null || item === void 0 ? void 0 : item.attributeValue) === selectedAttributes[item === null || item === void 0 ? void 0 : item.attributeName.toLowerCase()] ? "#ebebeb" : "#f8f8f8",
        borderRadius: "50%"
      }
    }, __jsx("a", {
      className: "filter-color border-0",
      style: {
        backgroundColor: item === null || item === void 0 ? void 0 : item.colorCode,
        borderRadius: "50%",
        width: "3.8rem",
        height: "3.8rem",
        border: `1px solid ${item === null || item === void 0 ? void 0 : item.colorCode}`,
        cursor: "pointer"
      },
      onClick: e => {
        selectAttribute(item === null || item === void 0 ? void 0 : item.productId, e);
        updateSelectedAttributes(item === null || item === void 0 ? void 0 : item.attributeName.toLowerCase(), item === null || item === void 0 ? void 0 : item.attributeValue);
      }
    })))));
  })), (variantData === null || variantData === void 0 ? void 0 : variantData.length) > 0 ? __jsx("div", {
    className: "product-single-filter"
  }, variantData !== null && variantData !== void 0 && variantData.some(value => {
    var _value$attributeName;

    return (value === null || value === void 0 ? void 0 : (_value$attributeName = value.attributeName) === null || _value$attributeName === void 0 ? void 0 : _value$attributeName.toLowerCase()) === "size";
  }) ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("label", {
    style: {
      // fontWeight: "600px",
      // fontSize: "14px",
      // lineHeight: "22px",
      // marginBottom:"5px",
      color: "#000",
      fontWeight: "500"
    }
  }, "Size")) : null, __jsx("div", {
    className: " d-flex ",
    style: {
      gap: "4px",
      marginBottom: "1rem"
    }
  }, variantData === null || variantData === void 0 ? void 0 : variantData.filter(value => value.attributeName.toLowerCase() === "size").map((item, index) => {
    var _item$thumb4;

    return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("ul", {
      className: "config-size-list d-flex",
      style: {
        marginTop: "5px"
      }
    }, __jsx("li", {
      key: `filter-size-${index}`,
      className: `${(item === null || item === void 0 ? void 0 : item.attributeValue) === selectedAttributes.size ? "active" : "" // attrs["size"]?.find((value) =>
      //   product?.attributes?.some((attrValue) => attrValue?.attributeValue === value.value)
      // )
      //   ? "active"
      //   : ""
      } ${!isDisabled(item === null || item === void 0 ? void 0 : item.attributeValue) ? "strikethrough" : ""}`
    }, item !== null && item !== void 0 && item.thumb ? __jsx("a", {
      href: "#",
      className: "filter-thumb p-0",
      onClick: e => {
        selectAttribute(item === null || item === void 0 ? void 0 : item.productId, e);
        updateSelectedAttributes(item === null || item === void 0 ? void 0 : item.attributeName.toLowerCase(), item === null || item === void 0 ? void 0 : item.attributeValue);
      }
    }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__.LazyLoadImage, {
      src: process.env.NEXT_PUBLIC_ASSET_URI + (item === null || item === void 0 ? void 0 : (_item$thumb4 = item.thumb) === null || _item$thumb4 === void 0 ? void 0 : _item$thumb4.url),
      alt: "product thumb",
      width: item.thumb.width,
      height: item.thumb.height
    })) : __jsx("a", {
      href: "#",
      className: "d-flex align-items-center justify-content-center",
      onClick: e => selectAttribute(item === null || item === void 0 ? void 0 : item.productId, e),
      style: {
        fontWeight: "600",
        fontSize: "12px",
        lineHeight: "15px" // color: "#292D32",

      }
    }, item === null || item === void 0 ? void 0 : item.attributeValue))));
  }))) : "", (variantData === null || variantData === void 0 ? void 0 : variantData.length) > 0 ? __jsx("div", {
    className: "product-single-filter"
  }, Array.from(new Set(variantData === null || variantData === void 0 ? void 0 : variantData.filter(value => value.attributeName.toLowerCase() !== "size" && value.attributeDescription.toLowerCase() !== "size" && value.attributeDescription.toLowerCase() !== "color" && value.attributeDescription.toLowerCase() !== "colour").map(item => item.attributeName.toLowerCase()))).map((uniqueAttributeName, index) => __jsx("div", {
    key: `attribute-group-${index}`,
    style: {
      marginBottom: "1rem"
    }
  }, __jsx("label", {
    style: {
      color: "#000",
      fontWeight: "500",
      marginBottom: "10px"
    }
  }, uniqueAttributeName, " \xA0"), __jsx("ul", {
    className: "config-size-list ",
    style: {
      marginTop: "5px"
    }
  }, variantData === null || variantData === void 0 ? void 0 : variantData.filter(item => item.attributeName.toLowerCase() === uniqueAttributeName).map((item, subIndex) => {
    var _item$thumb5;

    return __jsx("li", {
      key: `filter-size-${subIndex}`,
      className: `${Object.values(selectedAttributes).includes(item === null || item === void 0 ? void 0 : item.attributeValue) ? "active" : ""} ${!isDisabled(item === null || item === void 0 ? void 0 : item.attributeValue) // ? "strikethrough"
      ? "" : ""}`
    }, item !== null && item !== void 0 && item.thumb ? __jsx("a", {
      href: "#",
      className: "filter-thumb p-0",
      onClick: e => selectAttribute(item === null || item === void 0 ? void 0 : item.productId, e)
    }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__.LazyLoadImage, {
      src: process.env.NEXT_PUBLIC_ASSET_URI + (item === null || item === void 0 ? void 0 : (_item$thumb5 = item.thumb) === null || _item$thumb5 === void 0 ? void 0 : _item$thumb5.url),
      alt: "product thumb",
      width: item.thumb.width,
      height: item.thumb.height
    })) : __jsx("a", {
      href: "#",
      className: "d-flex align-items-center justify-content-center",
      onClick: e => selectAttribute(item === null || item === void 0 ? void 0 : item.productId, e),
      style: {
        fontWeight: "600",
        fontSize: "12px",
        lineHeight: "15px",
        // color: "#292D32",
        marginRight: "5px" // color:`${  isDisabled(item.attributeDescription, item.attributeValue)? "blue":"black"}`

      }
    }, item === null || item === void 0 ? void 0 : item.attributeValue));
  }))))) : "") : "", isSticky && __jsx("div", {
    className: "sticky-wrapper"
  }, __jsx("div", {
    className: "sticky-header desktop-sticky sticky-cart d-none d-lg-block"
  }, __jsx("div", {
    className: "container"
  }, __jsx("div", {
    className: "sticky-img mr-4 media-with-lazy"
  }, __jsx("figure", {
    className: "mb-0"
  }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__.LazyLoadImage, {
    src: process.env.NEXT_PUBLIC_ASSET_URI + product.product.url,
    width: "100%",
    height: "auto",
    alt: "Thumbnail"
  }))), __jsx("div", {
    className: "sticky-detail"
  }, __jsx("div", {
    className: "sticky-product-name"
  }, __jsx("h2", {
    className: "product-title w-100 ls-0"
  }, product.productName)), __jsx("div", {
    className: "ratings-container"
  }, __jsx("div", {
    className: "product-ratings"
  }, __jsx("span", {
    className: "ratings",
    style: {
      width: `${20 * product.rating}%`
    }
  }), __jsx("span", {
    className: "tooltiptext tooltip-top"
  }, product === null || product === void 0 ? void 0 : (_product$rating2 = product.rating) === null || _product$rating2 === void 0 ? void 0 : _product$rating2.toFixed(2))), __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
    href: "#",
    className: "rating-link"
  }, "(", " ", product.reviews > 0 ? `${product.reviews} Reviews` : "There are no reviews yet.", " ", ")"))), __jsx("div", {
    className: "product-action"
  }, __jsx(_qty__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
    max: (product === null || product === void 0 ? void 0 : product.stock) > 10 ? 10 : product === null || product === void 0 ? void 0 : product.stock,
    value: qty,
    onChangeQty: changeQty
  }), __jsx("a", {
    href: "#",
    className: `btn btn-dark add-cart mr-2 ${product.stock < 0 ? "disabled" : ""}`,
    title: "Add To Cart",
    onClick: onAddCartClick
  }, "Add to Cart"))))), __jsx("div", {
    className: "product-action"
  }, product !== null && product !== void 0 && (_product$variantData = product.variantData) !== null && _product$variantData !== void 0 && _product$variantData.length ? __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), {
    collapsed: true
  }, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("button", {
    className: `d-none price-toggle ${toggleState === null || toggleState === void 0 ? void 0 : toggleState.toLowerCase()}`,
    onClick: onToggle
  }), __jsx("div", {
    className: "price-box product-filtered-price m-0",
    ref: setCollapsibleElement
  }, variant && variant.id >= 0 && (variant.price ? variant.sale_price ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("del", {
    className: "old-price"
  }, __jsx("span", null, "$", variant.price.toFixed(2))), __jsx("span", {
    className: "product-price"
  }, "$", variant && variant.sale_price.toFixed(2))) : __jsx("span", {
    className: "product-price"
  }, "$", variant && variant.price.toFixed(2)) : __jsx("span", {
    className: "product-stock pb-3 d-block"
  }, product.is_out_of_stock ? "Out of Stock" : `${product.stock} in stock`))))) : "", __jsx(_qty__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
    max: 10,
    value: qty,
    onChangeQty: changeQty
  }), __jsx("a", {
    href: "#",
    style: product.stock < 1 ? {
      pointerEvents: "none",
      touchAction: "none"
    } : {},
    className: `btn btn-dark add-cart shopping-cart mr-2 custom-detail-cart ${product.stock < 1 ? "disabled" : ""}`,
    title: "Add To Cart",
    onClick: () => product.stock > 0 ? onAddCartClick : null
  }, (product === null || product === void 0 ? void 0 : product.stock) > 0 ? "Add To Cart" : "Out of Stock")), __jsx("hr", {
    className: "divider mb-0 mt-0"
  }), __jsx("div", {
    className: "product-single-share mb-3"
  }, __jsx("label", {
    className: "sr-only"
  }, "Share:"), __jsx("a", {
    href: "#",
    className: `btn-icon-wish add-wishlist ${isInWishlist() ? "added-wishlist" : ""}`,
    onClick: onWishlistClick,
    title: `${isInWishlist() ? "Go to Wishlist" : "Add to Wishlist"}`
  }, __jsx("i", {
    className: "icon-wishlist-2"
  }), __jsx("span", {
    style: {
      marginLeft: "10px",
      fontFamily: "Poppins",
      fontWeight: "14px",
      lineHeight: "34px"
    }
  }, isInWishlist() ? "Go to Wishlist" : "Add to Wishlist")))));
}

const mapStateToProps = state => {
  return {
    wishlist: state.wishlist.list ? state.wishlist.list : []
  };
};

/* harmony default export */ __webpack_exports__["Z"] = ((0,_server_apollo_js__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z)({
  ssr: true
})((0,react_redux__WEBPACK_IMPORTED_MODULE_3__.connect)(mapStateToProps, _objectSpread(_objectSpread({}, _store_wishlist__WEBPACK_IMPORTED_MODULE_5__/* .actions */ .Nw), _store_cart__WEBPACK_IMPORTED_MODULE_6__/* .actions */ .Nw))(ProductDetailOne)));

/***/ })

};
;