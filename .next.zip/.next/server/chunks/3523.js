exports.id = 3523;
exports.ids = [3523];
exports.modules = {

/***/ 3523:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ SingleTabOne; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8974);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7659);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_tabs__WEBPACK_IMPORTED_MODULE_2__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);



function SingleTabOne(props) {
  var _product$productDetai, _product$productInfo;

  const {
    adClass = "",
    product
  } = props;

  function activeHandler(e) {
    e.preventDefault();
    document.querySelector('.add-product-review .active') && document.querySelector('.add-product-review .active').classList.remove('active');
    e.currentTarget.classList.add('active');
  }

  const {
    0: activeTab,
    1: setActiveTab
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0); // Initialize the active tab

  function activeHandler(e, tabIndex) {
    e.preventDefault();
    setActiveTab(tabIndex); // Update the active tab when a tab is clicked
  }

  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
    className: "skel-pro-tabs"
  }), product && __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_2__.Tabs, {
    className: `product-single-tabs ${adClass}`,
    selectedTabClassName: "active",
    selectedTabPanelClassName: "show"
  }, __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_2__.TabList, {
    className: "nav nav-tabs"
  }, __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_2__.Tab, {
    className: "nav-item"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: "#",
    className: "nav-link",
    style: {
      fontFamily: "Poppines"
    }
  }, "OverView")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_2__.Tab, {
    className: "nav-item"
  }, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: "#",
    className: "nav-link",
    style: {
      fontFamily: "Poppines"
    }
  }, "Specifications"))), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_2__.TabPanel, {
    className: "tab-pane fade"
  }, __jsx("p", {
    style: {
      marginBottom: "9px",
      letterSpacing: 0,
      listStyleType: "disc",
      color: "#000",
      fontFamily: "Poppins",
      fontSize: "1.4rem",
      fontStyle: "normal",
      fontWeight: "400",
      lineHeight: "2.375rem"
    }
  }, product === null || product === void 0 ? void 0 : product.description), __jsx("div", {
    className: "container",
    style: {
      marginTop: "79px"
    }
  }, product && (product === null || product === void 0 ? void 0 : (_product$productDetai = product.productDetailImages) === null || _product$productDetai === void 0 ? void 0 : _product$productDetai.map((image, index) => __jsx("div", {
    key: index
  }, __jsx("img", {
    src: image.fileURL,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  })))))), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_2__.TabPanel, {
    className: "tab-pane fade"
  }, __jsx("div", {
    className: "product-desc-content"
  }, __jsx("ul", null, product === null || product === void 0 ? void 0 : (_product$productInfo = product.productInfo) === null || _product$productInfo === void 0 ? void 0 : _product$productInfo.map((item, index) => {
    return __jsx("li", {
      key: index
    }, item);
  }))))));
}

/***/ })

};
;