exports.id = 3825;
exports.ids = [3825];
exports.modules = {

/***/ 3825:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_slide_toggle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3920);
/* harmony import */ var react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_slide_toggle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_sticky_box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9058);
/* harmony import */ var react_sticky_box__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_sticky_box__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store_wishlist__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5708);
/* harmony import */ var _store_cart__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2806);
/* harmony import */ var _product_nav__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7684);
/* harmony import */ var _qty__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7029);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8974);
/* harmony import */ var _features_product_countdown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4229);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






 // Import Actions


 // Import Custom Component






function ProductDetailFive(props) {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  const {
    product,
    adClassOne = "",
    type = '',
    prev,
    next,
    adClassTwo = "order-last",
    parent = ".product-single-default"
  } = props;
  const {
    0: attrs,
    1: setAttrs
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
    sizes: [],
    colors: []
  });
  const {
    0: variant,
    1: setVariant
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const {
    0: size,
    1: setSize
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const {
    0: color,
    1: setColor
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const {
    0: qty,
    1: setQty
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (product) {
      let attributes = product.variants.reduce((acc, cur) => {
        cur.size && !acc.sizes.find(size => size.size === cur.size.size) && acc.sizes.push(cur.size);
        cur.color && !acc.colors.find(color => color.name === cur.color.name) && acc.colors.push(cur.color);
        return acc;
      }, {
        sizes: [],
        colors: []
      });
      setAttrs(attributes);
      initState();
    }
  }, [product]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (product) {
      let priceToggle = document.querySelector(`${parent} .price-toggle`);
      let variationToggle = document.querySelector(`${parent} .variation-toggle`);

      if (attrs.sizes.length && !size || attrs.colors.length && !color) {
        document.querySelector(`${parent} .add-cart`) && document.querySelector(`${parent} .add-cart`).classList.add('disabled');
        priceToggle && priceToggle.classList.contains('expanded') && priceToggle.click();
      } else {
        document.querySelector(`${parent} .add-cart`) && document.querySelector(`${parent} .add-cart`).classList.remove('disabled');
        let index = product.variants.findIndex(item => {
          return !(item.size && item.size.size !== size) && !(item.color && item.color.name !== color);
        });
        setVariant(_objectSpread(_objectSpread({}, product.variants[index]), {}, {
          id: index
        }));
      }

      if (size !== null || color !== null) {
        variationToggle && variationToggle.classList.contains('collapsed') && variationToggle.click();
      } else {
        variationToggle && variationToggle.classList.contains('expanded') && variationToggle.click();
      }
    }
  }, [size, color]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (variant && variant.id >= 0) {
      let priceToggle = document.querySelector(`${parent} .price-toggle`);
      priceToggle && priceToggle.classList.contains('collapsed') && priceToggle.click();
    }
  }, [variant]);

  function isInWishlist() {
    return product && props.wishlist.findIndex(item => item.slug === product.slug) > -1;
  }

  function onWishlistClick(e) {
    e.preventDefault();

    if (!isInWishlist()) {
      let target = e.currentTarget;
      target.classList.add("load-more-overlay");
      target.classList.add("loading");
      setTimeout(() => {
        target.classList.remove('load-more-overlay');
        target.classList.remove('loading');
        props.addToWishList(product);
      }, 1000);
    } else {
      router.push('/pages/wishlist');
    }
  }

  function onAddCartClick(e) {
    e.preventDefault();

    if (product.stock > 0 && !e.currentTarget.classList.contains('disabled')) {
      if (product.variants.length === 0) {
        props.addToCart(product, qty, -1);
      } else {
        props.addToCart(product, qty, variant.id);
      }
    }
  }

  function changeQty(value) {
    setQty(value);
  }

  function selectColor(name, e) {
    e.preventDefault();
    setColor(color !== name ? name : null);
  }

  function selectSize(name, e) {
    e.preventDefault();
    setSize(size !== name ? name : null);
  }

  function initState() {
    setSize(null);
    setColor(null);
    setQty(1);
  }

  function clearVariation(e) {
    e.preventDefault();
    initState();
  }

  function isDisabled(type, name) {
    if (type === 'color' && size) {
      return !product.variants.find(variant => variant.size.size === size && variant.color.name === name);
    } else if (type === 'size' && color) {
      return !product.variants.find(variant => variant.color.name === color && variant.size.size === name);
    }

    return false;
  }

  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
    className: `col-lg-3 ${adClassOne}`
  }, __jsx((react_sticky_box__WEBPACK_IMPORTED_MODULE_5___default()), {
    className: "sidebar-wrapper",
    offsetTop: 70
  }, __jsx("div", {
    className: "skel-pro skel-sticky"
  }), product && __jsx("div", {
    className: "product-single-details"
  }, type == 1 && __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("h1", {
    className: "product-title"
  }, product.name), __jsx(_product_nav__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
    prev: prev,
    next: next
  }), __jsx("div", {
    className: "ratings-container"
  }, __jsx("div", {
    className: "product-ratings"
  }, __jsx("span", {
    className: "ratings",
    style: {
      width: `${20 * product.ratings}%`
    }
  }), __jsx("span", {
    className: "tooltiptext tooltip-top"
  }, product.ratings.toFixed(2))), __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z, {
    href: "#",
    className: "rating-link"
  }, "( ", product.reviews > 0 ? `${product.reviews} Reviews` : 'There are no reviews yet.', " )")), __jsx("hr", {
    className: "short-divider"
  })), __jsx("div", {
    className: "price-box"
  }, product && product.price[0] == product.price[1] ? __jsx("span", {
    className: "product-price"
  }, '$' + product.price[0].toFixed(2)) : product.variants.length > 0 ? __jsx("span", {
    className: "product-price"
  }, '$' + product.price[0].toFixed(2), " \u2013 ", '$' + product.price[1].toFixed(2)) : __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("span", {
    className: "old-price"
  }, '$' + product.price[1].toFixed(2)), __jsx("span", {
    className: "new-price"
  }, '$' + product.price[0].toFixed(2)))), __jsx("div", {
    className: "product-desc"
  }, __jsx("p", null, product.short_description)), product.until && product.until !== null && __jsx(_features_product_countdown__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z, {
    type: "1"
  }), __jsx("ul", {
    className: "single-info-list"
  }, product.sku ? __jsx("li", null, "SKU: ", __jsx("strong", null, product.sku)) : '', __jsx("li", null, "CATEGORY: ", product.categories.map((item, index) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), {
    key: `single-cat-${index}`
  }, __jsx("strong", null, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z, {
    href: {
      pathname: '/shop',
      query: {
        category: item.slug
      }
    },
    className: "category"
  }, item.name)), index < product.categories.length - 1 ? ', ' : ''))), product.tags && product.tags.length > 0 ? __jsx("li", null, "TAGs: ", product.tags.map((item, index) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), {
    key: `single-cat-${index}`
  }, __jsx("strong", null, __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z, {
    href: {
      pathname: '/shop',
      query: {
        tag: item.slug
      }
    },
    className: "category"
  }, item.name)), index < product.tags.length - 1 ? ', ' : ''))) : '')))), __jsx("div", {
    className: `col-lg-3 ${adClassTwo}`,
    style: {
      zIndex: '2'
    }
  }, __jsx((react_sticky_box__WEBPACK_IMPORTED_MODULE_5___default()), {
    className: "sticky-wrapper mb-3 mb-lg-0",
    offsetTop: 70
  }, __jsx("div", {
    className: "skel-pro skel-sticky"
  }), product && __jsx("div", {
    className: "product-single-details mb-lg-0"
  }, product.variants.length > 0 ? __jsx("div", {
    className: "product-filters-container custom-product-filters pt-0"
  }, attrs.colors.length > 0 ? __jsx("div", {
    className: `product-single-filter ${attrs.sizes.length > 0 ? '' : 'border-0'}`
  }, __jsx("label", null, "Color:"), __jsx("ul", {
    className: "config-size-list config-color-list config-filter-list"
  }, attrs.colors.map((item, index) => __jsx("li", {
    key: `filter-color-${index}`,
    className: `${item.name === color ? 'active' : ''} ${isDisabled('color', item.name) ? 'disabled' : ''}`
  }, item.thumb ? __jsx("a", {
    href: "#",
    className: "filter-thumb p-0",
    onClick: e => selectColor(item.name, e)
  }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__.LazyLoadImage, {
    src: process.env.NEXT_PUBLIC_ASSET_URI + item.thumb.url,
    alt: "product thumb",
    width: item.thumb.width,
    height: item.thumb.height
  })) : __jsx("a", {
    href: "#",
    className: "filter-color border-0",
    style: {
      backgroundColor: item.color
    },
    onClick: e => selectColor(item.name, e)
  }))))) : '', attrs.sizes.length > 0 ? __jsx("div", {
    className: `product-single-filter d-flex ${attrs.colors.length > 0 ? '' : 'border-0'}`
  }, __jsx("label", null, "Size:"), __jsx("ul", {
    className: "config-size-list"
  }, attrs.sizes.map((item, index) => __jsx("li", {
    key: `filter-size-${index}`,
    className: `${item.size === size ? 'active' : ''} ${isDisabled('size', item.size) ? 'disabled' : ''}`
  }, item.thumb ? __jsx("a", {
    href: "#",
    className: "filter-thumb p-0",
    onClick: e => selectSize(item.size, e)
  }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_4__.LazyLoadImage, {
    src: process.env.NEXT_PUBLIC_ASSET_URI + item.thumb.url,
    alt: "product thumb",
    width: item.thumb.width,
    height: item.thumb.height
  })) : __jsx("a", {
    href: "#",
    className: "d-flex align-items-center justify-content-center",
    onClick: e => selectSize(item.size, e)
  }, item.size))))) : '', __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), {
    collapsed: true
  }, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("button", {
    className: `d-none variation-toggle ${toggleState.toLowerCase()}`,
    onClick: onToggle
  }), __jsx("div", {
    className: "product-single-filter m-0",
    ref: setCollapsibleElement
  }, __jsx("label", null), __jsx("a", {
    className: "font1 text-uppercase clear-btn",
    href: "#",
    onClick: clearVariation
  }, "Clear"))))) : '', __jsx("div", {
    className: "product-action pb-0"
  }, product.variants.length ? __jsx((react_slide_toggle__WEBPACK_IMPORTED_MODULE_1___default()), {
    collapsed: true
  }, ({
    onToggle,
    setCollapsibleElement,
    toggleState
  }) => __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("button", {
    className: `d-none price-toggle ${toggleState.toLowerCase()}`,
    onClick: onToggle
  }), __jsx("div", {
    className: "price-box product-filtered-price m-0",
    ref: setCollapsibleElement
  }, variant && variant.id >= 0 && (variant.price ? __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, variant.sale_price ? __jsx("del", {
    className: "old-price"
  }, __jsx("span", null, "$", variant.sale_price.toFixed(2))) : '', __jsx("span", {
    className: "product-price"
  }, "$", variant && variant.price.toFixed(2))) : __jsx("span", {
    className: "product-stock pb-3 d-block"
  }, product.is_out_of_stock ? 'Out of Stock' : `${product.stock} in stock`))))) : '', __jsx("div", {
    className: "product-single-qty d-flex align-items-center mb-1 pb-2 mt-0"
  }, __jsx("label", {
    className: "mr-3 mb-0"
  }, "QTY:"), __jsx(_qty__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
    max: product.stock,
    value: qty,
    onChangeQty: changeQty
  })), __jsx("a", {
    href: "#",
    className: `btn btn-dark add-cart mr-2 ${attrs.sizes.length > 0 || attrs.colors.length > 0 ? 'disabled' : ''}`,
    title: "Add To Cart",
    onClick: onAddCartClick
  }, "Add to Cart"), __jsx("a", {
    href: "#",
    className: `btn-icon-wish add-wishlist mt-1 d-inline-flex justify-content-start ml-lg-0 ml-2 ${isInWishlist() ? 'added-wishlist' : ''}`,
    onClick: onWishlistClick,
    title: `${isInWishlist() ? 'Go to Wishlist' : 'Add to Wishlist'}`
  }, __jsx("i", {
    className: "icon-wishlist-2"
  }), __jsx("span", null, isInWishlist() ? 'Go to Wishlist' : 'Add to Wishlist'))), __jsx("div", {
    className: "product-single-share custom-product-single-share"
  }, __jsx("label", {
    className: "sr-only"
  }, "Share:"), __jsx("div", {
    className: "social-icons mt-0"
  }, __jsx("a", {
    href: "#",
    className: "social-icon social-facebook icon-facebook",
    title: "Facebook"
  }), __jsx("a", {
    href: "#",
    className: "social-icon social-twitter icon-twitter",
    title: "Twitter"
  }), __jsx("a", {
    href: "#",
    className: "social-icon social-linkedin fab fa-linkedin-in",
    title: "Linkedin"
  }), __jsx("a", {
    href: "#",
    className: "social-icon social-mail icon-mail-alt",
    title: "Mail"
  })))))));
}

const mapStateToProps = state => {
  return {
    wishlist: state.wishlist.list ? state.wishlist.list : []
  };
};

/* harmony default export */ __webpack_exports__["Z"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)(mapStateToProps, _objectSpread(_objectSpread({}, _store_wishlist__WEBPACK_IMPORTED_MODULE_6__/* .actions */ .Nw), _store_cart__WEBPACK_IMPORTED_MODULE_7__/* .actions */ .Nw))(ProductDetailFive));

/***/ })

};
;