exports.id = 8816;
exports.ids = [8816];
exports.modules = {

/***/ 5128:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);


function ShopBanner({
  adClass
}) {
  return __jsx("div", {
    className: `category-banner banner banner2 d-flex align-items-center justify-content-end ${adClass}`,
    style: {
      backgroundImage: 'url(images/home/banners/banner2.jpg)'
    }
  }, __jsx("div", {
    className: "container d-flex align-items-center justify-content-end"
  }, __jsx("div", {
    className: "banner-layer text-right pt-0"
  }, __jsx("h4", {
    className: "text-dark mb-0 pl-3 pr-3 pt-1 pb-1"
  }, "TOP ELECTRONIC", __jsx("br", null), "FOR GIFTS"))));
}

/* harmony default export */ __webpack_exports__["Z"] = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().memo(ShopBanner));

/***/ }),

/***/ 129:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "oQ": function() { return /* binding */ shopColors; },
/* harmony export */   "jU": function() { return /* binding */ shopSizes; }
/* harmony export */ });
/* unused harmony export shopBrands */
const shopColors = [{
  color: "#000",
  name: "black"
}, {
  color: "#0188cc",
  name: "blue"
}, {
  color: "#81d742",
  name: "green"
}, {
  color: "#6085a5",
  name: "indigo"
}, {
  color: "#ab6e6e",
  name: "red"
}];
const shopSizes = [{
  size: "XL",
  name: "Extra Large"
}, {
  size: "L",
  name: "Large"
}, {
  size: "M",
  name: "Medium"
}, {
  size: "S",
  name: "Small"
}];
const shopBrands = [{
  name: "Adidas",
  category: "adidas"
}, {
  name: "Asics",
  category: "asics"
}, {
  name: "Brooks",
  category: "brooks"
}, {
  name: "Nike",
  category: "nike"
}, {
  name: "Puma",
  category: "puma"
}];

/***/ })

};
;