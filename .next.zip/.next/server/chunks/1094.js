exports.id = 1094;
exports.ids = [1094];
exports.modules = {

/***/ 1094:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ blog_sidebar; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: external "react-sticky-box"
var external_react_sticky_box_ = __webpack_require__(9058);
var external_react_sticky_box_default = /*#__PURE__*/__webpack_require__.n(external_react_sticky_box_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./server/apollo.js + 1 modules
var apollo = __webpack_require__(7164);
// EXTERNAL MODULE: ./server/queries.js
var queries = __webpack_require__(4733);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
;// CONCATENATED MODULE: ./components/features/blogs/blog-type-two.jsx
var __jsx = (external_react_default()).createElement;
 // import { LazyLoadImage } from 'react-lazy-load-image-component';
// Import Custom Component


function BlogTypeTwo(props) {
  const {
    blog
  } = props;
  let date = new Date(blog.date);
  let monthArray = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return __jsx("li", {
    className: "media-with-lazy"
  }, __jsx("figure", {
    className: "post-media"
  }, __jsx(ALink/* default */.Z, {
    href: `/pages/blog/${blog.slug}`
  }, blog.picture ? __jsx((external_react_default()).Fragment, null, __jsx("div", {
    className: "lazy-overlay"
  }), __jsx(LazyLoadImage, {
    alt: "post_image",
    src: process.env.NEXT_PUBLIC_ASSET_URI + blog.picture[0].url,
    threshold: 500,
    width: "100%",
    height: "auto",
    effect: "blur"
  })) : "")), __jsx("div", {
    className: "post-info"
  }, __jsx(ALink/* default */.Z, {
    href: `/pages/blog/${blog.slug}`
  }, blog.title), __jsx("div", {
    className: "post-meta"
  }, ` ${monthArray[date.getMonth()]} ${date.getUTCDate() < 10 ? "0" + date.getUTCDate() : date.getUTCDate() + 1}, ${date.getYear() + 1900}`)));
}
;// CONCATENATED MODULE: ./components/partials/blog/blog-sidebar.jsx

var blog_sidebar_jsx = (external_react_default()).createElement;


 // Import Apollo Server and Query


 // Import Custom Component




function BlogSidebar() {
  const {
    data,
    loading,
    error
  } = (0,react_hooks_.useQuery)(queries/* GET_POST_SIDEBAR_DATA */.oG);
  const categories = data && data.postSidebarData.categories;
  const recent = data && data.postSidebarData.recent;
  const router = (0,router_.useRouter)();
  const query = router.query;

  if (error) {
    return blog_sidebar_jsx("div", null, error.message);
  }

  function sidebarToggle(e) {
    let body = document.querySelector('body');
    e.preventDefault();

    if (body.classList.contains('sidebar-opened')) {
      body.classList.remove('sidebar-opened');
    } else {
      body.classList.add('sidebar-opened');
    }
  }

  function closeSidebar() {
    document.querySelector('body').classList.contains('sidebar-opened') && document.querySelector('body').classList.remove('sidebar-opened');
  }

  return blog_sidebar_jsx((external_react_default()).Fragment, null, blog_sidebar_jsx("div", {
    className: "sidebar-overlay",
    onClick: closeSidebar
  }), blog_sidebar_jsx("div", {
    className: "sidebar-toggle custom-sidebar-toggle",
    onClick: e => sidebarToggle(e)
  }, blog_sidebar_jsx("i", {
    className: "fas fa-sliders-h"
  })), blog_sidebar_jsx("aside", {
    className: `sidebar mobile-sidebar col-lg-3 h-auto skeleton-body skel-shop-products ${loading ? '' : 'loaded'}`
  }, blog_sidebar_jsx((external_react_sticky_box_default()), {
    className: "sidebar-wrapper sticky-sidebar",
    offsetTop: 70
  }, loading ? blog_sidebar_jsx("div", {
    className: "skel-widget"
  }) : blog_sidebar_jsx("div", {
    className: "widget widget-categories"
  }, blog_sidebar_jsx("h4", {
    className: "widget-title"
  }, "Blog Categories"), blog_sidebar_jsx("ul", {
    className: "list"
  }, categories.map((item, index) => blog_sidebar_jsx("li", {
    key: ("Blog Category:", index),
    className: `${query.category === item.slug ? 'active' : ''}`
  }, blog_sidebar_jsx(ALink/* default */.Z, {
    href: {
      pathname: '/pages/blog',
      query: {
        category: item.slug
      }
    },
    scroll: false
  }, item.name))))), loading ? blog_sidebar_jsx("div", {
    className: "skel-widget"
  }) : blog_sidebar_jsx("div", {
    className: "widget widget-post"
  }, blog_sidebar_jsx("h4", {
    className: "widget-title"
  }, "Recent Posts"), blog_sidebar_jsx("ul", {
    className: "simple-post-list"
  }, recent.slice(0, 2).map((blog, index) => blog_sidebar_jsx(BlogTypeTwo, {
    blog: blog,
    key: "BlogTypeTwo" + index
  })))), loading ? blog_sidebar_jsx("div", {
    className: "skel-widget"
  }) : blog_sidebar_jsx("div", {
    className: "widget"
  }, blog_sidebar_jsx("h4", {
    className: "widget-title"
  }, "Tags"), blog_sidebar_jsx("div", {
    className: "tagcloud"
  }, blog_sidebar_jsx(ALink/* default */.Z, {
    href: "#"
  }, "ARTICLES"), blog_sidebar_jsx(ALink/* default */.Z, {
    href: "#"
  }, "CHAT"))))));
}

/* harmony default export */ var blog_sidebar = ((0,apollo/* default */.Z)({
  ssr: true
})(BlogSidebar));

/***/ })

};
;