exports.id = 5023;
exports.ids = [5023];
exports.modules = {

/***/ 4181:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7164);
/* harmony import */ var _server_queries__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4733);
/* harmony import */ var _features_products_product_three__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9915);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9905);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);


 // Import Apollo Server and Query


 // Import Custom Component

 // Import Keyframes



function ProductWidgetContainer(props) {
  const {
    adClass = ""
  } = props;
  const {
    data,
    loading,
    error
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_2__.useQuery)(_server_queries__WEBPACK_IMPORTED_MODULE_4__/* .GET_SPECIAL_PRODUCTS */ .yG, {
    variables: {
      featured: true,
      bestSelling: true,
      latest: true,
      topRated: true,
      count: 3
    }
  });
  const featured = data && data.specialProducts.featured;
  const bestSelling = data && data.specialProducts.bestSelling;
  const latest = data && data.specialProducts.latest;
  const topRated = data && data.specialProducts.topRated;

  if (error) {
    return __jsx("div", null, error.message);
  }

  return __jsx("section", {
    className: `product-widgets-container custom-widgets pb-2 skeleton-body skel-shop-products ${loading ? '' : 'loaded'} ${adClass}`
  }, __jsx("div", {
    className: "container"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-3 col-sm-6 pb-5 pb-lg-0"
  }, loading ? [0, 1, 2].map((item, index) => __jsx("div", {
    className: "skel-product-col skel-pro mb-2",
    key: "ProductThree" + index
  })) : __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("h4", {
    className: "section-sub-title ls-n-25 pb-2 mb-1"
  }, "Featured Products"), featured.slice(0, 3).map((product, index) => __jsx(_features_products_product_three__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    product: product,
    key: (`ProductThree`, index)
  })))), __jsx("div", {
    className: "col-lg-3 col-sm-6 pb-5 pb-lg-0"
  }, loading ? [0, 1, 2].map((item, index) => __jsx("div", {
    className: "skel-product-col skel-pro mb-2",
    key: "ProductThree" + index
  })) : __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("h4", {
    className: "section-sub-title ls-n-25 pb-2 mb-1"
  }, "Best Selling Products"), bestSelling.slice(0, 3).map((product, index) => __jsx(_features_products_product_three__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    product: product,
    key: (`ProductThree`, index)
  })))), __jsx("div", {
    className: "col-lg-3 col-sm-6 pb-5 pb-sm-0"
  }, loading ? [0, 1, 2].map((item, index) => __jsx("div", {
    className: "skel-product-col skel-pro mb-2",
    key: "ProductThree" + index
  })) : __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("h4", {
    className: "section-sub-title ls-n-25 pb-2 mb-1"
  }, "Latest Products"), latest.slice(0, 3).map((product, index) => __jsx(_features_products_product_three__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    product: product,
    key: (`ProductThree`, index)
  })))), __jsx("div", {
    className: "col-lg-3 col-sm-6 pb-0"
  }, loading ? [0, 1, 2].map((item, index) => __jsx("div", {
    className: "skel-product-col skel-pro mb-2",
    key: "ProductThree" + index
  })) : __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("h4", {
    className: "section-sub-title ls-n-25 pb-2 mb-1"
  }, "Top Rated Products"), topRated.slice(0, 3).map((product, index) => __jsx(_features_products_product_three__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    product: product,
    key: (`ProductThree`, index)
  })))))));
}

/* harmony default export */ __webpack_exports__["Z"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)({
  ssr: true
})(ProductWidgetContainer));

/***/ }),

/***/ 5655:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4138);
/* harmony import */ var _features_products_product_one__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4011);
/* harmony import */ var _utils_data_slider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8509);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//Import Custom Component

 //Import Settings



function RelatedProducts(props) {
  const {
    adClass = "",
    products = [],
    loading,
    isContainer = false
  } = props;

  const sliderOption = _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_3__/* .productSlider */ .sE), {}, {
    dots: true,
    nav: false,
    responsive: _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_3__/* .productSlider.responsive */ .sE.responsive), {}, {
      1200: {
        items: 5
      }
    })
  });

  return !loading && !products.length ? '' : __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("section", {
    className: `products-section  pt-0 pb-2 ${adClass}`,
    style: {
      marginTop: "100px"
    }
  }, __jsx("div", {
    className: isContainer ? 'container' : ''
  }, __jsx("h2", {
    className: "section-title pb-4"
  }, "Related Products"), !loading && !products.length ? __jsx("div", {
    className: "info-box with-icon"
  }, __jsx("p", null, "No products were found matching your selection.")) : __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    adClass: "products-slider dots-top dots-small",
    options: sliderOption
  }, loading ? [0, 1, 2, 3, 4].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-skel" + index
  })) : products.map((item, index) => __jsx("div", {
    className: `border-1 custom-border-remove ${index === 0 ? 'first-item' : ''}`,
    style: {
      borderColor: '#B9B9B9'
    },
    key: "product-one" + index
  }, __jsx(_features_products_product_one__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    adClass: "inner-quickview inner-icon",
    product: item
  })))))), __jsx("img", {
    src: "images\\brands\\deatail-banner.svg",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }));
}

/* harmony default export */ __webpack_exports__["Z"] = (RelatedProducts);

/***/ })

};
;