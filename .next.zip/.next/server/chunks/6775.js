exports.id = 6775;
exports.ids = [6775];
exports.modules = {

/***/ 6775:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ ProductMediaOne; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6302);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_image_lightbox__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7773);
/* harmony import */ var react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4138);
/* harmony import */ var _utils_data_slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8509);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);



 //Import Custom Component

 //Import Utils


function ProductMediaOne(props) {
  const {
    adClass = 'col-lg-5 col-md-6',
    product,
    parent = ".product-single-default"
  } = props;
  const {
    0: openLB,
    1: setOpenLB
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: photoIndex,
    1: setPhotoIndex
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: mediaRef,
    1: setMediaRef
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const {
    0: redraw,
    1: setRedraw
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const events = {
    onTranslate: function (e) {
      document.querySelector(`${parent} .prod-thumbnail .owl-dot.active`) && document.querySelector(`${parent} .prod-thumbnail .owl-dot.active`).classList.remove('active');
      let thumbs = document.querySelectorAll(`${parent} .prod-thumbnail .owl-item`);
      thumbs[e.item.index].querySelector('.owl-dot').classList.add('active');
    },
    onTranslated: function (e) {
      setPhotoIndex(e.item.index);
    }
  };
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (product) {
      setOpenLB(false);
      setPhotoIndex(0);
      setRedraw(true);
      mediaRef && mediaRef.current && mediaRef.current.goTo(0);
      document.querySelector(`${parent} .prod-thumbnail .owl-dot.active`) && document.querySelector(`${parent} .prod-thumbnail .owl-dot.active`) && document.querySelector(`${parent} .prod-thumbnail .owl-dot.active`).classList.remove('active');
      document.querySelector(`${parent} .prod-thumbnail .owl-dot`).classList.add('active');
    }
  }, [product]);

  function isSale() {
    var _product$variants;

    return (product === null || product === void 0 ? void 0 : product.price[0]) !== (product === null || product === void 0 ? void 0 : product.price[1]) && product.variants.length === 0 ? '-' + (100 * (product.price[1] - product.price[0]) / product.price[1]).toFixed(0) + '%' : product !== null && product !== void 0 && (_product$variants = product.variants) !== null && _product$variants !== void 0 && _product$variants.find(variant => variant.sale_price) ? "Sale" : false;
  }

  function openLightBox() {
    setOpenLB(true);
    setRedraw(false);
  }

  function closeLightBox() {
    setOpenLB(false);
    setRedraw(false);
  }

  function moveNextPhoto() {
    setPhotoIndex((photoIndex + 1) % product.large_pictures.length);
  }

  function movePrevPhoto() {
    setPhotoIndex((photoIndex + product.large_pictures.length - 1) % product.large_pictures.length);
  }

  function changeMediaIndex(index, e) {
    if (!e.currentTarget.classList.contains('active')) {
      let thumbs = e.currentTarget.closest('.prod-thumbnail');
      thumbs.querySelector('.owl-dot.active') && thumbs.querySelector('.owl-dot.active').classList.remove('active');
      e.currentTarget.classList.add('active');
    }

    mediaRef.current.goTo(index);
  }

  return __jsx("div", {
    className: `product-single-gallery ${adClass}`
  }, __jsx("div", {
    className: "skel-pro skel-magnifier"
  }), product && __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", null, __jsx("div", {
    className: "product-slider-container"
  }, __jsx("div", {
    className: "label-group"
  }, product.is_hot ? __jsx("div", {
    className: "product-label label-hot"
  }, "HOT") : '', isSale() ? __jsx("div", {
    className: "product-label label-sale"
  }, isSale()) : ''), __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    adClass: "product-single-carousel owl-carousel owl-theme show-nav-hover",
    options: _utils_data_slider__WEBPACK_IMPORTED_MODULE_5__/* .productSingleSlider */ .Kk,
    events: events,
    onChangeRef: setMediaRef,
    redraw: redraw
  }, product.images.map((item, index) => __jsx("div", {
    className: "product-item",
    key: `product-item-${index}`
  }, __jsx(react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2__.Magnifier, {
    style: {
      paddingTop: "100%",
      position: "relative",
      height: "auto !important"
    },
    imageSrc: item.fileURL,
    imageAlt: "product",
    mouseActivation: "hover",
    cursorStyleActive: "crosshair",
    dragToMove: false,
    className: "product-single-image"
  })))), __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    adClass: "prod-thumbnail owl-theme owl-dots",
    options: _utils_data_slider__WEBPACK_IMPORTED_MODULE_5__/* .prodThumbSlider */ .Kq
  }, product.images.map((item, index) => __jsx("div", {
    className: "owl-dot media-with-lazy",
    key: `owl-dot-${index}`,
    onClick: e => changeMediaIndex(index, e)
  }, __jsx("figure", {
    className: "mb-0",
    style: {
      paddingTop: "0px"
    }
  }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3__.LazyLoadImage, {
    src: item.fileURL,
    alt: "Thumbnail",
    width: "100%",
    height: "auto",
    className: "d-block",
    style: {
      height: "auto"
    }
  }))))))), openLB && __jsx((react_image_lightbox__WEBPACK_IMPORTED_MODULE_1___default()), {
    mainSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[photoIndex].url,
    prevSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[(photoIndex + product.large_pictures.length - 1) % product.large_pictures.length].url,
    nextSrc: process.env.NEXT_PUBLIC_ASSET_URI + product.large_pictures[(photoIndex + 1) % product.large_pictures.length].url,
    onCloseRequest: closeLightBox,
    onMoveNextRequest: moveNextPhoto,
    onMovePrevRequest: movePrevPhoto
  })));
}

/***/ })

};
;