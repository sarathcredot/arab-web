exports.id = 5580;
exports.ids = [5580];
exports.modules = {

/***/ 3576:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export default */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9997);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_modal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6155);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_2__);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);


 // Import Utils


const modalStyles = {
  content: {
    backgroundColor: "#fff",
    backgroundImage: "url(images/newsletter_popup_bg.jpg)",
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center",
    backgroundSize: "cover",
    top: "auto",
    outline: "none",
    width: "100%",
    marginLeft: "1rem",
    marginRight: "1rem"
  }
};
react_modal__WEBPACK_IMPORTED_MODULE_1___default().setAppElement("#__next");
function NewsletterModal() {
  const {
    0: modalIsOpen,
    1: setOpenNewsletter
  } = useState(false);
  const {
    0: doNotShow,
    1: setDoNotShow
  } = useState(false); // useEffect( () => {
  //     let timer;
  //     Cookie.get( "hideNewsletter" ) || ( timer = setTimeout( () => {
  //         setOpenNewsletter( true );
  //     }, 5000 ) );
  //     return () => {
  //         timer && clearTimeout( timer );
  //     };
  // }, [] );

  function closeModal() {
    if (!document.querySelector(".mfp-newsletter.open-modal")) return;
    document.querySelector(".mfp-newsletter.open-modal").classList.add("close-modal");
    setTimeout(() => {
      setOpenNewsletter(false);
      doNotShow && Cookie.set("hideNewsletter", "true", {
        expires: 7,
        path: router.basePath
      });
    }, 350);
  }

  function handleChange(event) {
    setDoNotShow(event.target.checked);
  }

  return __jsx(Modal, {
    isOpen: modalIsOpen,
    style: modalStyles,
    onRequestClose: closeModal,
    shouldReturnFocusAfterClose: false,
    className: "newsletter-popup bg-img",
    overlayClassName: "mfp-bg mfp-newsletter d-flex align-items-center justify-content-center open-modal"
  }, __jsx("div", {
    className: "newsletter-popup-content"
  }, __jsx("img", {
    src: "images/logo-black.png",
    alt: "Logo",
    className: "logo-newsletter"
  }), __jsx("h2", null, "Subscribe to newsletter"), __jsx("p", null, "Subscribe to the Porto mailing list to receive updates on new arrivals, special offers and our promotions."), __jsx("form", {
    action: "#"
  }, __jsx("div", {
    className: "input-group"
  }, __jsx("input", {
    type: "email",
    className: "form-control",
    id: "newsletter-email",
    name: "newsletter-email",
    placeholder: "Your email address",
    required: true
  }), __jsx("input", {
    type: "submit",
    className: "btn btn-primary",
    value: "Submit"
  }))), __jsx("div", {
    className: "newsletter-subscribe"
  }, __jsx("div", {
    className: "custom-control custom-checkbox"
  }, __jsx("input", {
    type: "checkbox",
    className: "custom-control-input",
    value: doNotShow,
    id: "show-again",
    onChange: handleChange
  }), __jsx("label", {
    htmlFor: "show-again",
    className: "custom-control-label"
  }, "Don't show this popup again")))), __jsx("button", {
    title: "Close (Esc)",
    type: "button",
    className: "mfp-close",
    onClick: closeModal
  }, "\xD7"));
}

/***/ }),

/***/ 8037:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9905);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);





function BannerSection({
  offer,
  sectionTwoData,
  sectionThreeData
}) {
  var _sectionTwoData$image, _sectionThreeData$ima, _sectionThreeData$ima2;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  return (// <Reveal keyframes={fadeInUpShorter} delay={200} duration={1000} triggerOnce>
    __jsx("div", {
      className: "banner-section"
    }, __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("div", {
      className: "row "
    }, __jsx("div", {
      className: "col-md-8 custom-web-banner2"
    }, __jsx("img", {
      src: (sectionTwoData === null || sectionTwoData === void 0 ? void 0 : sectionTwoData.images) && (sectionTwoData === null || sectionTwoData === void 0 ? void 0 : (_sectionTwoData$image = sectionTwoData.images[0]) === null || _sectionTwoData$image === void 0 ? void 0 : _sectionTwoData$image.fileURL),
      onClick: () => {
        var _sectionTwoData$butto;

        if (sectionTwoData !== null && sectionTwoData !== void 0 && sectionTwoData.buttons && (sectionTwoData === null || sectionTwoData === void 0 ? void 0 : sectionTwoData.buttons.length) > 0 && sectionTwoData !== null && sectionTwoData !== void 0 && (_sectionTwoData$butto = sectionTwoData.buttons[0]) !== null && _sectionTwoData$butto !== void 0 && _sectionTwoData$butto.redirectionURL) {
          var _sectionTwoData$butto2;

          router.push(sectionTwoData === null || sectionTwoData === void 0 ? void 0 : (_sectionTwoData$butto2 = sectionTwoData.buttons[0]) === null || _sectionTwoData$butto2 === void 0 ? void 0 : _sectionTwoData$butto2.redirectionURL);
        }
      },
      className: "bannerimg",
      style: {
        width: "100%",
        height: "470px",
        objectFit: "cover",
        cursor: "pointer"
      }
    })), __jsx("div", {
      className: "col-md-8 custom-responsive-banner2"
    }, __jsx("img", {
      src: "images/home/banners/homeimagemob2.jpg",
      className: "bannerimg",
      style: {
        width: "100%"
      }
    })), __jsx("div", {
      className: "col-md-4 custom-web-banner3"
    }, __jsx("img", {
      src: (sectionThreeData === null || sectionThreeData === void 0 ? void 0 : sectionThreeData.images) && (sectionThreeData === null || sectionThreeData === void 0 ? void 0 : (_sectionThreeData$ima = sectionThreeData.images[0]) === null || _sectionThreeData$ima === void 0 ? void 0 : _sectionThreeData$ima.fileURL),
      className: "bannerimg",
      style: {
        width: "100%",
        height: "470px",
        objectFit: "cover",
        cursor: "pointer"
      },
      onClick: () => {
        var _sectionThreeData$but;

        if (sectionThreeData !== null && sectionThreeData !== void 0 && sectionThreeData.buttons && (sectionThreeData === null || sectionThreeData === void 0 ? void 0 : sectionThreeData.buttons.length) > 0 && sectionThreeData !== null && sectionThreeData !== void 0 && (_sectionThreeData$but = sectionThreeData.buttons[0]) !== null && _sectionThreeData$but !== void 0 && _sectionThreeData$but.redirectionURL) {
          var _sectionThreeData$but2;

          router.push(sectionThreeData === null || sectionThreeData === void 0 ? void 0 : (_sectionThreeData$but2 = sectionThreeData.buttons[0]) === null || _sectionThreeData$but2 === void 0 ? void 0 : _sectionThreeData$but2.redirectionURL);
        }
      }
    })), __jsx("div", {
      className: "col-md-4 custom-responsive-banner3"
    }, __jsx("img", {
      src: (sectionThreeData === null || sectionThreeData === void 0 ? void 0 : sectionThreeData.images) && (sectionThreeData === null || sectionThreeData === void 0 ? void 0 : (_sectionThreeData$ima2 = sectionThreeData.images[0]) === null || _sectionThreeData$ima2 === void 0 ? void 0 : _sectionThreeData$ima2.fileURL),
      className: "bannerimg",
      style: {
        width: "100%",
        objectFit: "contain",
        cursor: "pointer"
      },
      onClick: () => {
        var _sectionThreeData$but3;

        if (sectionThreeData !== null && sectionThreeData !== void 0 && sectionThreeData.buttons && (sectionThreeData === null || sectionThreeData === void 0 ? void 0 : sectionThreeData.buttons.length) > 0 && sectionThreeData !== null && sectionThreeData !== void 0 && (_sectionThreeData$but3 = sectionThreeData.buttons[0]) !== null && _sectionThreeData$but3 !== void 0 && _sectionThreeData$but3.redirectionURL) {
          var _sectionThreeData$but4;

          router.push(sectionThreeData === null || sectionThreeData === void 0 ? void 0 : (_sectionThreeData$but4 = sectionThreeData.buttons[0]) === null || _sectionThreeData$but4 === void 0 ? void 0 : _sectionThreeData$but4.redirectionURL);
        }
      }
    }))), __jsx("div", {
      className: "row pt-4"
    }, __jsx("div", {
      className: "col-md-12"
    }, __jsx("img", {
      src: "images/home/banners/homeimage4.svg",
      className: "home_banner3",
      style: {
        width: "100%",
        height: "272px",
        objectFit: "cover",
        position: "relative",
        cursor: "pointer"
      }
    }), __jsx("div", {
      className: "app-downloadbtn"
    }, __jsx("div", null, __jsx("img", {
      src: "/images/bannerlogo.svg"
    })), __jsx("div", {
      style: {
        display: "flex",
        gap: "24px"
      }
    }, __jsx("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      width: "139",
      height: "42",
      viewBox: "0 0 139 42",
      fill: "none",
      style: {
        cursor: "pointer"
      }
    }, __jsx("path", {
      d: "M113.17 0.898521H9.79992C9.42198 0.898521 9.0513 0.898522 8.67578 0.900945C8.36082 0.903367 8.04829 0.908212 7.73092 0.913057C7.04044 0.920325 6.35239 0.980893 5.6716 1.09476C4.99081 1.21105 4.33425 1.42668 3.71888 1.73921C3.10351 2.05416 2.54386 2.4636 2.05447 2.95057C1.56508 3.43754 1.15564 3.99961 0.843107 4.6174C0.530576 5.23278 0.314955 5.89176 0.201087 6.57254C0.0872185 7.25333 0.0242253 7.93896 0.0169572 8.62944C0.00726625 8.94439 0.00484545 9.25935 0 9.57672V33.3267C0.00484545 33.6465 0.00726625 33.9542 0.0169572 34.274C0.0242253 34.962 0.0872185 35.6501 0.201087 36.3309C0.314955 37.0117 0.530576 37.6731 0.843107 38.2884C1.15564 38.9014 1.56266 39.4635 2.05447 39.9456C2.54144 40.435 3.10109 40.8444 3.71646 41.1569C4.33183 41.4695 4.99081 41.6875 5.66918 41.8062C6.34996 41.9177 7.03801 41.9782 7.72849 41.9879C8.04587 41.9952 8.3584 41.9976 8.67336 41.9976C9.04888 42.0001 9.42198 42.0001 9.7975 42.0001H128.976C129.344 42.0001 129.72 42.0001 130.091 41.9976C130.403 41.9976 130.725 41.9928 131.038 41.9855C131.726 41.9783 132.414 41.9177 133.092 41.8038C133.776 41.6875 134.435 41.467 135.052 41.1545C135.668 40.842 136.23 40.4325 136.714 39.9432C137.204 39.4586 137.613 38.8965 137.928 38.286C138.238 37.6706 138.454 37.0092 138.565 36.3285C138.679 35.6477 138.742 34.962 138.757 34.2716C138.762 33.9518 138.762 33.6441 138.762 33.3243C138.769 32.9512 138.769 32.5805 138.769 32.2001V10.696C138.769 10.3205 138.769 9.9474 138.762 9.5743C138.762 9.25935 138.762 8.94439 138.757 8.62701C138.745 7.93896 138.682 7.25091 138.565 6.57012C138.454 5.88934 138.238 5.23035 137.928 4.61498C137.293 3.37939 136.288 2.37154 135.052 1.73678C134.435 1.42425 133.773 1.20863 133.092 1.09234C132.412 0.978472 131.726 0.917904 131.038 0.910636C130.725 0.90579 130.403 0.898521 130.091 0.896098C129.722 0.893675 129.347 0.893677 128.976 0.893677H113.17V0.898521Z",
      fill: "#CCCED3"
    }), __jsx("path", {
      d: "M8.67976 41.1013C8.36723 41.1013 8.06196 41.0964 7.75186 41.0916C7.10741 41.0819 6.46539 41.0262 5.83063 40.9244C5.23707 40.8227 4.6653 40.6313 4.12746 40.3599C3.59688 40.091 3.11234 39.7397 2.69321 39.3157C2.26681 38.8966 1.91309 38.412 1.64417 37.8815C1.37282 37.346 1.18385 36.7719 1.08694 36.1783C0.982761 35.5411 0.924616 34.8967 0.917348 34.2522C0.91008 34.0366 0.900391 33.3146 0.900391 33.3146V9.57919C0.900391 9.57919 0.91008 8.86691 0.917348 8.66098C0.924616 8.01653 0.982761 7.37209 1.08694 6.73734C1.18385 6.14377 1.37282 5.56716 1.64659 5.02932C1.91551 4.49632 2.26681 4.01177 2.69078 3.59264C3.11234 3.16866 3.59931 2.81494 4.12988 2.54118C4.66531 2.27225 5.23707 2.08328 5.82821 1.98395C6.46539 1.87977 7.10983 1.82163 7.75428 1.81436L8.68218 1.80225H130.087L131.025 1.81678C131.665 1.82405 132.304 1.87977 132.934 1.98395C133.53 2.0857 134.109 2.27468 134.652 2.54844C135.718 3.0984 136.585 3.96816 137.133 5.03416C137.399 5.56958 137.586 6.13892 137.683 6.72764C137.789 7.36967 137.85 8.01653 137.862 8.66582C137.864 8.95655 137.864 9.26908 137.864 9.58161C137.872 9.96683 137.872 10.3327 137.872 10.7033V32.2074C137.872 32.5805 137.872 32.9439 137.864 33.3122C137.864 33.6465 137.864 33.9518 137.859 34.2668C137.847 34.9039 137.789 35.5411 137.685 36.171C137.591 36.767 137.402 37.346 137.13 37.8863C136.859 38.412 136.508 38.8942 136.086 39.3109C135.667 39.7348 135.18 40.091 134.647 40.3623C134.107 40.6361 133.53 40.8275 132.934 40.9268C132.299 41.0286 131.657 41.0867 131.013 41.094C130.712 41.1013 130.397 41.1061 130.09 41.1061L128.975 41.1085L8.67976 41.1013Z",
      fill: "#FBFBFB"
    }), __jsx("path", {
      d: "M33.5937 21.3367C33.618 19.5245 34.5677 17.8504 36.1109 16.9007C35.1322 15.5028 33.5526 14.6476 31.847 14.5943C30.0517 14.4053 28.3146 15.6675 27.3988 15.6675C26.4661 15.6675 25.0585 14.6112 23.5443 14.6427C21.5504 14.7081 19.7358 15.8153 18.7642 17.5573C16.6977 21.1356 18.2385 26.3929 20.2179 29.2857C21.2088 30.703 22.3668 32.2826 23.881 32.2269C25.3637 32.1663 25.9161 31.282 27.7065 31.282C29.4775 31.282 29.9984 32.2269 31.5441 32.1905C33.1334 32.1663 34.1364 30.7684 35.091 29.339C35.8033 28.3287 36.3508 27.2142 36.7142 26.0344C34.8245 25.2373 33.5962 23.3863 33.5937 21.3367ZM30.6768 12.6924C31.5441 11.6507 31.9705 10.3133 31.8688 8.96143C30.5435 9.09952 29.3201 9.73428 28.4406 10.7349C27.5733 11.7233 27.1323 13.0146 27.2196 14.3253C28.5593 14.3399 29.8337 13.7366 30.6768 12.6924Z",
      fill: "#010202"
    }), __jsx("path", {
      d: "M51.3775 28.7866H46.5151L45.345 32.2341H43.2856L47.8912 19.4737H50.0305L54.6385 32.2341H52.5429L51.3775 28.7866ZM47.0166 27.1949H50.8712L48.9694 21.5984H48.9161C48.9185 21.5984 47.0166 27.1949 47.0166 27.1949ZM64.5887 27.5825C64.5887 30.4728 63.0405 32.3311 60.705 32.3311C59.4985 32.394 58.3623 31.7617 57.7784 30.703H57.7348V35.311H55.8257V22.9309H57.6742V24.479H57.7081C58.3162 23.4275 59.4549 22.7952 60.6711 22.834C63.0333 22.8364 64.5887 24.7019 64.5887 27.5825ZM62.6263 27.5825C62.6263 25.7001 61.6523 24.462 60.1672 24.462C58.7087 24.462 57.7275 25.7267 57.7275 27.5849C57.7275 29.4601 58.7087 30.7151 60.1672 30.7151C61.6523 30.7151 62.6263 29.4844 62.6263 27.5825ZM74.8271 27.5825C74.8271 30.4728 73.279 32.3311 70.9435 32.3311C69.7369 32.394 68.6007 31.7617 68.0168 30.703H67.9732V35.311H66.0641V22.9309H67.9126V24.479H67.9466C68.5571 23.4275 69.6933 22.7952 70.9096 22.834C73.2717 22.8364 74.8271 24.7019 74.8271 27.5825ZM72.8647 27.5825C72.8647 25.7001 71.8908 24.462 70.4056 24.462C68.9471 24.462 67.9659 25.7267 67.9659 27.5849C67.9659 29.4601 68.9471 30.7151 70.4056 30.7151C71.8908 30.7151 72.8647 29.4844 72.8647 27.5825ZM81.5938 28.68C81.7367 29.9447 82.965 30.7757 84.644 30.7757C86.2527 30.7757 87.4107 29.9447 87.4107 28.8036C87.4107 27.8127 86.713 27.2215 85.0583 26.8145L83.4035 26.4172C81.0608 25.8503 79.973 24.7552 79.973 22.9769C79.973 20.7747 81.8918 19.2629 84.6149 19.2629C87.3114 19.2629 89.1599 20.7747 89.2229 22.9769H87.2944C87.1782 21.7026 86.1267 20.9346 84.5883 20.9346C83.0498 20.9346 81.9984 21.7123 81.9984 22.8437C81.9984 23.7473 82.6719 24.2755 84.3169 24.6825L85.7221 25.029C88.3411 25.6468 89.4264 26.7006 89.4264 28.5661C89.4264 30.9525 87.5246 32.4498 84.501 32.4498C81.6713 32.4498 79.7598 30.9889 79.6362 28.6824C79.6386 28.68 81.5938 28.68 81.5938 28.68ZM93.5523 20.731V22.9333H95.3209V24.4451H93.5523V29.574C93.5523 30.3711 93.9061 30.7417 94.6837 30.7417C94.8945 30.7369 95.1029 30.7224 95.3112 30.6981V32.2002C94.9599 32.2656 94.6062 32.2947 94.2501 32.2899C92.3676 32.2899 91.6311 31.5824 91.6311 29.7799V24.4475H90.2768V22.9357H91.6311V20.731H93.5523ZM96.3433 27.5825C96.3433 24.6559 98.0683 22.817 100.755 22.817C103.452 22.817 105.169 24.6559 105.169 27.5825C105.169 30.5189 103.461 32.348 100.755 32.348C98.0513 32.3504 96.3433 30.5189 96.3433 27.5825ZM103.224 27.5825C103.224 25.5741 102.303 24.3894 100.755 24.3894C99.2094 24.3894 98.2888 25.5838 98.2888 27.5825C98.2888 29.5982 99.2094 30.7732 100.755 30.7732C102.303 30.7757 103.224 29.6006 103.224 27.5825ZM106.744 22.9309H108.566V24.5129H108.61C108.864 23.493 109.797 22.7928 110.846 22.8316C111.066 22.8316 111.287 22.8558 111.5 22.9018V24.6874C111.221 24.6026 110.933 24.5638 110.642 24.5711C110.08 24.5493 109.537 24.7722 109.155 25.184C108.772 25.5959 108.588 26.1531 108.653 26.7128V32.2293H106.742V22.9309H106.744ZM120.306 29.5013C120.05 31.19 118.405 32.348 116.302 32.348C113.596 32.348 111.917 30.5358 111.917 27.6261C111.917 24.7092 113.605 22.8146 116.222 22.8146C118.795 22.8146 120.413 24.5832 120.413 27.4032V28.0574H113.843V28.1737C113.782 28.8666 114.02 29.5522 114.499 30.0561C114.979 30.56 115.65 30.8338 116.345 30.8096C117.273 30.8968 118.145 30.3638 118.494 29.5013H120.306ZM113.85 26.7249H118.502C118.535 26.1022 118.31 25.4941 117.877 25.0459C117.443 24.5977 116.842 24.3506 116.219 24.3627C115.592 24.3579 114.989 24.605 114.543 25.0508C114.099 25.4941 113.848 26.0974 113.85 26.7249Z",
      fill: "#010202"
    }), __jsx("path", {
      d: "M46.7739 9.86992C47.5855 9.81177 48.3778 10.1195 48.9374 10.7106C49.4971 11.2993 49.7612 12.1085 49.6594 12.9153C49.6594 14.8753 48.6007 15.9994 46.7739 15.9994H44.5596V9.8675H46.7739V9.86992ZM45.5117 15.1345H46.6673C47.2464 15.1684 47.8109 14.9407 48.2033 14.5143C48.5958 14.0879 48.7751 13.504 48.6903 12.9298C48.7678 12.3581 48.5886 11.7814 48.1961 11.3575C47.8036 10.9335 47.2439 10.7058 46.6673 10.7373H45.5117V15.1345ZM50.7327 13.6857C50.6527 12.8547 51.05 12.0528 51.7575 11.6143C52.4649 11.1733 53.3613 11.1733 54.0688 11.6143C54.7762 12.0528 55.1735 12.8547 55.0936 13.6857C55.1735 14.5167 54.7786 15.3186 54.0688 15.7596C53.3613 16.2005 52.4649 16.2005 51.7551 15.7596C51.05 15.321 50.6527 14.5167 50.7327 13.6857ZM54.1584 13.6857C54.1584 12.6827 53.7078 12.0964 52.918 12.0964C52.1233 12.0964 51.6775 12.6827 51.6775 13.6857C51.6775 14.6984 52.1233 15.2799 52.918 15.2799C53.7078 15.2799 54.1584 14.6936 54.1584 13.6857ZM60.8984 16.0018H59.9511L58.9942 12.5955H58.9215L57.9693 16.0018H57.0318L55.755 11.3744H56.6805L57.509 14.9043H57.5769L58.5266 11.3744H59.4036L60.3533 14.9043H60.426L61.2497 11.3744H62.1631L60.8984 16.0018ZM63.2412 11.3744H64.1206V12.1085H64.1885C64.4259 11.5682 64.9807 11.2363 65.5694 11.2848C66.0249 11.2509 66.4731 11.4253 66.7832 11.7596C67.0958 12.094 67.2387 12.5519 67.1709 13.0049V15.9994H66.2575V13.2327C66.2575 12.4889 65.9353 12.1206 65.2593 12.1206C64.9492 12.1061 64.6488 12.2272 64.438 12.4525C64.2248 12.6779 64.1231 12.9855 64.1546 13.2932V15.9994H63.2412V11.3744ZM68.6269 9.56708H69.5403V15.9994H68.6269V9.56708ZM70.8074 13.6857C70.7274 12.8547 71.1247 12.0528 71.8346 11.6143C72.542 11.1733 73.4384 11.1733 74.1459 11.6143C74.8533 12.0528 75.2531 12.8547 75.1731 13.6857C75.2531 14.5167 74.8582 15.3186 74.1483 15.7596C73.4384 16.2005 72.542 16.2005 71.8346 15.7596C71.1247 15.321 70.7274 14.5167 70.8074 13.6857ZM74.2331 13.6857C74.2331 12.6827 73.7825 12.0964 72.9927 12.0964C72.198 12.0964 71.7522 12.6827 71.7522 13.6857C71.7522 14.6984 72.198 15.2799 72.9927 15.2799C73.7825 15.2799 74.2331 14.6936 74.2331 13.6857ZM76.1349 14.6936C76.1349 13.8601 76.7552 13.3804 77.8551 13.3126L79.1076 13.2399V12.8402C79.1076 12.3508 78.7854 12.077 78.1603 12.077C77.6516 12.077 77.2979 12.2636 77.1961 12.5906H76.3118C76.4039 11.796 77.1525 11.2872 78.2015 11.2872C79.362 11.2872 80.0161 11.8638 80.0161 12.8426V16.0043H79.1367V15.3525H79.064C78.766 15.8274 78.233 16.106 77.6734 16.0794C77.2809 16.1205 76.8884 15.9921 76.5953 15.7281C76.3045 15.464 76.1349 15.0885 76.1349 14.6936ZM79.1076 14.2987V13.911L77.9762 13.9837C77.339 14.0273 77.0507 14.2429 77.0507 14.6524C77.0507 15.0691 77.4117 15.3114 77.9084 15.3114C78.2015 15.3404 78.4971 15.2508 78.7224 15.0594C78.9501 14.8656 79.0882 14.5918 79.1076 14.2987ZM81.2178 13.6857C81.2178 12.2224 81.9689 11.2969 83.139 11.2969C83.7278 11.2703 84.2826 11.5852 84.5588 12.1085H84.6266V9.56708H85.54V16.0018H84.6654V15.2702H84.5927C84.2971 15.7886 83.735 16.1012 83.139 16.0769C81.9616 16.0769 81.2178 15.1515 81.2178 13.6857ZM82.1603 13.6857C82.1603 14.6669 82.623 15.2581 83.3958 15.2581C84.1663 15.2581 84.6411 14.6596 84.6411 13.6906C84.6411 12.7263 84.159 12.1182 83.3958 12.1182C82.6303 12.1182 82.1603 12.7118 82.1603 13.6857ZM89.317 13.6857C89.237 12.8547 89.6344 12.0528 90.3418 11.6143C91.0492 11.1733 91.9456 11.1733 92.6531 11.6143C93.3605 12.0528 93.7578 12.8547 93.6779 13.6857C93.7578 14.5167 93.3629 15.3186 92.6531 15.7596C91.9456 16.2005 91.0492 16.2005 90.3394 15.7596C89.6319 15.321 89.2346 14.5167 89.317 13.6857ZM92.7427 13.6857C92.7427 12.6827 92.2921 12.0964 91.5023 12.0964C90.7076 12.0964 90.2618 12.6827 90.2618 13.6857C90.2618 14.6984 90.7076 15.2799 91.5023 15.2799C92.2921 15.2799 92.7427 14.6936 92.7427 13.6857ZM94.9062 11.3744H95.7857V12.1085H95.8535C96.0909 11.5682 96.6457 11.2363 97.2345 11.2848C97.6899 11.2509 98.1381 11.4253 98.4482 11.7596C98.7608 12.094 98.9013 12.5519 98.8359 13.0049V15.9994H97.9225V13.2327C97.9225 12.4889 97.6003 12.1206 96.9243 12.1206C96.6142 12.1061 96.3162 12.2272 96.103 12.4525C95.8923 12.6779 95.7881 12.9855 95.822 13.2932V15.9994H94.9086V11.3744H94.9062ZM103.996 10.2236V11.3962H104.999V12.1642H103.996V14.5434C103.996 15.0279 104.195 15.2411 104.65 15.2411C104.767 15.2411 104.883 15.2338 104.999 15.2193V15.98C104.835 16.0091 104.67 16.0261 104.503 16.0285C103.488 16.0285 103.083 15.6699 103.083 14.7784V12.1642H102.346V11.3962H103.08V10.2236H103.996ZM106.245 9.56708H107.151V12.1158H107.223C107.47 11.5707 108.035 11.2388 108.633 11.2872C109.086 11.263 109.527 11.4423 109.837 11.7742C110.145 12.1085 110.288 12.5616 110.228 13.0122V15.9994H109.314V13.2351C109.314 12.4962 108.97 12.1206 108.326 12.1206C108.008 12.094 107.696 12.2103 107.47 12.438C107.245 12.6633 107.134 12.9783 107.16 13.2957V15.9994H106.247V9.56708H106.245ZM115.55 14.7517C115.293 15.6239 114.45 16.1884 113.544 16.0891C112.929 16.106 112.335 15.8492 111.923 15.3889C111.512 14.9286 111.323 14.3108 111.407 13.7002C111.325 13.0873 111.514 12.4671 111.923 12.0043C112.333 11.5392 112.922 11.2775 113.542 11.2824C114.828 11.2824 115.606 12.1618 115.606 13.6155V13.9328H112.34V13.9837C112.311 14.3277 112.43 14.6669 112.662 14.9189C112.897 15.1708 113.227 15.3138 113.571 15.3089C114.019 15.3622 114.453 15.1418 114.673 14.7469L115.55 14.7517ZM112.34 13.2617H114.678C114.7 12.9468 114.591 12.6391 114.373 12.4114C114.157 12.1812 113.852 12.0576 113.537 12.0625C113.217 12.0576 112.909 12.1836 112.684 12.4114C112.459 12.6342 112.335 12.9419 112.34 13.2617Z",
      fill: "#010202"
    })), __jsx("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      width: "139",
      height: "42",
      viewBox: "0 0 139 42",
      fill: "none",
      style: {
        cursor: "pointer"
      }
    }, __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M133.794 41.1015H5.35344C2.52854 41.1015 0.214844 38.7902 0.214844 35.9629V5.1386C0.214844 2.3137 2.52612 0 5.35344 0H133.794C136.619 0 138.933 2.31128 138.933 5.1386V35.9654C138.933 38.7902 136.622 41.1015 133.794 41.1015Z",
      fill: "#FBFBFB"
    }), __jsx("path", {
      d: "M58.1112 31.6408C60.5344 31.6408 62.4987 29.684 62.4987 27.2702C62.4987 24.8564 60.5344 22.8996 58.1112 22.8996C55.688 22.8996 53.7236 24.8564 53.7236 27.2702C53.7236 29.684 55.688 31.6408 58.1112 31.6408Z",
      fill: "black"
    }), __jsx("path", {
      d: "M67.6791 31.6408C70.1022 31.6408 72.0666 29.684 72.0666 27.2702C72.0666 24.8564 70.1022 22.8996 67.6791 22.8996C65.2559 22.8996 63.2915 24.8564 63.2915 27.2702C63.2915 29.684 65.2559 31.6408 67.6791 31.6408Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M133.794 0.00238037H5.35344C2.52854 0.00238037 0.214844 2.31366 0.214844 5.14098V35.9677C0.214844 38.7926 2.52612 41.1063 5.35344 41.1063H133.794C136.619 41.1063 138.933 38.795 138.933 35.9677V5.13855C138.933 2.31366 136.622 0.00238037 133.794 0.00238037ZM133.794 0.82368C136.173 0.82368 138.109 2.75944 138.109 5.13855V35.9653C138.109 38.3444 136.173 40.2802 133.794 40.2802H5.35344C2.97433 40.2802 1.03857 38.3444 1.03857 35.9653V5.13855C1.03857 2.75944 2.97433 0.82368 5.35344 0.82368H133.794Z",
      fill: "#CCCED3"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M48.9407 10.5268C48.9407 11.3893 48.6863 12.0725 48.1751 12.5861C47.5937 13.1942 46.8402 13.497 45.9099 13.497C45.0207 13.497 44.2624 13.1893 43.6422 12.5716C43.0171 11.9562 42.707 11.1882 42.707 10.2772C42.707 9.36387 43.0171 8.59829 43.6422 7.98292C44.2624 7.36754 45.0207 7.05743 45.9099 7.05743C46.3508 7.05743 46.7748 7.14465 47.1745 7.31424C47.5767 7.48626 47.8989 7.71641 48.1388 8.0023L47.5961 8.54498C47.1891 8.05802 46.627 7.81332 45.9075 7.81332C45.2582 7.81332 44.6985 8.04106 44.2237 8.49895C43.7488 8.95685 43.5138 9.548 43.5138 10.2772C43.5138 11.0065 43.7512 11.5976 44.2237 12.0555C44.6961 12.5134 45.2582 12.7387 45.9075 12.7387C46.5955 12.7387 47.1697 12.5086 47.63 12.0507C47.928 11.7502 48.1 11.336 48.1461 10.803H45.9075V10.0616H48.8947C48.9262 10.2215 48.9407 10.3766 48.9407 10.5268Z",
      fill: "#010202"
    }), __jsx("path", {
      d: "M48.9407 10.5268C48.9407 11.3893 48.6863 12.0725 48.1751 12.5861C47.5937 13.1942 46.8402 13.497 45.9099 13.497C45.0207 13.497 44.2624 13.1893 43.6422 12.5716C43.0171 11.9562 42.707 11.1882 42.707 10.2772C42.707 9.36387 43.0171 8.59829 43.6422 7.98292C44.2624 7.36754 45.0207 7.05743 45.9099 7.05743C46.3508 7.05743 46.7748 7.14465 47.1745 7.31424C47.5767 7.48626 47.8989 7.71641 48.1388 8.0023L47.5961 8.54498C47.1891 8.05802 46.627 7.81332 45.9075 7.81332C45.2582 7.81332 44.6985 8.04106 44.2237 8.49895C43.7488 8.95685 43.5138 9.548 43.5138 10.2772C43.5138 11.0065 43.7512 11.5976 44.2237 12.0555C44.6961 12.5134 45.2582 12.7387 45.9075 12.7387C46.5955 12.7387 47.1697 12.5086 47.63 12.0507C47.928 11.7502 48.1 11.336 48.1461 10.803H45.9075V10.0616H48.8947C48.9262 10.2215 48.9407 10.3766 48.9407 10.5268Z",
      stroke: "#010202",
      "stroke-width": "0.2"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M53.6758 7.95138H50.8679V9.90652H53.3972V10.6479H50.8679V12.603H53.6758V13.3613H50.0757V7.1955H53.6758V7.95138Z",
      fill: "#010202"
    }), __jsx("path", {
      d: "M53.6758 7.95138H50.8679V9.90652H53.3972V10.6479H50.8679V12.603H53.6758V13.3613H50.0757V7.1955H53.6758V7.95138Z",
      stroke: "#010202",
      "stroke-width": "0.2"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M57.0167 13.3589H56.2245V7.95143H54.502V7.19312H58.7393V7.95143H57.0167V13.3589Z",
      fill: "#010202"
    }), __jsx("path", {
      d: "M57.0167 13.3589H56.2245V7.95143H54.502V7.19312H58.7393V7.95143H57.0167V13.3589Z",
      stroke: "#010202",
      "stroke-width": "0.2"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M61.8047 13.3589H62.5969V7.19312H61.8047V13.3589Z",
      fill: "#010202"
    }), __jsx("path", {
      d: "M61.8047 13.3589H62.5969V7.19312H61.8047V13.3589Z",
      stroke: "#010202",
      "stroke-width": "0.2"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M66.11 13.3589H65.3178V7.95143H63.5952V7.19312H67.8326V7.95143H66.11V13.3589Z",
      fill: "#010202"
    }), __jsx("path", {
      d: "M66.11 13.3589H65.3178V7.95143H63.5952V7.19312H67.8326V7.95143H66.11V13.3589Z",
      stroke: "#010202",
      "stroke-width": "0.2"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M71.9157 12.0458C72.3712 12.5085 72.9309 12.7387 73.5923 12.7387C74.2512 12.7387 74.8085 12.5085 75.2664 12.0458C75.7218 11.5831 75.952 10.9943 75.952 10.2772C75.952 9.56009 75.7218 8.96895 75.2664 8.50863C74.8109 8.04589 74.2512 7.81573 73.5923 7.81573C72.9309 7.81573 72.3736 8.04831 71.9182 8.50863C71.4627 8.96895 71.2325 9.56009 71.2325 10.2772C71.2325 10.9943 71.4603 11.5831 71.9157 12.0458ZM75.8527 12.5618C75.2446 13.1869 74.4935 13.497 73.5923 13.497C72.691 13.497 71.9375 13.1869 71.3319 12.5618C70.7262 11.9392 70.4233 11.1785 70.4233 10.2772C70.4233 9.37597 70.7262 8.61281 71.3319 7.99017C71.9375 7.36753 72.6886 7.05499 73.5898 7.05499C74.4862 7.05499 75.2373 7.36752 75.8454 7.99259C76.4535 8.61765 76.7563 9.37839 76.7563 10.2748C76.7612 11.1785 76.4583 11.9392 75.8527 12.5618Z",
      fill: "#010202"
    }), __jsx("path", {
      d: "M71.9157 12.0458C72.3712 12.5085 72.9309 12.7387 73.5923 12.7387C74.2512 12.7387 74.8085 12.5085 75.2664 12.0458C75.7218 11.5831 75.952 10.9943 75.952 10.2772C75.952 9.56009 75.7218 8.96895 75.2664 8.50863C74.8109 8.04589 74.2512 7.81573 73.5923 7.81573C72.9309 7.81573 72.3736 8.04831 71.9182 8.50863C71.4627 8.96895 71.2325 9.56009 71.2325 10.2772C71.2325 10.9943 71.4603 11.5831 71.9157 12.0458ZM75.8527 12.5618C75.2446 13.1869 74.4935 13.497 73.5923 13.497C72.691 13.497 71.9375 13.1869 71.3319 12.5618C70.7262 11.9392 70.4233 11.1785 70.4233 10.2772C70.4233 9.37597 70.7262 8.61281 71.3319 7.99017C71.9375 7.36753 72.6886 7.05499 73.5898 7.05499C74.4862 7.05499 75.2373 7.36752 75.8454 7.99259C76.4535 8.61765 76.7563 9.37839 76.7563 10.2748C76.7612 11.1785 76.4583 11.9392 75.8527 12.5618Z",
      stroke: "#010202",
      "stroke-width": "0.2"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M77.8721 13.3589V7.19312H78.8363L81.8332 11.9877H81.8671L81.8332 10.8005V7.19312H82.6279V13.3589H81.7993L78.6643 8.32937H78.6304L78.6643 9.51893V13.3589H77.8721Z",
      fill: "#010202"
    }), __jsx("path", {
      d: "M77.8721 13.3589V7.19312H78.8363L81.8332 11.9877H81.8671L81.8332 10.8005V7.19312H82.6279V13.3589H81.7993L78.6643 8.32937H78.6304L78.6643 9.51893V13.3589H77.8721Z",
      stroke: "#010202",
      "stroke-width": "0.2"
    }), __jsx("path", {
      d: "M109.467 18.5314H107.55V31.3767H109.467V18.5314Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M124.822 23.1589L122.625 28.7287H122.557L120.277 23.1589H118.21L121.631 30.9407L119.681 35.2725H121.68L126.952 23.1589H124.822Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M114.178 22.8777C112.79 22.8777 111.353 23.4883 110.757 24.845L112.458 25.5549C112.821 24.845 113.5 24.6124 114.209 24.6124C115.2 24.6124 116.208 25.2084 116.225 26.2647V26.398C115.876 26.1993 115.135 25.9037 114.226 25.9037C112.39 25.9037 110.524 26.9116 110.524 28.794C110.524 30.5142 112.029 31.6214 113.715 31.6214C115.002 31.6214 115.714 31.0423 116.16 30.364H116.225V31.3549H118.076V26.4295C118.078 24.1497 116.375 22.8777 114.178 22.8777Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M102.279 18.5314H97.6855V31.3767H99.6019V26.5095H102.279C104.404 26.5095 106.492 24.971 106.492 22.5192C106.492 20.0699 104.404 18.5314 102.279 18.5314Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M79.427 23.876H79.3616C78.9303 23.3624 78.1018 22.8972 77.0624 22.8972C74.8771 22.8972 72.8735 24.8184 72.8735 27.2848C72.8735 29.7341 74.8771 31.6384 77.0624 31.6384C78.1042 31.6384 78.9328 31.1757 79.3616 30.6475H79.427V31.275C79.427 32.9467 78.533 33.8407 77.0939 33.8407C75.9189 33.8407 75.1897 32.9976 74.8917 32.2853L73.22 32.9806C73.6997 34.1387 74.974 35.5632 77.0939 35.5632C79.3471 35.5632 81.2489 34.238 81.2489 31.0109V23.1637H79.427V23.876Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M82.5742 31.3767H84.4954V18.5314H82.5742V31.3767Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M93.2846 25.6809C92.9212 24.7045 91.8116 22.8996 89.5439 22.8996C87.2932 22.8996 85.4229 24.673 85.4229 27.2702C85.4229 29.7196 87.2762 31.6408 89.7595 31.6408C91.7631 31.6408 92.9212 30.4149 93.4033 29.7026L91.9133 28.7093C91.4143 29.4385 90.7383 29.9182 89.7595 29.9182C88.7832 29.9182 88.0878 29.47 87.6421 28.593L93.4857 26.1751L93.2846 25.6809Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M46.7301 24.2419V26.0952H51.1685C51.0353 27.1394 50.6864 27.9002 50.1583 28.4283C49.5114 29.0752 48.5011 29.785 46.7301 29.785C43.9973 29.785 41.8629 27.5828 41.8629 24.8524C41.8629 22.122 43.9997 19.9197 46.7301 19.9197C48.2031 19.9197 49.2788 20.4987 50.0735 21.2425L51.3817 19.9342C50.2721 18.8755 48.7991 18.0639 46.7301 18.0639C42.9894 18.0639 39.8447 21.1117 39.8447 24.8524C39.8447 28.5931 42.9894 31.6384 46.7301 31.6384C48.7507 31.6384 50.2721 30.977 51.4641 29.7342C52.6876 28.5083 53.0704 26.7881 53.0704 25.3975C53.0704 24.9687 53.0389 24.5713 52.971 24.2394L46.7301 24.2419Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M23.1367 20.5496L10.6911 8.1283C10.5482 8.4166 10.4634 8.77032 10.4634 9.19914V31.9049C10.4634 32.3386 10.5506 32.6996 10.6984 32.9879L23.1367 20.5496Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M10.729 8.04913C10.734 8.03673 10.7414 8.02681 10.7488 8.0144C10.7414 8.02681 10.7364 8.03921 10.729 8.04913Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M23.8578 19.83L27.6906 15.9973L13.0767 7.69458C12.6624 7.45715 12.2723 7.3457 11.9235 7.3457C11.7466 7.3457 11.5843 7.37719 11.4341 7.43292L23.8578 19.83Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M33.0945 19.0692L28.6149 16.5229L24.5835 20.5544L28.6149 24.5761L33.0945 22.0298C34.5288 21.2182 34.5288 19.8833 33.0945 19.0692Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M23.8658 21.2764L11.4688 33.6784C11.9121 33.8286 12.4669 33.7559 13.075 33.4119L27.6986 25.0995L23.8658 21.2764Z",
      fill: "black"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M10.7148 33.0266C10.773 33.1332 10.8384 33.2301 10.9135 33.3125C10.8384 33.2253 10.7681 33.1332 10.7148 33.0266Z",
      fill: "black"
    }), __jsx("path", {
      d: "M58.1099 24.6221C56.7871 24.6221 55.6436 25.6978 55.6436 27.2702C55.6436 28.8256 56.7847 29.9206 58.1099 29.9206C59.4351 29.9206 60.5762 28.828 60.5762 27.2702C60.5762 25.6978 59.4351 24.6221 58.1099 24.6221Z",
      fill: "white"
    }), __jsx("path", {
      d: "M70.1475 27.2702C70.1475 25.6978 69.0064 24.6221 67.6812 24.6221C66.3584 24.6221 65.2148 25.6978 65.2148 27.2702C65.2148 28.8256 66.3559 29.9206 67.6812 29.9206C69.0064 29.9206 70.1475 28.8256 70.1475 27.2702Z",
      fill: "white"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M77.2259 29.9206C75.9031 29.9206 74.7935 28.811 74.7935 27.2895C74.7935 25.7487 75.9031 24.6245 77.2283 24.6245C78.5341 24.6245 79.5614 25.7511 79.5614 27.2895C79.559 28.811 78.5317 29.9182 77.2259 29.9206Z",
      fill: "#FBFBFB"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M102.326 24.7215H99.5981V20.3194H102.326C103.76 20.3194 104.574 21.5065 104.574 22.5192C104.572 23.515 103.758 24.7215 102.326 24.7215Z",
      fill: "white"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M87.323 27.1393C87.2746 25.4507 88.6313 24.5906 89.6101 24.5906C90.3708 24.5906 91.0177 24.9734 91.2309 25.5185L87.323 27.1393Z",
      fill: "white"
    }), __jsx("path", {
      "fill-rule": "evenodd",
      "clip-rule": "evenodd",
      d: "M113.945 29.9183C113.317 29.9183 112.44 29.6033 112.44 28.8281C112.44 27.8372 113.531 27.4568 114.473 27.4568C115.314 27.4568 115.714 27.6385 116.225 27.8856C116.077 29.0752 115.052 29.9183 113.945 29.9183Z",
      fill: "#FBFBFB"
    })))))))) // </Reveal>

  );
}

/* harmony default export */ __webpack_exports__["Z"] = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().memo(BannerSection));

/***/ }),

/***/ 4184:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4138);
/* harmony import */ var _utils_data_slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8509);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9905);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);



 // Import Cusom Component

 // Import Settigns




const GET_ALL_BRANDS = _apollo_client__WEBPACK_IMPORTED_MODULE_3__.gql`query GetAllTopBrandRecords($input: BrandRecordsFilter) {
    getAllTopBrandRecords(input: $input) {
      maxRecords
      message
      records {
        brandName
        _id
        logo {
            fileType
            fileURL
            mimeType
            originalName
        }
      }
    }
}`;

function BrandSection() {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
  const {
    data: brndData
  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_3__.useQuery)(GET_ALL_BRANDS);
  return __jsx("div", {
    className: "brands-section mt-2 mb-3"
  }, __jsx((react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default()), {
    keyframes: _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_6__/* .fadeIn */ .Ji,
    delay: 200,
    duration: 500,
    triggerOnce: true
  }, __jsx("h4", {
    className: "section-title text-transform-none"
  }, "Top Brands"), __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    adClass: "  nav-circle  ",
    options: _utils_data_slider__WEBPACK_IMPORTED_MODULE_5__/* .brandSlider */ .mI
  }, brndData && brndData.getAllTopBrandRecords.records.map((brand, index) => __jsx("figure", {
    key: index,
    className: "circular-image",
    style: {
      justifyContent: "center",
      display: "flex",
      alignItems: "center",
      cursor: "pointer"
    },
    onClick: () => router.push(`/shop?brands=${brand._id}`)
  }, __jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__.LazyLoadImage, {
    alt: brand.brandName,
    src: brand.logo.fileURL,
    width: "100%",
    height: "auto",
    threshold: 500,
    effect: "black and white",
    className: "rounded-circle"
  }))))));
}

/* harmony default export */ __webpack_exports__["Z"] = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().memo(BrandSection));

/***/ }),

/***/ 199:
/***/ (function(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7659);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_tabs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _server_queries__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4733);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7164);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8974);
/* harmony import */ var _features_products_product_one__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4011);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9905);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);




 // Import Apollo and Query


 // Import Custom Component



 // Import Settings



function CategoryFilterSection() {
  var _data$getProducts;

  const {
    0: category,
    1: setCategory
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    data,
    loading,
    error
  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_9__.useQuery)(_server_queries__WEBPACK_IMPORTED_MODULE_5__/* .GET_PRODUCTS */ .tT, {
    variables: {
      input: {
        size: 10,
        page: 0
      }
    }
  }); // const [getProducts, { data, loading, error }] = useLazyQuery(GET_PRODUCTS);

  const products = data && (data === null || data === void 0 ? void 0 : (_data$getProducts = data.getProducts) === null || _data$getProducts === void 0 ? void 0 : _data$getProducts.records); // useEffect(() => {
  // getProducts({
  //   variables: {
  //     category: category,
  //     from: 0,
  //     to: 6,
  //   },
  // });
  // }, [category]);

  function getProduct(e, item) {
    e.preventDefault();
    setCategory(item);
  } // if (error) {
  //   return useRouter().push("/pages/404");
  // }


  return __jsx("section", {
    className: `category-filter-section skeleton-body skel-shop-products ${loading ? "" : "loaded"}`
  }, __jsx((react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default()), {
    keyframes: _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_10__/* .fadeInUpShorter */ .lN,
    delay: 200,
    duration: 1000,
    triggerOnce: true
  }, __jsx("div", {
    className: "container"
  }, __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tabs, {
    selectedTabClassName: "active",
    selectedTabPanelClassName: "active show"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-3 pr-lg-3 pr-sm-0 col-sm-6 order-1 order-sm-0"
  }, __jsx("div", {
    className: "shop-list h-100"
  }, __jsx("h4", {
    style: {
      color: "rgba(179, 179, 179, 1)",
      fontWeight: "500",
      fontSize: "23px",
      padding: "20px 3.2rem",
      display: "flex",
      alignItems: "center",
      borderBottom: " 1px solid #323232"
    }
  }, "Sort"), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.TabList, {
    className: "nav nav-tabs flex-sm-column border-0"
  }, __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item m-0"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "kids-fashion");
    },
    className: "nav-link m-0 p-0"
  })), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "kids-fashion");
    },
    className: "nav-link"
  }, "Kids Fashion")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "casual-shoes");
    },
    className: "nav-link"
  }, "Casual Shoes")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "spring-and-autumn");
    },
    className: "nav-link"
  }, "Spring & Autumn")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "man");
    },
    className: "nav-link"
  }, "Man")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "accessories-4");
    },
    className: "nav-link"
  }, "Accessories")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "pants-and-polos");
    },
    className: "nav-link"
  }, "Pants & Denim")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "tees-knits-and-polos");
    },
    className: "nav-link"
  }, "Tees, Knits & Polos")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "watch-fashion");
    },
    className: "nav-link"
  }, "Watch Fashion")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "woman");
    },
    className: "nav-link"
  }, "Woman")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "accessories-4");
    },
    className: "nav-link"
  }, "Accessories")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "dresses-and-skirts");
    },
    className: "nav-link"
  }, "Dresses & Skirts")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "shoes-and-boots");
    },
    className: "nav-link"
  }, "Shoes & Boots")), __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.Tab, {
    className: "nav-item"
  }, __jsx("a", {
    href: "#",
    onClick: e => {
      getProduct(e, "top-and-blouses");
    },
    className: "nav-link"
  }, "Top & Blouses"))), __jsx("div", {
    style: {
      background: "rgba(34, 34, 34, 1)",
      height: "64px",
      paddingLeft: "28px",
      paddingTop: "20px"
    }
  }, " ", __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
    className: "view-all",
    href: "/shop",
    style: {
      color: "rgba(255, 255, 255, 1)"
    }
  }, "View All")))), __jsx("div", {
    className: "col-lg-3 col-sm-6 pl-lg-3 pl-sm-0 order-0"
  }, __jsx("div", {
    className: "banner banner3",
    style: {
      backgroundImage: "url(images/home/banners/sort.svg)"
    }
  }, __jsx("div", {
    className: "container d-flex justify-content-center"
  }))), __jsx("div", {
    className: "col-lg-6 tab-content mt-2 mt-lg-0 order-2 order-sm-0"
  }, new Array(14).fill(1).map((item, index) => __jsx(react_tabs__WEBPACK_IMPORTED_MODULE_3__.TabPanel, {
    className: `tab-pane fade ${products && (products === null || products === void 0 ? void 0 : products.length) > 3 ? "" : "h-half"}`,
    key: "TabPanel: " + index
  }, __jsx("div", {
    className: "product-content products-with-divide"
  }, __jsx("div", {
    className: "row row-joined h-100"
  }, products ? products.slice(0, 6).map((item, index) => __jsx("div", {
    className: "col-sm-4 col-6",
    key: "Kitchen:" + index,
    style: {
      border: "1px solid rgba(185, 185, 185, 1)"
    }
  }, __jsx(_features_products_product_one__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
    adClass: "inner-quickview inner-icon",
    product: item
  }))) : new Array(6).fill(1).map((item, index) => __jsx("div", {
    className: "col-sm-4 col-6",
    key: "Skeleton:" + index
  }, __jsx("div", {
    className: "skel-pro skel-pro-grid"
  })))))))))))));
}

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)({
  ssr: true
})(CategoryFilterSection));

/***/ }),

/***/ 4385:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ deal_section; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-awesome-reveal"
var external_react_awesome_reveal_ = __webpack_require__(104);
var external_react_awesome_reveal_default = /*#__PURE__*/__webpack_require__.n(external_react_awesome_reveal_);
// EXTERNAL MODULE: ./components/features/products/product-one.jsx
var product_one = __webpack_require__(4011);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: external "react-lazy-load-image-component"
var external_react_lazy_load_image_component_ = __webpack_require__(9290);
// EXTERNAL MODULE: ./store/wishlist.js
var wishlist = __webpack_require__(5708);
// EXTERNAL MODULE: ./store/cart.js
var cart = __webpack_require__(2806);
// EXTERNAL MODULE: ./store/modal.js
var modal = __webpack_require__(6723);
// EXTERNAL MODULE: ./components/common/ALink.jsx
var ALink = __webpack_require__(8974);
// EXTERNAL MODULE: ./components/features/product-countdown.jsx
var product_countdown = __webpack_require__(4229);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(8074);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(2034);
// EXTERNAL MODULE: ./components/features/modals/add-to-cart-popup.jsx
var add_to_cart_popup = __webpack_require__(4922);
;// CONCATENATED MODULE: ./components/features/products/product-four.jsx
var __jsx = (external_react_default()).createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // Import Actions



 // Import Custom Component






client_.useQuery;

function ProductFour(props) {
  var _product$images$, _product$mrp, _product$variants;

  const router = (0,router_.useRouter)();
  const {
    adClass = "",
    link = "default",
    product
  } = props;

  function isSale() {
    return product.price[0] !== product.price[1] && product.variants.length === 0 ? "-" + (100 * (product.price[1] - product.price[0]) / product.price[1]).toFixed(0) + "%" : product.variants.find(variant => variant.sale_price) ? "Sale" : false;
  }

  function isInWishlist() {
    return product && props.wishlist.findIndex(item => item.slug === product.slug) > -1;
  }

  function onWishlistClick(e) {
    e.preventDefault();

    if (!isInWishlist()) {
      let target = e.currentTarget;
      target.classList.add("load-more-overlay");
      target.classList.add("loading");
      setTimeout(() => {
        target.classList.remove("load-more-overlay");
        target.classList.remove("loading");
        props.addToWishList(product);
      }, 1000);
    } else {
      router.push("/pages/wishlist");
    }
  }

  function onAddCartClick(e) {
    e.preventDefault();

    if (localStorage.getItem("arabtoken")) {
      try {
        if (product.stock > 0 && !e.currentTarget.classList.contains("disabled")) {
          const response = addToCart({
            variables: {
              input: {
                productId: product._id,
                quantity: 1
              }
            }
          });

          if (response) {
            cartRefetch();
            return (0,external_react_toastify_.toast)(__jsx(add_to_cart_popup/* default */.Z, {
              product: {
                product
              }
            }));
          }
        }
      } catch (error) {
        console.log(error);
      }
    } else {
      const localCart = JSON.parse(localStorage.getItem("cart"));

      if (localCart) {
        const productIndex = localCart.findIndex(item => item.productId === product._id);

        if (productIndex > -1) {
          localCart[productIndex].quantity += 1;
        } else {
          localCart.push({
            productId: product._id,
            quantity: 1,
            name: product.productName,
            shortDescription: product.shortDescription,
            stock: product.stock,
            color: product.color,
            size: product.size,
            price: product.price,
            image: product.images[0] && product.images[0].fileURL,
            sellingPrice: product.sellingPrice,
            mrp: product.mrp
          });
        }

        localStorage.setItem("cart", JSON.stringify(localCart));
      } else {
        localStorage.setItem("cart", JSON.stringify([{
          productId: product._id,
          quantity: 1,
          name: product.productName,
          shortDescription: product.shortDescription,
          stock: product.stock,
          color: product.color,
          size: product.size,
          price: product.price,
          image: product.images[0] && product.images[0].fileURL,
          sellingPrice: product.sellingPrice,
          mrp: product.mrp
        }]));
      }
    }

    return (0,external_react_toastify_.toast)(__jsx(add_to_cart_popup/* default */.Z, {
      product: {
        product
      }
    }));
  }

  ;

  function onQuickViewClick(e) {
    e.preventDefault();
    props.showQuickView(product.slug);
  }

  return __jsx("div", {
    className: `product-default custom-product-resp media-with-lazy ${adClass}`,
    style: {
      border: "1px solid rgba(185, 185, 185, 1)"
    }
  }, __jsx(ALink/* default */.Z, {
    href: `product/default/${product === null || product === void 0 ? void 0 : product._id}`
  }, __jsx("span", {
    style: {
      display: "flex",
      justifyContent: "center",
      maxHeight: "383px"
    }
  }, __jsx("img", {
    src: product === null || product === void 0 ? void 0 : (_product$images$ = product.images[0]) === null || _product$images$ === void 0 ? void 0 : _product$images$.fileURL,
    style: {
      marginTop: "74px",
      objectFit: "contain"
    }
  }))), __jsx("div", {
    className: "product-details",
    style: {
      alignItems: "center"
    }
  }, __jsx("div", {
    className: "category-wrap"
  }, __jsx("div", {
    className: "category-list"
  }, __jsx((external_react_default()).Fragment, {
    key: product._id
  }, __jsx(ALink/* default */.Z, {
    href: {
      pathname: `product/default/${product === null || product === void 0 ? void 0 : product._id}` // query: { product._id },

    },
    style: {
      color: "rgba(227, 6, 19, 1)",
      fontSize: "12px",
      fontWeight: "700",
      justifyContent: "center"
    }
  }, product === null || product === void 0 ? void 0 : product.categoryNamePath)))), __jsx("h3", {
    className: "product-title",
    style: {
      justifyContent: "center"
    }
  }, __jsx(ALink/* default */.Z, {
    href: `/product/default/${product.slug}`
  }, product === null || product === void 0 ? void 0 : product.productName)), __jsx("div", {
    className: "price-box"
  }, __jsx("span", {
    style: {
      fontFamily: "Plus Jakarta Sans"
    }
  }, "OMR"), __jsx("span", {
    className: "product-price",
    style: {
      fontWeight: "800px",
      fontSize: "16px",
      lineHeight: "15px",
      marginLeft: "25px"
    }
  }, product === null || product === void 0 ? void 0 : product.price.toFixed(2)), __jsx("span", {
    className: "old-price",
    style: {
      marginLeft: "25px",
      color: "#777777",
      fontWeight: "600"
    }
  }, product === null || product === void 0 ? void 0 : (_product$mrp = product.mrp) === null || _product$mrp === void 0 ? void 0 : _product$mrp.toFixed(2))), __jsx("div", {
    className: "product-action"
  }, (product === null || product === void 0 ? void 0 : (_product$variants = product.variants) === null || _product$variants === void 0 ? void 0 : _product$variants.length) > 0 ? __jsx(ALink/* default */.Z, {
    href: `/product/default/${product === null || product === void 0 ? void 0 : product.slug}`,
    className: "btn-icon btn-add-cart"
  }, __jsx("i", {
    className: "fa fa-arrow-right"
  }), __jsx("span", null, "SELECT OPTIONS")) : __jsx("a", {
    href: "#",
    className: "btn-icon  btn-add-cart product-type-simple ",
    title: "Add To Cart",
    onClick: onAddCartClick
  }, __jsx("span", null, "ADD TO CART")))));
}

const mapStateToProps = state => {
  return {
    wishlist: state.wishlist.list ? state.wishlist.list : []
  };
};

/* harmony default export */ var product_four = ((0,external_react_redux_.connect)(mapStateToProps, _objectSpread(_objectSpread(_objectSpread({}, wishlist/* actions */.Nw), cart/* actions */.Nw), modal/* actions */.Nw))( /*#__PURE__*/external_react_default().memo(ProductFour)));
// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__(7530);
// EXTERNAL MODULE: ./utils/data/keyframes.js
var keyframes = __webpack_require__(9905);
;// CONCATENATED MODULE: ./components/partials/home/deal-section.jsx
var deal_section_jsx = (external_react_default()).createElement;

 //Import Custom Component



 // Import Settigns



const GET_PRODUCTS = react_hooks_.gql`query GetProducts($input: ProductFilters) {
  getProducts(input: $input) {
    maxRecords
    records {
      _id
      attributes {
        attributeValue
        attributeName
      }
      brandId
      brandName
      categoryId
      categoryIdPath
      categoryNamePath
      description
      images {
        fileURL
        originalName
        fileType
      }
      mrp
      offerPrice
      price
      productCode
      productInfo
      productName
      productShortInfo
      rating
      sellingPrice
      shortDescription
      skuId
      status
      stock
      tags
      vendorId
      isBlocked
    }
  }
}`;

function DealSection() {
  var _data$getProducts;

  // const {data,loading,error}=useQuery(GET_PRODUCTS)
  const [getProducts, {
    data,
    loading,
    error
  }] = (0,react_hooks_.useLazyQuery)(GET_PRODUCTS);
  (0,external_react_.useEffect)(() => {
    getProducts({
      variables: {
        input: {
          discount: 10,
          size: 6
        }
      }
    });
  }, []);
  const products = data === null || data === void 0 ? void 0 : (_data$getProducts = data.getProducts) === null || _data$getProducts === void 0 ? void 0 : _data$getProducts.records;
  return deal_section_jsx("section", {
    className: "deal-products-section"
  }, deal_section_jsx("div", {
    className: "deal-section-head"
  }, deal_section_jsx("h2", {
    className: "section-title d-flex align-items-center text-transform-none"
  }, "Deals of the day"), deal_section_jsx(ALink/* default */.Z, {
    href: "/shop?discount=10"
  }, " ", deal_section_jsx("p", {
    style: {
      color: "rgba(0, 0, 0, 1)",
      fontWeight: "500"
    }
  }, "View All Products"))), deal_section_jsx("h4", {
    className: "recommendmob"
  }, "Deals of the day"), deal_section_jsx((external_react_awesome_reveal_default()), {
    keyframes: keyframes/* fadeInUpShorter */.lN,
    delay: 100,
    duration: 1000,
    triggerOnce: true // style={{ border: "1px solid rgba(185, 185, 185, 1)" }}

  }, deal_section_jsx("div", {
    className: "row"
  }, deal_section_jsx("div", {
    className: "col-lg-4 col-md-5 mb-2 mb-md-0"
  }, products ? products.slice(0, 15) // .filter((item) => item.until && item.until !== null)
  .slice(0, 1).map((item, index) => {
    return deal_section_jsx(product_four, {
      adClass: "deal-product",
      product: item,
      key: "All Products:" + index
    });
  }) : [0].map((item, index) => deal_section_jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "Skeleton:" + index
  }))), deal_section_jsx("div", {
    className: "col-lg-8 col-md-7"
  }, deal_section_jsx("div", {
    className: "products-with-divide"
  }, deal_section_jsx("div", {
    className: "row row-joined"
  }, products ? products // .filter((item) => item.until === null)
  .slice(0, 6).map((item, index) => deal_section_jsx("div", {
    className: "col-xl-4 col-sm-4 col-6 customdeal-border",
    key: "All Products:" + index // style={{ border: "1px solid rgba(185, 185, 185, 1)", borderRight:"none" }}

  }, deal_section_jsx(product_one/* default */.Z // adClass="inner-quickview inner-icon"
  , {
    product: item // customStyle="65%"

  }))) : new Array(6).fill(1).map((item, index) => deal_section_jsx("div", {
    className: "col-xl-3 col-sm-4 col-6",
    key: "All Products:" + index
  }, deal_section_jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "Skeleton:" + index
  })))))))));
}

/* harmony default export */ var deal_section = (/*#__PURE__*/external_react_default().memo(DealSection));

/***/ }),

/***/ 6924:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8974);
/* harmony import */ var _features_products_product_one__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4011);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4138);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9905);
/* harmony import */ var _utils_data_slider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8509);
/* harmony import */ var _garden_collection__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5249);
/* harmony import */ var _recent_collection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2413);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7530);
/* harmony import */ var _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _server_queries__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4733);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // Import Custom Component



 // Import Settigns







const GET_PRODUCTS = _apollo_react_hooks__WEBPACK_IMPORTED_MODULE_9__.gql`
query GetProducts($input: ProductFilters) {
  getProducts(input: $input) {
    maxRecords
    records {
      _id
      vendorId
      brandId
      brandName
      productName
      shortDescription
      skuId
      description
      productInfo
      productShortInfo
      images {
        fileType
        fileURL
        mimeType
        originalName
      }
      rating
      sellingPrice
      price
      mrp
      tags
      productCode
      categoryId
      categoryNamePath
      categoryIdPath
      isBlocked
      stock
      status
      offerPrice
      attributes {
        attributeId
        attributeName
        attributeValueId
        attributeValue
        attributeDescription
      }
      productDetailImages {
        fileType
        fileURL
        mimeType
        originalName
      }
      warehouseSkuId
    }
  }
}`;

function ElectronicCollection() {
  var _data$getProducts;

  const {
    data,
    loading,
    error
  } = (0,_apollo_react_hooks__WEBPACK_IMPORTED_MODULE_9__.useQuery)(GET_PRODUCTS, {
    variables: {
      input: {
        bestSeller: true
      }
    }
  });
  const products = data === null || data === void 0 ? void 0 : (_data$getProducts = data.getProducts) === null || _data$getProducts === void 0 ? void 0 : _data$getProducts.records; //   const { data, loading, error } = useQuery(GET_HOME_DATA, {
  //     variables: { productsCount: 15 },
  //   });
  // const giftAndGadgets = data && data?.giftAndGadgets?.data;
  // const latest = data && data?.specialProducts?.latest;
  // const topRated = data && data?.specialProducts?.topRated;
  // const bestSelling = data && data?.specialProducts?.bestSelling;
  // const electronic = data && data?.electronic?.data;

  return __jsx("div", {
    className: "container",
    style: {
      paddingBottom: "60px"
    }
  }, __jsx("section", {
    className: "recent-products-section"
  }, __jsx((react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default()), {
    keyframes: _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_5__/* .fadeIn */ .Ji,
    delay: 100,
    duration: 1000,
    triggerOnce: true
  }, __jsx("div", {
    className: "heading shop-list   mb-0 pl-0 pr-0 ",
    style: {
      borderBottom: "1px solid ",
      borderColor: "#EEEEEE"
    }
  }, __jsx("div", {
    className: "pt-5 pb-5 mt-5 d-flex align-items-center justify-content-between flex-wrap"
  }, __jsx("h4", {
    className: "section-title text-transform-none mb-0 mr-0 "
  }, "Best Selling"), __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    href: "/shop?bestSeller=true",
    style: {
      color: "black",
      fontWeight: "600"
    }
  }, "View All Products"))), __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    adClass: "products-slider best-selling-slider nav-blackcircle pb-0",
    options: _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_6__/* .productSlider */ .sE), {}, {
      responsive: _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_6__/* .productSlider.responsive */ .sE.responsive), {}, {
        0: {
          items: 2,
          nav: true,
          loop: true
        },
        576: {
          items: 2,
          nav: true,
          loop: true
        },
        768: {
          items: 3,
          nav: true,
          loop: true
        },
        992: {
          items: 4,
          nav: true
        },
        1200: {
          items: 5,
          nav: true,
          loop: true
        }
      })
    })
  }, products && products // .slice(0, 7)
  .map((item, index) => __jsx(_features_products_product_one__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index // customStyle="20%"

  })) // : [0, 1, 2, 3].map((item, index) => (
  //     <div
  //       className="skel-pro skel-pro-grid"
  //       key={"product-one" + index}
  //     ></div>
  //   )
  //   )
  ))));
}

/* harmony default export */ __webpack_exports__["Z"] = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().memo(ElectronicCollection));

/***/ }),

/***/ 2239:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8974);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4138);
/* harmony import */ var _utils_data_slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8509);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9905);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);


 // Import Custom Component


 // Import Settings

 // Import Keyframes



function FooterBannerSection({
  data
}) {
  var _data$images;

  const options = {
    items: 1,
    // Number of items to show
    // margin: 50, // Space between items
    loop: true,
    // Enable loop
    autoplay: false,
    // Autoplay the slider
    autoplayTimeout: 3000,
    // Autoplay interval (3 seconds in this example)
    dots: true
  };
  return __jsx("div", {
    className: "mt-4"
  }, __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    adClass: "home-slider mb-2",
    options: options
  }, data === null || data === void 0 ? void 0 : (_data$images = data.images) === null || _data$images === void 0 ? void 0 : _data$images.map((item, imgIndex) => {
    return __jsx("div", {
      key: imgIndex,
      style: {
        maxHeight: "550px"
      },
      className: "bannerheight",
      style: {
        cursor: "pointer"
      },
      onClick: () => {
        var _data$buttons$;

        if (data !== null && data !== void 0 && data.buttons && (data === null || data === void 0 ? void 0 : data.buttons.length) > 0 && data !== null && data !== void 0 && (_data$buttons$ = data.buttons[0]) !== null && _data$buttons$ !== void 0 && _data$buttons$.redirectionURL) {
          var _data$buttons$2;

          router.push(data === null || data === void 0 ? void 0 : (_data$buttons$2 = data.buttons[0]) === null || _data$buttons$2 === void 0 ? void 0 : _data$buttons$2.redirectionURL);
        }
      }
    }, __jsx("img", {
      src: item.fileURL,
      alt: "Image",
      style: {
        height: "100%",
        maxHeight: "550px",
        objectFit: "cover"
      }
    }));
  })));
}

/* harmony default export */ __webpack_exports__["Z"] = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().memo(FooterBannerSection));

/***/ }),

/***/ 5249:
/***/ (function(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7659);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_tabs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8974);
/* harmony import */ var _features_product_countdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4229);
/* harmony import */ var _features_products_product_one__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4011);
/* harmony import */ var _features_products_product_three__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9915);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4138);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9905);
/* harmony import */ var _utils_data_slider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8509);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // Import Custom Component





 // Import Settigns




function GardenCollection(props) {
  const {
    latest,
    bestSelling,
    topRated,
    products
  } = props;

  const slideOption = _objectSpread(_objectSpread({}, productSlider), {}, {
    nav: false,
    responsive: _objectSpread(_objectSpread({}, productSlider.responsive), {}, {
      1200: {
        items: 4
      }
    })
  });

  return __jsx(Reveal, {
    keyframes: fadeIn,
    delay: 100,
    duration: 1000,
    triggerOnce: true
  }, __jsx("section", {
    className: "garden-collection"
  }, __jsx("div", {
    className: "bg-white"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-xl-12 col-xl-12cols pr-xl-0"
  }, __jsx("div", {
    className: "product-slider-tab appear-animate bg-white carousel-with-bg"
  }, __jsx(Tabs, {
    selectedTabClassName: "active",
    selectedTabPanelClassName: "active show"
  }, __jsx("div", {
    className: "heading shop-list d-flex align-items-center flex-wrap justify-content-center justify-content-md-start"
  }, __jsx(TabList, {
    className: "nav ml-0 justify-content-center mb-0"
  }, __jsx(Tab, {
    className: "nav-item"
  }, __jsx(ALink, {
    href: "#",
    className: "nav-link"
  }, "Iphone")), __jsx(Tab, {
    className: "nav-item"
  }, __jsx(ALink, {
    href: "#",
    className: "nav-link"
  }, "Ipad")), __jsx(Tab, {
    className: "nav-item"
  }, __jsx(ALink, {
    href: "#",
    className: "nav-link"
  }, "Macbook")), __jsx(Tab, {
    className: "nav-item"
  }, __jsx(ALink, {
    href: "#",
    className: "nav-link"
  }, "Watch")), __jsx(Tab, {
    className: "nav-item"
  }, __jsx(ALink, {
    href: "#",
    className: "nav-link"
  }, "Airpods")))), __jsx("div", {
    className: "tab-content"
  }, __jsx(TabPanel, {
    className: "tab-pane fade"
  }, __jsx(OwlCarousel, {
    adClass: "products-slider nav-circle nav-image-center pb-0 border-bottom-1 border-left-1 border-right-1 border-top-0 border-solid custom-border-color",
    options: slideOption,
    style: {
      border: " 1px solid #EEE"
    }
  }, bestSelling ? bestSelling.slice(0, 6).map((item, index) => __jsx(ProductOne, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index
  })) : [0, 1, 2, 3].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-one" + index
  })))), __jsx(TabPanel, {
    className: "tab-pane fade"
  }, __jsx(OwlCarousel, {
    adClass: "products-slider nav-circle nav-image-center pb-0",
    options: slideOption
  }, latest ? latest.slice(0, 6).map((item, index) => __jsx(ProductOne, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index
  })) : [0, 1, 2, 3].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-one" + index
  })))), __jsx(TabPanel, {
    className: "tab-pane fade"
  }, __jsx(OwlCarousel, {
    adClass: "products-slider nav-circle nav-image-center pb-0",
    options: slideOption
  }, topRated ? topRated.slice(0, 6).map((item, index) => __jsx(ProductOne, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index
  })) : [0, 1, 2, 3].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-one" + index
  }))))))))))));
}

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(/* unused pure expression or super */ null && (React.memo(GardenCollection))));

/***/ }),

/***/ 5729:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export default */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8974);
/* harmony import */ var _features_products_product_one__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4011);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4138);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9905);
/* harmony import */ var _utils_data_slider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8509);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

 // Import Custom Component



 // Import Settigns



function GiftCollection({
  products
}) {
  return __jsx("section", {
    className: "gift-section"
  }, __jsx(Reveal, {
    keyframes: fadeIn,
    delay: 100,
    duration: 1000,
    triggerOnce: true
  }, __jsx("div", {
    className: "categories-container categories-container-two bg-white"
  }, __jsx("h4", {
    className: "section-title text-transform-none"
  }, "Gift & Gadgets"), __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col-lg-3 col-6"
  }, __jsx("div", {
    className: "shop-list p-0 d-flex align-items-sm-center flex-sm-row flex-column"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'her-him'
      }
    }
  }, __jsx("i", {
    className: "icon-boy-broad-smile"
  })), __jsx("div", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'her-him'
      }
    },
    className: "sub-title"
  }, "For Him"), __jsx("ul", null, __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gifts-for-boyfriend'
      }
    }
  }, "Gifts for Boyfriend")), __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gifts-for-dad'
      }
    }
  }, "Gifts for Dad")), __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gifts-for-husband'
      }
    }
  }, "Gifts for Husband")))))), __jsx("div", {
    className: "col-lg-3 col-6"
  }, __jsx("div", {
    className: "shop-list p-0 d-flex align-items-sm-center flex-sm-row flex-column"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'for-her'
      }
    }
  }, __jsx("i", {
    className: "icon-smiling-girl"
  })), __jsx("div", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'for-her'
      }
    },
    className: "sub-title"
  }, "For Her"), __jsx("ul", null, __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gifts-for-mom'
      }
    }
  }, "Gifts for Mom")), __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gifts-for-girlfriend'
      }
    }
  }, "Gifts for Girlfriend")), __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gifts-for-wife'
      }
    }
  }, "Gifts for Wife")))))), __jsx("div", {
    className: "col-lg-3 col-6"
  }, __jsx("div", {
    className: "shop-list p-0 d-flex align-items-sm-center flex-sm-row flex-column"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'for-kids'
      }
    }
  }, __jsx("i", {
    className: "icon-smiling-baby"
  })), __jsx("div", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'for-kids'
      }
    },
    className: "sub-title"
  }, "For Kids"), __jsx("ul", null, __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gifts-for-boys'
      }
    }
  }, "Gifts for Boys")), __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gifts-for-girls'
      }
    }
  }, "Gifts for Girls")), __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'gifts-for-twin-boys'
      }
    }
  }, "Gifts for Twin Boys")))))), __jsx("div", {
    className: "col-lg-3 col-6"
  }, __jsx("div", {
    className: "shop-list p-0 d-flex align-items-sm-center flex-sm-row flex-column"
  }, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'birthday'
      }
    }
  }, __jsx("i", {
    className: "icon-gift-2"
  })), __jsx("div", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'birthday'
      }
    },
    className: "sub-title"
  }, "Birthday"), __jsx("ul", null, __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'birthday-for-him'
      }
    }
  }, "Birthday for Him")), __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'birthday-for-her'
      }
    }
  }, "Birthday for Her")), __jsx("li", null, __jsx(ALink, {
    href: {
      pathname: '/shop',
      query: {
        category: 'boyfriend-for-gifts'
      }
    }
  }, "Boyfriend Gifts"))))))))), __jsx(OwlCarousel, {
    adClass: "products-slider product-slider-two carousel-with-bg nav-outer show-nav-hover nav-image-center pb-0 nav-circle",
    options: productSlider
  }, products ? products.map((item, index) => __jsx(ProductOne, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index
  })) : [0, 1, 2, 3, 4, 5].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-one" + index
  }))), __jsx(Reveal, {
    keyframes: fadeIn,
    delay: 100,
    duration: 1000,
    triggerOnce: true
  }, __jsx("div", {
    className: "sale-banner banner bg-image mb-4",
    style: {
      backgroundImage: 'url(images/home/banners/banner6.jpg)'
    }
  }, __jsx("div", {
    className: "container banner-content"
  }, __jsx("div", {
    className: "row no-gutter justify-content-start"
  }, __jsx("div", {
    className: "col-auto col-lg-5 col-md-6 col-12 d-flex flex-column justify-content-center content-left text-center text-md-right"
  }, __jsx("h4", {
    className: "align-left text-white text-uppercase"
  }, "THE PERFECT GIFT FOR YOUR GIRLFRIEND"), __jsx("h3", {
    className: "text-white mb-0 align-left text-uppercase"
  }, "GIFT SELECTION ON SALE")), __jsx("div", {
    className: "col-auto col-md-2 col-12 col-2 justify-content-center content-center mr-md-3 mr-lg-0  ml-md-4 ml-lg-0"
  }, __jsx("h2", {
    className: "text-white mb-0 position-relative align-left"
  }, "50", __jsx("small", null, "%", __jsx("ins", null, "OFF")))), __jsx("div", {
    className: "mb-0 col-md-4 col-12 col-3 col-auto justify-content-center justify-content-md-start content-right"
  }, __jsx(ALink, {
    href: "/shop",
    className: "btn btn-lg bg-white text-dark font2"
  }, "Shop Now!")))))));
}

/***/ }),

/***/ 5837:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4138);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);
 // Import Custom Component


 // Import Settings 
// Import Keyframes

function HomeSection({
  offer,
  data
}) {
  var _data$images;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const options = {
    items: 1,
    // Number of items to show
    // margin: 50, // Space between items
    loop: true,
    // Enable loop
    autoplay: false,
    // Autoplay the slider
    // autoplayTimeout: 3000,
    // Autoplay interval (3 seconds in this example)
    // dots: true,
    nav: true
  };
  return __jsx("div", {
    className: "skeleton-body skel-shop-products"
  }, !offer ? __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    adClass: "home-slider nav-circle mb-2 ",
    options: options
  }, data === null || data === void 0 ? void 0 : (_data$images = data.images) === null || _data$images === void 0 ? void 0 : _data$images.map((item, imgIndex) => {
    return __jsx("div", {
      key: imgIndex,
      style: {
        cursor: "pointer"
      },
      onClick: () => {
        var _data$buttons$;

        if (data !== null && data !== void 0 && data.buttons && (data === null || data === void 0 ? void 0 : data.buttons.length) > 0 && data !== null && data !== void 0 && (_data$buttons$ = data.buttons[0]) !== null && _data$buttons$ !== void 0 && _data$buttons$.redirectionURL) {
          var _data$buttons$2;

          router.push(data === null || data === void 0 ? void 0 : (_data$buttons$2 = data.buttons[0]) === null || _data$buttons$2 === void 0 ? void 0 : _data$buttons$2.redirectionURL);
        }
      }
    }, __jsx("img", {
      src: item.fileURL,
      alt: "Image",
      style: {
        height: "100%",
        height: "auto",
        objectFit: "fill"
      }
    }));
  })) : __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    adClass: "home-slider nav-circle mb-2 ",
    options: options
  }, __jsx("div", null, __jsx("img", {
    src: offer === null || offer === void 0 ? void 0 : offer.fileURL,
    alt: "Image",
    style: {
      height: "350px"
    }
  }))));
}

/* harmony default export */ __webpack_exports__["Z"] = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().memo(HomeSection));

/***/ }),

/***/ 2413:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7659);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_tabs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8974);
/* harmony import */ var _features_products_product_one__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4011);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4138);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9905);
/* harmony import */ var _utils_data_slider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8509);
/* harmony import */ var _server_apollo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7164);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_9__);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // Import Custom Component



 // Import Settigns






function RecentCollection(props) {
  var _tenPercentData$getPr, _thirtyPercentData$ge, _fiftyPercentData$get;

  const {
    bestSelling
  } = props;
  const GET_PRODUCTS = _apollo_client__WEBPACK_IMPORTED_MODULE_9__.gql`
  query GetProducts($input: ProductFilters) {
    getProducts(input: $input) {
      maxRecords
      records {
        _id
        attributes {
          attributeValue
          attributeName
        }
        brandId
        brandName
        categoryId
        categoryIdPath
        categoryNamePath
        description
        images {
          fileURL
          originalName
          fileType
        }
        mrp
        offerPrice
        price
        productCode
        productInfo
        productName
        productShortInfo
        rating
        sellingPrice
        shortDescription
        skuId
        status
        stock
        tags
        vendorId
        isBlocked
      }
    }
  }
`;
  const {
    data: tenPercentData
  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_9__.useQuery)(GET_PRODUCTS, {
    variables: {
      input: {
        discount: 10
      }
    }
  });
  const tenPercentProducts = tenPercentData === null || tenPercentData === void 0 ? void 0 : (_tenPercentData$getPr = tenPercentData.getProducts) === null || _tenPercentData$getPr === void 0 ? void 0 : _tenPercentData$getPr.records; // Query products with 30% discount

  const {
    data: thirtyPercentData
  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_9__.useQuery)(GET_PRODUCTS, {
    variables: {
      input: {
        discount: 30
      }
    }
  });
  const thirtyPercentProducts = thirtyPercentData === null || thirtyPercentData === void 0 ? void 0 : (_thirtyPercentData$ge = thirtyPercentData.getProducts) === null || _thirtyPercentData$ge === void 0 ? void 0 : _thirtyPercentData$ge.records; // Query products with 50% discount

  const {
    data: fiftyPercentData
  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_9__.useQuery)(GET_PRODUCTS, {
    variables: {
      input: {
        discount: 50
      }
    }
  });
  const fiftyPercentProducts = fiftyPercentData === null || fiftyPercentData === void 0 ? void 0 : (_fiftyPercentData$get = fiftyPercentData.getProducts) === null || _fiftyPercentData$get === void 0 ? void 0 : _fiftyPercentData$get.records;
  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, __jsx("section", {
    className: "recent-products-section",
    style: {
      marginTop: "10px"
    }
  }, __jsx((react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default()), {
    keyframes: _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_6__/* .fadeIn */ .Ji,
    delay: 100,
    duration: 1000,
    triggerOnce: true,
    style: {
      marginTop: "30px"
    }
  }, __jsx("div", {
    className: "heading shop-list d-flex align-items-center flex-wrap  mb-0 pl-0 pr-0",
    style: {
      borderBottom: "1px solid ",
      borderColor: "#EEEEEE"
    }
  }, __jsx("h4", {
    className: "section-title text-transform-none mb-0 mr-0"
  }, "50% Off"), __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    className: "view-all ml-auto",
    href: "/shop?discount=50"
  }, "View All Products")), __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    adClass: "products-slider carousel-with-bg nav-blackcircle pb-0",
    options: _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_7__/* .productSlider */ .sE), {}, {
      responsive: _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_7__/* .productSlider.responsive */ .sE.responsive), {}, {
        0: {
          items: 2,
          nav: true
        },
        576: {
          items: 2,
          nav: true
        },
        768: {
          items: 3,
          nav: true
        },
        992: {
          items: 4,
          nav: true
        },
        1200: {
          items: 5,
          nav: true
        }
      })
    })
  }, fiftyPercentProducts ? fiftyPercentProducts.map((item, index) => __jsx(_features_products_product_one__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index,
    customStyle: "20%"
  })) : [0, 1].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-one" + index
  }))))), __jsx("section", {
    className: "recent-products-section"
  }, __jsx((react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default()), {
    keyframes: _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_6__/* .fadeIn */ .Ji,
    delay: 100,
    duration: 1000,
    triggerOnce: true,
    style: {
      marginTop: "30px"
    }
  }, __jsx("div", {
    className: "heading shop-list d-flex align-items-center flex-wrap mb-0 pl-0 pr-0",
    style: {
      borderBottom: "1px solid ",
      borderColor: "#EEEEEE"
    }
  }, __jsx("h4", {
    className: "section-title text-transform-none mb-0 mr-0"
  }, "30%off"), __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    className: "view-all ml-auto",
    href: "/shop?discount=30"
  }, "View All Products")), __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    adClass: "products-slider carousel-with-bg nav-blackcircle pb-0" // options={productSlider}
    ,
    options: _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_7__/* .productSlider */ .sE), {}, {
      responsive: _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_7__/* .productSlider.responsive */ .sE.responsive), {}, {
        0: {
          items: 2,
          nav: true
        },
        576: {
          items: 2,
          nav: true
        },
        768: {
          items: 3,
          nav: true
        },
        992: {
          items: 4,
          nav: true
        },
        1200: {
          items: 5,
          nav: true
        }
      })
    })
  }, thirtyPercentProducts ? thirtyPercentProducts.map((item, index) => __jsx(_features_products_product_one__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index,
    customStyle: "20%"
  })) : [0, 1].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-one" + index
  }))))), __jsx("section", {
    className: "recent-products-section"
  }, __jsx((react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default()), {
    keyframes: _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_6__/* .fadeIn */ .Ji,
    delay: 100,
    duration: 1000,
    triggerOnce: true,
    style: {
      marginTop: "30px"
    }
  }, __jsx("div", {
    className: "heading shop-list d-flex align-items-center flex-wrap mb-0 pl-0 pr-0",
    style: {
      borderBottom: "1px solid ",
      borderColor: "#EEEEEE"
    }
  }, __jsx("h4", {
    className: "section-title text-transform-none mb-0 mr-0"
  }, "10% Off"), __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    className: "view-all ml-auto",
    href: "/shop?discount=10"
  }, "View All Products")), __jsx(_features_owl_carousel__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    adClass: "products-slider carousel-with-bg nav-blackcircle pb-0" // options={productSlider}
    ,
    options: _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_7__/* .productSlider */ .sE), {}, {
      responsive: _objectSpread(_objectSpread({}, _utils_data_slider__WEBPACK_IMPORTED_MODULE_7__/* .productSlider.responsive */ .sE.responsive), {}, {
        0: {
          items: 2,
          nav: true
        },
        576: {
          items: 2,
          nav: true
        },
        768: {
          items: 3,
          nav: true
        },
        992: {
          items: 4,
          nav: true
        },
        1200: {
          items: 5,
          nav: true
        }
      })
    })
  }, tenPercentProducts === null || tenPercentProducts === void 0 ? void 0 : tenPercentProducts.map((item, index) => __jsx(_features_products_product_one__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index,
    customStyle: "20%"
  }))))));
}

/* harmony default export */ __webpack_exports__["Z"] = ((0,_server_apollo__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)({
  ssr: true
})(RecentCollection));

/***/ }),

/***/ 8048:
/***/ (function(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(104);
/* harmony import */ var react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_awesome_reveal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9290);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7659);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_tabs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8974);
/* harmony import */ var _features_product_countdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4229);
/* harmony import */ var _features_products_product_one__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4011);
/* harmony import */ var _features_products_product_three__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9915);
/* harmony import */ var _features_owl_carousel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4138);
/* harmony import */ var _utils_data_keyframes__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9905);
/* harmony import */ var _utils_data_slider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8509);
var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);



 // Import Custom Component





 // Import Settigns




function SelectedCollection(props) {
  const {
    latest,
    bestSelling,
    topRated
  } = props;
  return __jsx("section", {
    className: "selected-collection"
  }, __jsx(Reveal, {
    keyframes: fadeIn,
    delay: 100,
    duration: 1000,
    triggerOnce: true
  }, __jsx("div", {
    className: "product-slider-tab selected-products-section bg-white"
  }, __jsx(Tabs, {
    selectedTabClassName: "active",
    selectedTabPanelClassName: "active show"
  }, __jsx("div", {
    className: "heading shop-list d-flex flex-lg-row flex-column align-items-lg-center bg-gray mb-0 pl-0 pr-0 pt-2"
  }, __jsx("h4", {
    className: "section-title text-transform-none mb-0 ml-0"
  }, "Selected Products"), __jsx(TabList, {
    className: "nav justify-content-lg-center mb-0"
  }, __jsx(Tab, {
    className: "nav-item"
  }, __jsx(ALink, {
    href: "#",
    className: "nav-link"
  }, "Best Sellers")), __jsx(Tab, {
    className: "nav-item"
  }, __jsx(ALink, {
    href: "#",
    className: "nav-link"
  }, "New Arrivals")), __jsx(Tab, {
    className: "nav-item"
  }, __jsx(ALink, {
    href: "#",
    className: "nav-link"
  }, "Best Ratings"))), __jsx(ALink, {
    className: "view-all ml-auto",
    href: "/shop"
  }, "View All", __jsx("i", {
    className: "fas fa-long-arrow-alt-right"
  }))), __jsx("div", {
    className: "tab-content"
  }, __jsx(TabPanel, {
    className: "tab-pane fade"
  }, __jsx(OwlCarousel, {
    adClass: "products-slider nav-outer carousel-with-bg nav-circle show-nav-hover nav-image-center pb-0",
    options: productSlider
  }, bestSelling ? bestSelling.slice(0, 7).map((item, index) => __jsx(ProductOne, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index
  })) : [0, 1, 2, 3].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-one" + index
  })))), __jsx(TabPanel, {
    className: "tab-pane fade"
  }, __jsx(OwlCarousel, {
    adClass: "products-slider nav-outer carousel-with-bg nav-circle show-nav-hover nav-image-center pb-0",
    options: productSlider
  }, latest ? latest.slice(0, 7).map((item, index) => __jsx(ProductOne, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index
  })) : [0, 1, 2, 3].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-one" + index
  })))), __jsx(TabPanel, {
    className: "tab-pane fade"
  }, __jsx(OwlCarousel, {
    adClass: "products-slider nav-outer carousel-with-bg nav-circle show-nav-hover nav-image-center pb-0",
    options: productSlider
  }, topRated ? topRated.slice(0, 7).map((item, index) => __jsx(ProductOne, {
    adClass: "inner-quickview inner-icon",
    product: item,
    key: "product-one" + index
  })) : [0, 1, 2, 3].map((item, index) => __jsx("div", {
    className: "skel-pro skel-pro-grid",
    key: "product-one" + index
  })))))))), __jsx(Reveal, {
    keyframes: fadeIn,
    delay: 100,
    duration: 1000,
    triggerOnce: true
  }, __jsx("div", {
    className: "top-notice bg-dark text-white top-notice-bg"
  }, __jsx("div", {
    className: "container text-center d-flex align-items-center justify-content-center flex-column flex-xl-row "
  }, __jsx("img", {
    src: "images/home/shop-logo.png",
    width: "116",
    height: "23",
    alt: "logo"
  }), __jsx("h5", {
    className: "d-inline-block mb-0 pl-3 pr-3 pt-1 pb-1"
  }, "The Lowest Prices Once A Month! Hurry To Snap Up"), __jsx(ALink, {
    href: "/shop",
    className: "btn btn-darkcategory ls-n-0 mt-xl-0 mt-1"
  }, "SHOP NOW!")))));
}

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(/* unused pure expression or super */ null && (React.memo(SelectedCollection))));

/***/ })

};
;