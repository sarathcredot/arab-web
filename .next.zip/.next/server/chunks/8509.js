exports.id = 8509;
exports.ids = [8509];
exports.modules = {

/***/ 8509:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kk": function() { return /* binding */ productSingleSlider; },
/* harmony export */   "Kq": function() { return /* binding */ prodThumbSlider; },
/* harmony export */   "Wp": function() { return /* binding */ productExtendSlider; },
/* harmony export */   "Uw": function() { return /* binding */ blogSlider; },
/* harmony export */   "jP": function() { return /* binding */ postSlider; },
/* harmony export */   "sE": function() { return /* binding */ productSlider; },
/* harmony export */   "nV": function() { return /* binding */ widgetFeaturedProductSlider; },
/* harmony export */   "mI": function() { return /* binding */ brandSlider; }
/* harmony export */ });
/* unused harmony exports HomeSlider, categorySlider, infoBoxSlider, bannerSlider */
const productSingleSlider = {
  margin: 0,
  nav: true,
  loop: false,
  dots: false,
  autoplay: false
};
const prodThumbSlider = {
  margin: 8,
  items: 4,
  dots: false,
  nav: true,
  navText: ['<i class="fas fa-chevron-left">', '<i class="fas fa-chevron-right">']
};
const productExtendSlider = {
  loop: true,
  margin: 0,
  nav: true,
  dots: false,
  autoplay: false,
  center: true,
  responsive: {
    0: {
      items: 1
    },
    480: {
      items: 2
    },
    1200: {
      items: 3
    }
  }
};
const HomeSlider = {
  autoplay: false,
  nav: true,
  dots: false,
  autoplayTimeout: 12000,
  navText: ['<i class="icon-left-open-big">', '<i class="icon-right-open-big">'],
  loop: false
};
const blogSlider = {
  loop: false,
  margin: 20,
  autoplay: false,
  responsive: {
    0: {
      items: 1
    },
    480: {
      items: 2
    },
    768: {
      items: 3
    }
  }
};
const postSlider = {
  margin: 0,
  dots: false,
  lazyLoad: true,
  nav: true,
  items: 1
};
const productSlider = {
  loop: false,
  margin: 1,
  autoplay: false,
  dots: false,
  nav: false,
  navText: ['<i class="icon-left-open-big">', '<i class="icon-right-open-big">'],
  items: 2,
  responsive: {
    576: {
      items: 3
    },
    992: {
      items: 4
    },
    1200: {
      items: 6,
      nav: true
    }
  }
};
const categorySlider = {
  loop: false,
  margin: 20,
  autoplay: false,
  nav: false,
  dots: false,
  responsive: {
    0: {
      items: 2
    },
    480: {
      items: 3
    },
    576: {
      items: 4
    },
    768: {
      items: 5
    },
    992: {
      items: 7
    },
    1200: {
      items: 8
    }
  }
};
const widgetFeaturedProductSlider = {
  margin: 20,
  loop: false,
  nav: true,
  navText: ['<i class="icon-angle-left">', '<i class="icon-angle-right">'],
  dots: false
};
const infoBoxSlider = {
  loop: false,
  dots: false,
  responsive: {
    576: {
      items: 2
    },
    992: {
      items: 3
    },
    1400: {
      items: 4
    }
  }
};
const bannerSlider = {
  margin: 20,
  responsive: {
    576: {
      items: 2
    },
    992: {
      items: 3
    }
  }
};
const brandSlider = {
  loop: false,
  margin: 1,
  autoplay: false,
  dots: false,
  nav: true,
  navText: ['<i class="icon-left-open-big">', '<i class="icon-right-open-big">'],
  responsive: {
    0: {
      items: 4
    },
    480: {
      items: 4
    },
    768: {
      items: 5
    },
    992: {
      items: 6
    },
    1200: {
      items: 6
    }
  }
};

/***/ })

};
;