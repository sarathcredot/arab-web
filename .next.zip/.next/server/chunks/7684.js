exports.id = 7684;
exports.ids = [7684];
exports.modules = {

/***/ 7684:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ ProductNav; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_ALink__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8974);

var __jsx = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement);

function ProductNav(props) {
  const {
    next,
    prev,
    adClass = ''
  } = props;
  return __jsx((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, !prev && !next ? '' : __jsx("div", {
    className: `product-nav ${adClass}`
  }, __jsx("div", {
    className: `product-prev ${!prev ? 'disabled' : ''}`
  }, prev ? __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: prev ? {
      query: {
        slug: prev.slug
      }
    } : '#'
  }, __jsx("span", {
    className: "product-link"
  }), __jsx("span", {
    className: "product-popup"
  }, __jsx("span", {
    className: "box-content"
  }, __jsx("img", {
    // src={ process.env.NEXT_PUBLIC_ASSET_URI + prev?.small_pictures[ 0 ]?.url }
    alt: "product" // width={ prev?.small_pictures[ 0 ]?.width }
    // height={ prev?.small_pictures[ 0 ]?.height }

  }), __jsx("span", null, prev === null || prev === void 0 ? void 0 : prev.name)))) : __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: "#"
  }, __jsx("span", {
    className: "product-link"
  }))), __jsx("div", {
    className: `product-next ${!next ? 'disabled' : ''}`
  }, next ? __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: {
      query: {
        slug: next.slug
      }
    }
  }, __jsx("span", {
    className: "product-link"
  }), __jsx("span", {
    className: "product-popup"
  }, __jsx("span", {
    className: "box-content"
  }, __jsx("img", {
    // src={ process.env.NEXT_PUBLIC_ASSET_URI + next?.small_pictures[ 0 ]?.url }
    alt: "product" // width={ next?.small_pictures[ 0 ]?.width }
    // height={ next?.small_pictures[ 0 ]?.height }

  }), __jsx("span", null, next === null || next === void 0 ? void 0 : next.name)))) : __jsx(_common_ALink__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    href: "#"
  }, __jsx("span", {
    className: "product-link"
  })))));
}

/***/ })

};
;