exports.id = 5708;
exports.ids = [5708];
exports.modules = {

/***/ 5708:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nw": function() { return /* binding */ actions; },
/* harmony export */   "OP": function() { return /* binding */ wishlistSaga; }
/* harmony export */ });
/* unused harmony export actionTypes */
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3643);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(584);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5060);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const actionTypes = {
  AddToWishlist: "ADD_TO_WISHLIST",
  RemoveFromWishlsit: "REMOVE_FROM_WISHLIST",
  RefreshStore: "REFRESH_STORE",
  ShowModal: "SHOW_WISHLIST_MODAL"
};
const initialState = {
  list: [],
  showModal: false
};

const wishlistReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.AddToWishlist:
      if (state.list.findIndex(item => item === action.payload.product) < 0) {
        return _objectSpread(_objectSpread({}, state), {}, {
          list: [...state.list, action.payload.product]
        });
      }

      return state;

    case actionTypes.RemoveFromWishlsit:
      return {
        list: state.list.filter(product => product !== action.payload.product)
      };

    case actionTypes.RefreshStore:
      return initialState;

    default:
      return state;
  }
};

const actions = {
  addToWishList: product => ({
    type: actionTypes.AddToWishlist,
    payload: {
      product
    }
  }),
  removeFromWishlist: product => ({
    type: actionTypes.RemoveFromWishlsit,
    payload: {
      product
    }
  })
};
function* wishlistSaga() {
  yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_2__.takeEvery)(actionTypes.AddToWishlist, function* saga(e) {
    document.querySelector(".wishlist-popup") && document.querySelector(".wishlist-popup").classList.add("active");
    setTimeout(() => {
      document.querySelector(".wishlist-popup") && document.querySelector(".wishlist-popup").classList.remove("active");
    }, 2000);
  });
}
const persistConfig = {
  keyPrefix: "porto-",
  key: "wishlist",
  storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1___default())
};
/* harmony default export */ __webpack_exports__["ZP"] = ((0,redux_persist__WEBPACK_IMPORTED_MODULE_0__.persistReducer)(persistConfig, wishlistReducer));

/***/ })

};
;